# Roadcard Cartão Service

 Microsserviço responsável por realizar e gerennciar cartões.

## 1. Quem deve utilizar
 
   Serviços que precisem realizar operações como:
   
   		- Inclusão de Cartões;
   		- Alteração de Cartões;


## 2. Configuração da Aplicação

A seguir são apresentadas informações técnicas para configurar o ambiente em que a aplicação  deverá ser executada.

### 2.1 Requisitos

1. Java 8
2. Docker para rodar a aplicação 
3. Maven 3 configurado para acessar o repositório de artefatos da Pamcary ( [http://qualidade.pamcary-interno.com.br/nexus/](http://qualidade.pamcary-interno.com.br/nexus/) )
4. Ter permissão para utilizar os fontes do repositório git do projeto [http://erato.pamcary-interno.com.br/roadcard-interno/roadcard-cartao-service.git]

### 2.2 Rodar Aplicação com Docker

Após buildar a aplicação (_mvn clean build_), é necessário gerar uma imagem docker empacotando a aplicação. No diretório raiz do projeto existe um arquivo Dockerfile que servirá de base para imagem gerada. Ao acessar esse diretório, o comando abaixo gerará a imagem:

	docker build -t cartao-service:1.0.0 .
		
Para rodar o container docker a partir da imagem gerada execute o comando:

	docker run -it -p 9099:9091 --name cartao-service cartao-service:1.0.0
	
Para acessar o container acessar o endereco de acordo com a porta que foi mapeada:

	http://localhost:9099/

## 3. Referências

``[DOCKER]:`` [https://docs.docker.com/](https://docs.docker.com/)

