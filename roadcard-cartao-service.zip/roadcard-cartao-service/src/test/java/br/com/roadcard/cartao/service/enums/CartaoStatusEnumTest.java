package br.com.roadcard.cartao.service.enums;

import br.com.roadcard.cartao.model.CartaoStatusEnum;
import br.com.roadcard.cartao.service.AbstractCartaoServiceTest;
import br.com.roadcard.dock.exception.ResourceNotFoundException;
import org.junit.Test;

import static org.junit.Assert.*;

public class CartaoStatusEnumTest extends AbstractCartaoServiceTest {

    @Test
    public void testGet() throws Exception {
        assertSame("ATIVO", CartaoStatusEnum.ATIVO.getId());
        assertSame("Ativo", CartaoStatusEnum.ATIVO.getDescricao());
    }


    @Test
    public void buscarEnum_erroStatusNaoEncontrado(){
        try {
            CartaoStatusEnum.buscarEnum("");
            fail();
        } catch (Exception e) {
            assertEquals(ResourceNotFoundException.class, e.getClass());
        }
    }


}