package br.com.roadcard.cartao.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import br.com.roadcard.cartao.exception.UnprocessableEntityException;
import br.com.roadcard.cartao.model.dto.CartaoDockIntegradorDTO;
import br.com.roadcard.dock.autenticacao.AutenticacaoDockResponse;
import br.com.roadcard.dock.cards.CartaoDockDTO;
import br.com.roadcard.dock.cards.CartaoDockListDTO;

public class IntegradorDockServiceImplTest extends AbstractCartaoServiceTest {
    @Autowired
    private IntegradorDockServiceImpl integradorDockService;


    @Test
    public void buscarInformacaoCartaoDock_Sucesso() throws Exception {
        prepararMockToken();
        CartaoDockListDTO cartaoList = prepararListaCartoes();
        when(cardDockClient.getInfoCartao(any(),any())).thenReturn(cartaoList);

        CartaoDockIntegradorDTO result = integradorDockService.buscarInformacaoCartaoDock("numeroTest");

        assertEquals(cartaoList.getCartaoList().get(0).getId(), result.getId());
    }

    @Test
    public void buscarInformacaoCartaoDock_ErroQualquerExceptionNaDock() throws Exception {
        prepararMockToken();
        when(cardDockClient.getInfoCartao(any(),any())).thenThrow(RuntimeException.class);

        try {
            integradorDockService.buscarInformacaoCartaoDock("numeroTest");
            fail();
        } catch (Exception e){
            assertEquals(UnprocessableEntityException.class, e.getClass());
            assertEquals("error.msg.operacao.emissor", e.getMessage());
        }
    }

    @Test
    public void buscarInformacaoCartaoDock_ErroListaNula() throws Exception {
        prepararMockToken();
        CartaoDockListDTO cartaoList = null;
        when(cardDockClient.getInfoCartao(any(), any())).thenReturn(cartaoList);

        try {
            integradorDockService.buscarInformacaoCartaoDock("numeroTest");
            fail();
        } catch (Exception e){
            assertEquals(UnprocessableEntityException.class, e.getClass());
            assertEquals("error.msg.cartaoDock.nao.encontrado", e.getMessage());
        }
    }

    @Test
    public void buscarInformacaoCartaoDock_ErroListaVazia() throws Exception {
        prepararMockToken();
        List<CartaoDockDTO> list = null;

        CartaoDockListDTO cartaoList = new CartaoDockListDTO();
        cartaoList.setCartaoList(list);


        when(cardDockClient.getInfoCartao(any(), any())).thenReturn(cartaoList);

        try {
            integradorDockService.buscarInformacaoCartaoDock("numeroTest");
            fail();
        } catch (Exception e){
            assertEquals(UnprocessableEntityException.class, e.getClass());
            assertEquals("error.msg.cartaoDock.nao.encontrado", e.getMessage());
        }
    }


    @Test
    public void obterAutenticacaoDock_Sucesso() throws Exception {
        AutenticacaoDockResponse autenticacaoDockResponse = gerarAutenticacaoDockResponse();
        when(autenticacaoDockClient.gerarToken()).thenReturn(autenticacaoDockResponse);

        integradorDockService.obterAutenticacaoDock();

        assertEquals("tokenTest", autenticacaoDockResponse.getAccessToken());
    }

    @Test
    public void obterAutenticacaoDock_ErroNull() throws Exception {
        AutenticacaoDockResponse autenticacaoDockResponse = null;
        when(autenticacaoDockClient.gerarToken()).thenReturn(autenticacaoDockResponse);
        try{
            integradorDockService.obterAutenticacaoDock();
            fail();
        } catch (Exception e){
            assertEquals(UnprocessableEntityException.class, e.getClass());
        }
    }

    @Test
    public void obterAutenticacaoDock_ErroEmpty() throws Exception {
        AutenticacaoDockResponse autenticacaoDockResponse = new AutenticacaoDockResponse();
        autenticacaoDockResponse.setAccessToken("");
        autenticacaoDockResponse.setTokenType("");
        autenticacaoDockResponse.setExpiresIn("");

        when(autenticacaoDockClient.gerarToken()).thenReturn(autenticacaoDockResponse);
        try{
            integradorDockService.obterAutenticacaoDock();
            fail();
        } catch (Exception e){
            assertEquals(UnprocessableEntityException.class, e.getClass());
        }
    }




    private void prepararMockToken() {
        AutenticacaoDockResponse autenticacaoDockResponse = gerarAutenticacaoDockResponse();
        when(autenticacaoDockClient.gerarToken()).thenReturn(autenticacaoDockResponse);
    }

    private AutenticacaoDockResponse gerarAutenticacaoDockResponse() {
        AutenticacaoDockResponse autenticacaoDockResponse = new AutenticacaoDockResponse();
        autenticacaoDockResponse.setAccessToken("tokenTest");
        autenticacaoDockResponse.setTokenType("test");
        autenticacaoDockResponse.setExpiresIn("test");
        return autenticacaoDockResponse;
    }

}
