package br.com.roadcard.cartao.service.state;

import br.com.roadcard.cartao.model.CartaoStatusEnum;
import br.com.roadcard.cartao.model.state.*;
import br.com.roadcard.cartao.service.AbstractCartaoServiceTest;
import org.junit.Test;

import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;

public class CartaoStatusStateFactoryTest extends AbstractCartaoServiceTest {

    @Test
    public void testBuscarStatePorStatusNull() throws Exception {
        assertNull(CartaoStatusStateFactory.buscarStatePorStatus(null));
    }

    @Test
    public void testBuscarStatePorStatusProntoAtivacao() throws Exception {
        assertSame(ProntoAtivacaoStateImpl.class, CartaoStatusStateFactory.buscarStatePorStatus(CartaoStatusEnum.PRONTO_ATIVACAO).getClass());
    }

    @Test
    public void testBuscarStatePorStatusAtivo() throws Exception {
        assertSame(AtivoStateImpl.class, CartaoStatusStateFactory.buscarStatePorStatus(CartaoStatusEnum.ATIVO).getClass());
    }

    @Test
    public void testBuscarStatePorStatusBloqueado() throws Exception {
        assertSame(BloqueadoStateImpl.class, CartaoStatusStateFactory.buscarStatePorStatus(CartaoStatusEnum.BLOQUEADO).getClass());
    }

    @Test
    public void testBuscarStatePorStatusCancelado() throws Exception {
        assertSame(CanceladoStateImpl.class, CartaoStatusStateFactory.buscarStatePorStatus(CartaoStatusEnum.CANCELADO).getClass());
    }

}