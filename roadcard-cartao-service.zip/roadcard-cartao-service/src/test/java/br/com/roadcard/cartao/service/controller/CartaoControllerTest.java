package br.com.roadcard.cartao.service.controller;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.DataInput;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

import com.fasterxml.jackson.databind.ObjectMapper;

import br.com.roadcard.cartao.exception.CartaoFiltroException;
import br.com.roadcard.cartao.model.CartaoDock;
import br.com.roadcard.cartao.model.dto.CadastrarCartaoDTO;
import br.com.roadcard.cartao.model.dto.CartaoDockIntegradorDTO;
import br.com.roadcard.cartao.repository.CartaoRepository;
import br.com.roadcard.cartao.service.AbstractCartaoServiceTest;
import br.com.roadcard.cartao.service.IntegradorDockServiceImpl;
import br.com.roadcard.cartao.service.notifier.GenericTopicNotifier;
import br.com.roadcard.dock.exception.ResourceNotFoundException;
import br.com.roadcard.pamcard.auth.model.login.PermissaoDespesasConstants;
import br.com.roadcard.pamcard.auth.model.login.UsuarioPamcard;
import br.com.roadcard.pamcard.auth.test.context.support.WithMockUserPamcard;

public class CartaoControllerTest extends AbstractCartaoServiceTest {

    @Autowired
    private CartaoRepository cartaoRepository;

    @MockBean
    private IntegradorDockServiceImpl integradorDockService;

    @MockBean
    private GenericTopicNotifier genericTopicNotifier;

    private final ObjectMapper mapper = new ObjectMapper();


    @Test
    @WithMockUserPamcard(username = "testCadastrarCartao", cnpjContratante = "01234567891234")
    public void cadastrarCartao_Sucesso_e_ErroJaCadastrado() throws Exception{
        mockBuscaNaDock();

        //cadastro
        mockMvc.perform(post(CARTAO_RESOURCE)
                        .contentType("application/json")
                        .content(mapper.writeValueAsString(prepararCadastroCartaoDTO()))
                )
                .andDo(print())
                .andExpect(status().isCreated())
                .andExpect(header().exists("location"))
                .andExpect(header().string("location", "http://localhost" + "/api/cartoes/%7Bid%7D"))
                .andExpect(jsonPath("$.usuarioSolicitante").value("testCadastrarCartao"))
                .andExpect(jsonPath("$.nomeImpresso").value("testInMemory"));

        Optional<CartaoDock> cartao = cartaoRepository.findByIdCartaoIntegracao(1L);
        assertNotNull(cartao.get().getIdCartao());
        assertEquals("testCadastrarCartao", cartao.get().getUsuarioSolicitante());
        assertEquals("01234567891234", cartao.get().getProprietario().getCnpj());
        assertEquals("testInMemory", cartao.get().getNomeImpresso());
        assertEquals(Long.valueOf(1), cartao.get().getIdCartaoIntegracao());

        //erro por já ter cadastrado
        mockMvc.perform(post(CARTAO_RESOURCE)
                        .contentType("application/json")
                        .content(mapper.writeValueAsString(prepararCadastroCartaoDTO()))
                )
                .andDo(print())
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.msgErro").value("O número desse cartão já foi inserido."));
    }

    @Test
    @WithMockUserPamcard(username = "testProprietarioPresente", cnpjContratante = "25467197000102")
    public void cadastrarCartao_ProprietarioExisteNoBanco() throws Exception{
        CartaoDockIntegradorDTO cartaoDockIntegradorDTO = mockBuscaNaDock();
        cartaoDockIntegradorDTO.setId(2L);

        mockMvc.perform(post(CARTAO_RESOURCE)
                        .contentType("application/json")
                        .content(mapper.writeValueAsString(prepararCadastroCartaoDTO()))
                )
                .andDo(print())
                .andExpect(status().isCreated())
                .andExpect(header().exists("location"))
                .andExpect(header().string("location", "http://localhost" + "/api/cartoes/%7Bid%7D"))
                .andExpect(jsonPath("$.usuarioSolicitante").value("testProprietarioPresente"))
                .andExpect(jsonPath("$.nomeImpresso").value("testInMemory"));
    }

    @Test
    @WithMockUserPamcard
    public void cadastrarCartao_requestMalFormado() throws Exception {
        String cartaoPayload = "";

        mockMvc.perform(post(CARTAO_RESOURCE)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .content(cartaoPayload))
                .andDo(print())
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.tituloErro", is("Request JSON malformado")))
                .andExpect(jsonPath("$.msgErro", containsString("Required request body is missing:")));
    }

    @Test
    @WithMockUserPamcard
    public void cadastrarCartao_quantidadeCaracteresInvalida() throws Exception {
        CadastrarCartaoDTO cadastrarCartao = new CadastrarCartaoDTO();
        cadastrarCartao.setNumeroCartao("12");

        this.mockMvc.perform(post(CARTAO_RESOURCE)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .content(mapper.writeValueAsString(cadastrarCartao)))
                .andDo(print())
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.msgErro", is("Número cartão deve ter 16 caracteres; ")));
    }

    @Test
    public void cadastrarCartao_SemAutenticacao() throws Exception {

        mockMvc.perform(post(CARTAO_RESOURCE)
                        .contentType("application/json")
                        .content(mapper.writeValueAsString(prepararCadastroCartaoDTO()))
                )
                .andExpect(status().isUnauthorized());
    }


    // buscarCartoes


    @Test
    @WithMockUserPamcard(cnpjContratante = "00000000000014",
            authorities = PermissaoDespesasConstants.APLICACAO_DESPESAS_ACESSO_TOTAL,
            tipoUsuario = UsuarioPamcard.TipoUsuario.CLIENTE)
    public void buscarCartoes_Sucesso_Paginado() throws Exception {

        MvcResult result = mockMvc.perform(get(CARTAO_RESOURCE + "?pagina=0&tamanho=10&colunaOrdenacao=idCartao"))
                .andDo(print())
                .andExpect(status().isOk())
                .andReturn();

        String response = result.getResponse().getContentAsString();
        assertTrue(response.contains("testBuscarCartoes"));
        assertTrue(response.contains("00000000000014"));
    }

    @Test
    @WithMockUserPamcard(cnpjContratante = "00000000000014",
            authorities = PermissaoDespesasConstants.APLICACAO_DESPESAS_ACESSO_TOTAL,
            tipoUsuario = UsuarioPamcard.TipoUsuario.CLIENTE)
    public void buscarCartoes_Sucesso_NaoPaginado() throws Exception {

        mockMvc.perform(get(CARTAO_RESOURCE + "?paginado=false"))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].nomeImpresso").value("testBuscarCartoes"))
                .andExpect(jsonPath("$[0].proprietario.cnpj").value("00000000000014"));
    }

    @Test
    @WithMockUserPamcard(tipoUsuario = UsuarioPamcard.TipoUsuario.APLICACAO)
    public void buscarCartoes_UsuarioDiferenteDeCliente() throws Exception {

        Map<String, String> filtro = new HashMap<>();
        filtro.put("proprietario","cnpj");

        MvcResult result = mockMvc.perform(get(CARTAO_RESOURCE + "?paginado=false")
                        .header("filtros",mapper.writeValueAsString(filtro))
                )
                .andDo(print())
                .andExpect(status().isOk())
                .andReturn();

        String response = result.getResponse().getContentAsString();
        assertTrue(response.contains("00000000000014"));
        assertTrue(response.contains("25467197000102"));
        //usuario diferente de CLIENTE tem acesso a todos os cartoes na busca, pois nao filtra por cnpj
    }

    @Test
    @WithMockUserPamcard(cnpjContratante = "00000000000014",
            authorities = PermissaoDespesasConstants.APLICACAO_DESPESAS_ACESSO_TOTAL,
            tipoUsuario = UsuarioPamcard.TipoUsuario.CLIENTE)
    public void buscarCartoes_Sucesso_FiltroCPF() throws Exception {

        Map<String, String> filtro = new HashMap<>();
        filtro.put("cpf","00100200341");

        mockMvc.perform(get(CARTAO_RESOURCE + "?paginado=false")
                        .header("filtros",mapper.writeValueAsString(filtro))
                )
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].portador.cpf").value("00100200341"))
                .andExpect(jsonPath("$[0].proprietario.cnpj").value("00000000000014"))
                .andExpect(jsonPath("$[0].nomeImpresso").value("unicoComEsseCPFeCNPJ"));
    }

    @Test
    @WithMockUserPamcard(cnpjContratante = "00000000000014",
            authorities = PermissaoDespesasConstants.APLICACAO_DESPESAS_ACESSO_TOTAL,
            tipoUsuario = UsuarioPamcard.TipoUsuario.CLIENTE)
    public void buscarCartoes_Sucesso_FiltroStatus() throws Exception {

        Map<String, String> filtro = new HashMap<>();
        filtro.put("status","ATIVO");

        MvcResult result = mockMvc.perform(get(CARTAO_RESOURCE + "?paginado=false")
                        .header("filtros",mapper.writeValueAsString(filtro))
                )
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].proprietario.cnpj").value("00000000000014"))
                .andReturn();

        JsonNode node = mapper.readTree(result.getResponse().getContentAsString());
        List<String> resultadoStatus = new ArrayList<>();
         if (node.isArray()) {
            for (final JsonNode objNode : node) {
                resultadoStatus.add(mapper.readValue(objNode.get("status").toString(),String.class));
             }
        }
        long quantidadeRegistrosDiferenteAtivo = resultadoStatus.stream().filter(s -> !s.equals("ATIVO")).count();

         assertEquals(0,quantidadeRegistrosDiferenteAtivo);

    }

    @Test
    @WithMockUserPamcard(cnpjContratante = "00000000000014",
            authorities = PermissaoDespesasConstants.APLICACAO_DESPESAS_ACESSO_TOTAL,
            tipoUsuario = UsuarioPamcard.TipoUsuario.CLIENTE)
    public void buscarCartoes_Sucesso_FiltroQuatroDigitos() throws Exception {

        Map<String, String> filtro = new HashMap<>();
        filtro.put("quatroDigitos","4321");

        mockMvc.perform(get(CARTAO_RESOURCE + "?paginado=false")
                                .header("filtros",mapper.writeValueAsString(filtro))

                )
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].quatroUltimosDigitos").value("4321"))
                .andExpect(jsonPath("$[0].proprietario.cnpj").value("00000000000014"));
    }

    @Test
    @WithMockUserPamcard
    public void buscarCartoes_Erro_FiltroQuatroDigitosNaoNumericos() throws Exception {

        Map<String, String> filtro = new HashMap<>();
        filtro.put("quatroDigitos","naoNumerico");

        MvcResult result = mockMvc.perform(get(CARTAO_RESOURCE + "?paginado=false")
                        .header("filtros",mapper.writeValueAsString(filtro))
                )
                .andDo(print())
                .andExpect(status().isBadRequest())
                .andReturn();

        assertEquals(CartaoFiltroException.class, result.getResolvedException().getClass());
    }

    @Test
    @WithMockUserPamcard
    public void buscarCartoes_Erro_FiltroQuatroDigitosValidarQuantidadeCaractetes() throws Exception {

        Map<String, String> filtro = new HashMap<>();
        filtro.put("quatroDigitos","43211111");

        MvcResult result = mockMvc.perform(get(CARTAO_RESOURCE + "?paginado=false")
                        .header("filtros",mapper.writeValueAsString(filtro))
                )
                .andDo(print())
                .andExpect(status().isBadRequest())
                .andReturn();

        assertEquals(CartaoFiltroException.class, result.getResolvedException().getClass());
    }

    @Test
    @WithMockUserPamcard(cnpjContratante = "00000000000014",
            authorities = PermissaoDespesasConstants.APLICACAO_DESPESAS_ACESSO_TOTAL,
            tipoUsuario = UsuarioPamcard.TipoUsuario.CLIENTE)
    public void buscarCartoes_Sucesso_FiltroNomePortador() throws Exception {

        Map<String, String> filtro = new HashMap<>();
        filtro.put("nomePortador","vinicius2");

        mockMvc.perform(get(CARTAO_RESOURCE + "?paginado=false")
                        .header("filtros",mapper.writeValueAsString(filtro))
                )
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].portador.nome").value("vinicius2"));
    }


    @Test
    @WithMockUserPamcard(cnpjContratante = "00000000000014",
            authorities = PermissaoDespesasConstants.APLICACAO_DESPESAS_ACESSO_TOTAL,
            tipoUsuario = UsuarioPamcard.TipoUsuario.CLIENTE)
    public void buscarCartoes_Sucesso_FiltroTipoCartao() throws Exception {

        mockMvc.perform(get(CARTAO_RESOURCE + "?paginado=false")
                        .param("tipoCartao", "CARTAO_DOCK_FROTA")
                )
                .andDo(print())
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUserPamcard(cnpjContratante = "25467197000102",
            authorities = PermissaoDespesasConstants.APLICACAO_DESPESAS_ACESSO_TOTAL,
            tipoUsuario = UsuarioPamcard.TipoUsuario.CLIENTE)
    public void buscarCartoes_Sucesso_FiltroIdCartao() throws Exception {

        Map<String, String> filtro = new HashMap<>();
        filtro.put("idCartao","115");

        mockMvc.perform(get(CARTAO_RESOURCE + "?paginado=false")
                        .header("filtros",mapper.writeValueAsString(filtro))
                )
                .andDo(print())
                .andExpect(jsonPath("$[0].idCartao",  is(115)))
                .andExpect(status().isOk());
    }


    // buscarPorId


    @Test
    @WithMockUserPamcard(cnpjContratante = "00000000000014",
            authorities = PermissaoDespesasConstants.APLICACAO_DESPESAS_ACESSO_TOTAL,
            tipoUsuario = UsuarioPamcard.TipoUsuario.CLIENTE)
    public void buscarPorId_Sucesso() throws Exception {

        mockMvc.perform(get(CARTAO_RESOURCE + "/281"))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.idCartaoIntegracao").value("281"))
                .andExpect(jsonPath("$.proprietario.cnpj").value("00000000000014"));
    }

    @Test
    @WithMockUserPamcard(cnpjContratante = "00000000000014",
            authorities = PermissaoDespesasConstants.APLICACAO_DESPESAS_ACESSO_TOTAL,
            tipoUsuario = UsuarioPamcard.TipoUsuario.CLIENTE)
    public void buscarPorId_Erro_CartaoNaoEncontrado() throws Exception {

        MvcResult result = mockMvc.perform(get(CARTAO_RESOURCE + "/999"))
                .andDo(print())
                .andExpect(status().isNotFound())
                .andReturn();

        assertEquals(ResourceNotFoundException.class, result.getResolvedException().getClass());
    }

    @Test
    @WithMockUserPamcard(cnpjContratante = "00000000000055",
            authorities = PermissaoDespesasConstants.APLICACAO_DESPESAS_ACESSO_TOTAL,
            tipoUsuario = UsuarioPamcard.TipoUsuario.CLIENTE)
    public void buscarPorId_Erro_ValidarProprietario() throws Exception {

        MvcResult result = mockMvc.perform(get(CARTAO_RESOURCE + "/281"))
                .andDo(print())
                .andExpect(status().isNotFound())
                .andReturn();

        assertEquals(ResourceNotFoundException.class, result.getResolvedException().getClass());
    }



    // status



    @Test
    @WithMockUserPamcard
    public void carregarStatus() throws Exception {

        MvcResult result = mockMvc.perform(get(CARTAO_RESOURCE + "/status"))
                .andDo(print())
                .andExpect(status().isOk())
                .andReturn();

        String response = result.getResponse().getContentAsString();
        assertTrue(response.contains("PENDENTE_VINCULACAO"));
        assertTrue(response.contains("PENDENTE_SENHA"));
        assertTrue(response.contains("PENDENTE_LIMITE"));
        assertTrue(response.contains("PRONTO_ATIVACAO"));
        assertTrue(response.contains("ATIVO"));
        assertTrue(response.contains("BLOQUEADO"));
        assertTrue(response.contains("CANCELADO"));
    }














    private CartaoDockIntegradorDTO mockBuscaNaDock(){
        CartaoDockIntegradorDTO cartao = new CartaoDockIntegradorDTO();
        cartao.setId(1L);
        cartao.setNumeroCartao("1234********4321");
        cartao.setDataValidade(LocalDateTime.now());
        cartao.setDataEmissao(LocalDateTime.now());
        cartao.setNomeImpresso("testInMemory");

        when(integradorDockService.buscarInformacaoCartaoDock(any())).thenReturn(cartao);
        return cartao;
    }
    private CadastrarCartaoDTO prepararCadastroCartaoDTO() {
        CadastrarCartaoDTO cadastrarCartao = new CadastrarCartaoDTO();
        cadastrarCartao.setNumeroCartao("1234111100004321");
        return cadastrarCartao;
    }





}
