package br.com.roadcard.cartao.service.state;

import br.com.roadcard.cartao.model.CartaoStatusEnum;
import br.com.roadcard.cartao.model.state.CartaoStatusState;
import br.com.roadcard.cartao.model.state.CartaoStatusStateFactory;
import br.com.roadcard.cartao.service.AbstractCartaoServiceTest;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertSame;

public class BloqueadoStateImplTest extends AbstractCartaoServiceTest {

    private CartaoStatusState stateImpl;

    @Before
    public void onStart() {
        stateImpl = CartaoStatusStateFactory.buscarStatePorStatus(CartaoStatusEnum.BLOQUEADO);
    }

    @Test
    public void testDefinirCartaoAtivo() {
        assertSame(CartaoStatusEnum.ATIVO, stateImpl.definirCartaoAtivo());
    }

    @Test
    public void testDefinirCartaoCancelado() {
        assertSame(CartaoStatusEnum.CANCELADO, stateImpl.definirCartaoCancelado());
    }

}