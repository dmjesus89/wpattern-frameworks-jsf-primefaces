package br.com.roadcard.cartao.service.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;

import org.junit.Test;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.amazonaws.services.sns.model.PublishRequest;

import br.com.roadcard.cartao.model.LimiteCartao;
import br.com.roadcard.cartao.model.dto.LimiteDTO;
import br.com.roadcard.cartao.repository.LimiteCartaoRepository;
import br.com.roadcard.cartao.service.AbstractCartaoServiceTest;
import br.com.roadcard.dock.cards.LimiteCartaoDTO;
import br.com.roadcard.pamcard.auth.test.context.support.WithMockUserPamcard;

public class LimiteCartaoControllerTest extends AbstractCartaoServiceTest {
	@MockBean
	private LimiteCartaoRepository limiteCartaoRepository;
    private final String LIMITE = "/controlesLimites";
    

    @Test
    @WithMockUserPamcard(username = "testLimiteCartao", cnpjContratante = "62006491000135")
    public void cadastrarLimite_Sucesso() throws Exception {
    	prepararMock_AutenticacaoDockClientGerarToken();
    	prepararMock_gerarTokenValidoCognitoClient();
    	prepararMock_consultarSaldoConta(500);
    	prepararMock_cadastrarLimiteCartaoDock();
    	prepararMock_snsAws();
    	
    	//TODO remover esse mock com a correção do portador
    	when(limiteCartaoRepository.save(any(LimiteCartao.class))).thenReturn(null);
    	
    	
    	mockMvc.perform(post(CARTAO_RESOURCE+"/299"+LIMITE)
                .contentType("application/json")
                .content(mapper.writeValueAsString(prepararLimiteDTO(20, 50, 100))))
        .andDo(print())
        .andExpect(status().isCreated());
    	
    	
//    	Optional<LimiteCartao> limiteOptional = limiteCartaoRepository.findByIdCartaoAndProprietario("299", "62006491000135");
//    	
//    	assertEquals(BigDecimal.valueOf(20), limiteOptional.get().getLimiteDiario());
//    	assertEquals(Long.valueOf(10), limiteOptional.get().getIdLimiteIntegracao());
//    	assertEquals(BigDecimal.valueOf(50), limiteOptional.get().getLimiteSemanal());
//    	assertEquals(BigDecimal.valueOf(100), limiteOptional.get().getLimiteMensal());
//    	assertEquals(LocalDateTime.now().getDayOfMonth() ,limiteOptional.get().getDataHoraCadastro().getDayOfMonth());
//    	assertEquals(LocalDateTime.now().getMonth() ,limiteOptional.get().getDataHoraCadastro().getMonth());
//    	assertEquals(LocalDateTime.now().getYear() ,limiteOptional.get().getDataHoraCadastro().getYear());
    	
    	verify(snsMock, times(2)).publish(any(PublishRequest.class));
      
    }
    
    @Test
    @WithMockUserPamcard(username = "testLimiteCartao", cnpjContratante = "90687877000195")
    public void cadastrarLimite_cadastrarLimiteCartao_erroIntegracaoDock() throws Exception {
    	prepararMock_AutenticacaoDockClientGerarToken();
    	prepararMock_gerarTokenValidoCognitoClient();
    	prepararMock_consultarSaldoConta(500);
    	when(cardDockClient.cadastrarLimiteCartao(anyString(), eq(250L) , any(LimiteCartaoDTO.class))).thenThrow(new RuntimeException());

    	//TODO remover esse mock com a correção do portador
    	when(limiteCartaoRepository.save(any(LimiteCartao.class))).thenReturn(null);
    	
    	
    	mockMvc.perform(post(CARTAO_RESOURCE+"/250"+LIMITE)
                .contentType("application/json")
                .content(mapper.writeValueAsString(prepararLimiteDTO(20, 50, 100))))
        .andDo(print())
        .andExpect(status().isUnprocessableEntity())
        .andExpect(jsonPath("$.tituloErro").value("Erro Integração"))
    	.andExpect(jsonPath("$.msgErro").value("Não foi possível realizar a operação no emissor."));
      
    }
    
    @Test
    @WithMockUserPamcard(username = "testLimiteCartao", cnpjContratante = "74480593000177")
    public void cadastrarLimite_validarLimitesCartoesComSaldoContratante_limiteMaiorSaldoErro() throws Exception {
    	prepararMock_AutenticacaoDockClientGerarToken();
    	prepararMock_gerarTokenValidoCognitoClient();
    	prepararMock_consultarSaldoConta(1);
    	
    	//TODO remover esse mock com a correção do portador
    	when(limiteCartaoRepository.somatorioLimitesAtivosPorProprietario(any(String.class))).thenReturn(BigDecimal.valueOf(100));
    	
    	mockMvc.perform(post(CARTAO_RESOURCE+"/240"+LIMITE)
                .contentType("application/json")
                .content(mapper.writeValueAsString(prepararLimiteDTO(20, 50, 100))))
        .andDo(print())
        .andExpect(status().isUnprocessableEntity())
        .andExpect(jsonPath("$.tituloErro").value("Ocorreu um erro de validação"))
    	.andExpect(jsonPath("$.msgErro").value("O limite definido não pode ser maior que o seu saldo. "));
      
    }
    
    @Test
    @WithMockUserPamcard(username = "testLimiteCartao", cnpjContratante = "74480593000177")
    public void cadastrarLimite_cognitoServiceGetToken_obterTokenErro() throws Exception {
    	prepararMock_AutenticacaoDockClientGerarToken();
    	when(cognitoClient.getToken(any(String.class), any(String.class), any(String.class), any(String.class))).thenThrow(new RuntimeException());
    	
    	//TODO remover esse mock com a correção do portador
    	when(limiteCartaoRepository.somatorioLimitesAtivosPorProprietario(any(String.class))).thenReturn(BigDecimal.valueOf(100));
    	
    	mockMvc.perform(post(CARTAO_RESOURCE+"/240"+LIMITE)
                .contentType("application/json")
                .content(mapper.writeValueAsString(prepararLimiteDTO(20, 50, 100))))
        .andDo(print())
        .andExpect(status().isUnprocessableEntity())
        .andExpect(jsonPath("$.tituloErro").value("Erro Integração"))
    	.andExpect(jsonPath("$.msgErro").value("Não foi possível realizar a operação no emissor."));
      
    }
    
    @Test
    @WithMockUserPamcard(username = "testLimiteCartao", cnpjContratante = "00001001000312")
    public void cadastrarLimite_obterCartaoPendenteLimite_CartaoStatusPendenteLimiteErro() throws Exception {
    	
    	mockMvc.perform(post(CARTAO_RESOURCE+"/200"+LIMITE)
                .contentType("application/json")
                .content(mapper.writeValueAsString(prepararLimiteDTO(20, 50, 100))))
        .andDo(print())
        .andExpect(status().isUnprocessableEntity())
        .andExpect(jsonPath("$.tituloErro").value("Ocorreu um erro de validação"))
    	.andExpect(jsonPath("$.msgErro").value("Cartão não disponível para cadastro de limite. Por favor informe outro cartão."));
    }
    
    @Test
    @WithMockUserPamcard(username = "testLimiteCartao", cnpjContratante = "30972027000107")
    public void cadastrarLimite_buscarCartaoPeloIdCartaoEProprietario_CartaoNotFoundErro() throws Exception {
    	
    	mockMvc.perform(post(CARTAO_RESOURCE+"/990"+LIMITE)
                .contentType("application/json")
                .content(mapper.writeValueAsString(prepararLimiteDTO(20, 50, 100))))
        .andDo(print())
        .andExpect(status().isUnprocessableEntity())
        .andExpect(jsonPath("$.tituloErro").value("Cartão não encontrado."))
    	.andExpect(jsonPath("$.msgErro").value("Cartão não encontrado. Por favor informe outro cartão."));
        
      
    }
    
    @Test
    @WithMockUserPamcard(username = "testLimiteCartao", cnpjContratante = "30972027000107")
    public void cadastrarLimite_limiteValidation_limiteDiarioMaiorSemanalErro() throws Exception {
    	
    	mockMvc.perform(post(CARTAO_RESOURCE+"/990"+LIMITE)
                .contentType("application/json")
                .content(mapper.writeValueAsString(prepararLimiteDTO(80, 50, 100))))
        .andDo(print())
        .andExpect(status().isUnprocessableEntity())
        .andExpect(jsonPath("$.tituloErro").value("Ocorreu um erro de validação"))
    	.andExpect(jsonPath("$.msgErro").value("O limite diário não pode ser maior que o limite semanal."));
    }
    
    @Test
    @WithMockUserPamcard(username = "testLimiteCartao", cnpjContratante = "30972027000107")
    public void cadastrarLimite_limiteValidation_limiteSemanalMaiorMensalErro() throws Exception {
    	
    	mockMvc.perform(post(CARTAO_RESOURCE+"/990"+LIMITE)
                .contentType("application/json")
                .content(mapper.writeValueAsString(prepararLimiteDTO(80, 150, 100))))
        .andDo(print())
        .andExpect(status().isUnprocessableEntity())
        .andExpect(jsonPath("$.tituloErro").value("Ocorreu um erro de validação"))
    	.andExpect(jsonPath("$.msgErro").value("O limite semanal não pode ser maior que o limite mensal."));
    }
    
    @Test
    @WithMockUserPamcard(username = "testLimiteCartao", cnpjContratante = "30972027000107")
    public void cadastrarLimite_limiteValidation_limiteDiarioMaiorMensalErro() throws Exception {
    	
    	mockMvc.perform(post(CARTAO_RESOURCE+"/990"+LIMITE)
                .contentType("application/json")
                .content(mapper.writeValueAsString(prepararLimiteDTO(150, 200, 100))))
        .andDo(print())
        .andExpect(status().isUnprocessableEntity())
        .andExpect(jsonPath("$.tituloErro").value("Ocorreu um erro de validação"))
    	.andExpect(jsonPath("$.msgErro").value("O limite semanal não pode ser maior que o limite mensal."));
    }
    
    
	private LimiteDTO prepararLimiteDTO(int diario, int semanal, int mensal) {
		LimiteDTO item = new LimiteDTO();
		item.setLimiteDiario(BigDecimal.valueOf(diario));
		item.setLimiteSemanal(BigDecimal.valueOf(semanal));
		item.setLimiteMensal(BigDecimal.valueOf(mensal));
		return item;
	}
   
}
