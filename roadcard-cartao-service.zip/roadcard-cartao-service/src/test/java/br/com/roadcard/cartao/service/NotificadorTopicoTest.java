package br.com.roadcard.cartao.service;

import br.com.roadcard.cartao.exception.CartaoNotificationException;
import br.com.roadcard.cartao.service.notifier.GenericTopicNotifier;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.model.PublishResult;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;


@SpringBootTest
@RunWith(SpringRunner.class)
public class NotificadorTopicoTest {

    @Autowired
    private GenericTopicNotifier topicNotifier;

    @MockBean
    private AmazonSNS sns;


    @Test
    public void enviarNotificacao_sucesso() {
        PublishResult retorno = new PublishResult();
        retorno.setMessageId("Teste OK");
        when(sns.publish(Mockito.any())).thenReturn(retorno);

        boolean result = topicNotifier.enviarNotificacao("teste","teste","teste");
        assertTrue(result);
    }

    @Test
    public void enviarNotificacao_erro() throws JsonProcessingException {
        PublishResult retorno = new PublishResult();
        retorno.setMessageId("");
        when(sns.publish(Mockito.any())).thenReturn(retorno);

        when(topicNotifier.enviarSnsAws("teste","teste","teste")).thenThrow(RuntimeException.class);

        try {
            topicNotifier.enviarNotificacao("teste","teste","teste");
            fail();
        } catch (Exception e){
            assertEquals(CartaoNotificationException.class, e.getClass());
        }
    }

}
