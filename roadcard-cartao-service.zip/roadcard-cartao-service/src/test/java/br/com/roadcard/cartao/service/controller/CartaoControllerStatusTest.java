package br.com.roadcard.cartao.service.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Optional;

import org.junit.Test;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MvcResult;

import br.com.roadcard.cartao.exception.UnprocessableEntityException;
import br.com.roadcard.cartao.model.CartaoDock;
import br.com.roadcard.cartao.model.CartaoStatusEnum;
import br.com.roadcard.cartao.repository.CartaoDockRepository;
import br.com.roadcard.cartao.repository.CartaoRepository;
import br.com.roadcard.cartao.service.AbstractCartaoServiceTest;
import br.com.roadcard.dock.exception.ResourceNotFoundException;
import br.com.roadcard.pamcard.auth.test.context.support.WithMockUserPamcard;

public class CartaoControllerStatusTest extends AbstractCartaoServiceTest {

    @MockBean
    private CartaoRepository cartaoRepository;
    @MockBean
    private CartaoDockRepository cartaoDockRepository;


    @Test
    @WithMockUserPamcard
    public void alterarStatusParaAtivo() throws Exception {
    	prepararMock_AutenticacaoDockClientGerarToken();
    	
    	CartaoDock cartao = gerarCartaoDock();
    	cartao.setStatus(CartaoStatusEnum.PRONTO_ATIVACAO);
    	cartao.getProprietario().setCnpj("11111111111111");
        when(cartaoDockRepository.findById(any(Long.class))).thenReturn(Optional.ofNullable(cartao));
        
        prepararMockHistoricoCartaoTopicNotifier();

        mockMvc.perform(patch(STATUS_RESOURCE, 1)
        		.contentType("application/json")
                .content(CartaoStatusEnum.ATIVO.toString()))
                .andDo(print())
                .andExpect(status().isNoContent());
    }
    
    @Test
    @WithMockUserPamcard
    public void alterarStatusParaAtivoErroIntegracao() throws Exception {
    	prepararMock_AutenticacaoDockClientGerarToken();
    	
    	CartaoDock cartao = gerarCartaoDock();
    	cartao.setStatus(CartaoStatusEnum.BLOQUEADO);
    	cartao.getProprietario().setCnpj("11111111111111");
        when(cartaoDockRepository.findById(any(Long.class))).thenReturn(Optional.ofNullable(cartao));
        
        doThrow(new UnprocessableEntityException("Erro Integracao Mock", "Erro Integracao Mock"))
		.when(cardDockClient).ativarCartao(any(), any());

        mockMvc.perform(patch(STATUS_RESOURCE, 1)
        		.contentType("application/json")
                .content(CartaoStatusEnum.ATIVO.toString()))
                .andDo(print())
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.tituloErro", is("Erro Integração")))
                .andExpect(jsonPath("$.msgErro", is("Não foi possível realizar a operação no emissor.")));
    }
    
    @Test
    @WithMockUserPamcard
    public void alterarStatusParaBloqueado() throws Exception {
    	prepararMock_AutenticacaoDockClientGerarToken();
    	
    	CartaoDock cartao = gerarCartaoDock();
    	cartao.setStatus(CartaoStatusEnum.ATIVO);
    	cartao.getProprietario().setCnpj("11111111111111");
        when(cartaoDockRepository.findById(any(Long.class))).thenReturn(Optional.ofNullable(cartao));
        
        prepararMockHistoricoCartaoTopicNotifier();

        mockMvc.perform(patch(STATUS_RESOURCE, 1)
        		.contentType("application/json")
                .content(CartaoStatusEnum.BLOQUEADO.toString()))
                .andDo(print())
                .andExpect(status().isNoContent());
    }
    
    @Test
    @WithMockUserPamcard
    public void alterarStatusParaBloqueadoErroIntegracao() throws Exception {
    	prepararMock_AutenticacaoDockClientGerarToken();
    	
    	CartaoDock cartao = gerarCartaoDock();
    	cartao.setStatus(CartaoStatusEnum.ATIVO);
    	cartao.getProprietario().setCnpj("11111111111111");
        when(cartaoDockRepository.findById(any(Long.class))).thenReturn(Optional.ofNullable(cartao));
        
        doThrow(new UnprocessableEntityException("Erro Integracao Mock", "Erro Integracao Mock"))
		.when(cardDockClient).bloquearCartao(any(), any());

        mockMvc.perform(patch(STATUS_RESOURCE, 1)
        		.contentType("application/json")
                .content(CartaoStatusEnum.BLOQUEADO.toString()))
                .andDo(print())
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.tituloErro", is("Erro Integração")))
                .andExpect(jsonPath("$.msgErro", is("Não foi possível realizar a operação no emissor.")));
    }
    
    @Test
    @WithMockUserPamcard
    public void alterarStatusParaCancelado() throws Exception {
    	prepararMock_AutenticacaoDockClientGerarToken();
    	
    	CartaoDock cartao = gerarCartaoDock();
    	cartao.setStatus(CartaoStatusEnum.ATIVO);
    	cartao.getProprietario().setCnpj("11111111111111");
        when(cartaoDockRepository.findById(any(Long.class))).thenReturn(Optional.ofNullable(cartao));
        
        prepararMockHistoricoCartaoTopicNotifier();

        mockMvc.perform(patch(STATUS_RESOURCE, 1)
        		.contentType("application/json")
                .content(CartaoStatusEnum.CANCELADO.toString()))
                .andDo(print())
                .andExpect(status().isNoContent());
    }
    
    @Test
    @WithMockUserPamcard
    public void alterarStatusParaCanceladoErroIntegracao() throws Exception {
    	prepararMock_AutenticacaoDockClientGerarToken();
    	
    	CartaoDock cartao = gerarCartaoDock();
    	cartao.setStatus(CartaoStatusEnum.ATIVO);
    	cartao.getProprietario().setCnpj("11111111111111");
        when(cartaoDockRepository.findById(any(Long.class))).thenReturn(Optional.ofNullable(cartao));
        
        doThrow(new UnprocessableEntityException("Erro Integracao Mock", "Erro Integracao Mock"))
		.when(cardDockClient).cancelarCartao(any(), any());

        mockMvc.perform(patch(STATUS_RESOURCE, 1)
        		.contentType("application/json")
                .content(CartaoStatusEnum.CANCELADO.toString()))
                .andDo(print())
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.tituloErro", is("Erro Integração")))
                .andExpect(jsonPath("$.msgErro", is("Não foi possível realizar a operação no emissor.")));
    }
    
    @Test
    @WithMockUserPamcard
    public void alterarStatusNotFound() throws Exception {
    	
    	when(cartaoDockRepository.findById(any(Long.class))).thenReturn(Optional.<CartaoDock>empty());

        MvcResult result = mockMvc.perform(patch(STATUS_RESOURCE, 1)
        		.contentType("application/json")
                .content(CartaoStatusEnum.ATIVO.toString()))
                .andExpect(status().isNotFound()).andReturn();
        
        assertEquals(ResourceNotFoundException.class, result.getResolvedException().getClass());
    }
    
    @Test
    @WithMockUserPamcard
    public void alterarStatusComErroProprietario() throws Exception {
    	
    	CartaoDock cartao = gerarCartaoDock();
    	cartao.setStatus(CartaoStatusEnum.PRONTO_ATIVACAO);
    	when(cartaoDockRepository.findById(any(Long.class))).thenReturn(Optional.ofNullable(cartao));

        mockMvc.perform(patch(STATUS_RESOURCE, 1)
        		.contentType("application/json")
                .content(CartaoStatusEnum.ATIVO.toString()))
                .andDo(print())
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.tituloErro", is("Erro proprietário")))
                .andExpect(jsonPath("$.msgErro", is("Cartão não pertence ao proprietário")));
    }
    
    @Test
    @WithMockUserPamcard
    public void alterarStatusComErroAtivacao() throws Exception {
    	
    	CartaoDock cartao = gerarCartaoDock();
    	cartao.getProprietario().setCnpj("11111111111111");
    	cartao.setStatus(CartaoStatusEnum.PENDENTE_LIMITE);
    	when(cartaoDockRepository.findById(any(Long.class))).thenReturn(Optional.ofNullable(cartao));

        mockMvc.perform(patch(STATUS_RESOURCE, 1)
        		.contentType("application/json")
                .content(CartaoStatusEnum.ATIVO.toString()))
                .andDo(print())
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.tituloErro", is("Erro status")))
                .andExpect(jsonPath("$.msgErro", is("Cartão com status diferente de PRONTO_ATIVACAO ou BLOQUEADO")));
    }
    
    @Test
    @WithMockUserPamcard
    public void alterarStatusComErroBloqueio() throws Exception {
    	
    	CartaoDock cartao = gerarCartaoDock();
    	cartao.getProprietario().setCnpj("11111111111111");
    	cartao.setStatus(CartaoStatusEnum.PENDENTE_LIMITE);
    	when(cartaoDockRepository.findById(any(Long.class))).thenReturn(Optional.ofNullable(cartao));

        mockMvc.perform(patch(STATUS_RESOURCE, 1)
        		.contentType("application/json")
                .content(CartaoStatusEnum.BLOQUEADO.toString()))
                .andDo(print())
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.tituloErro", is("Erro status")))
                .andExpect(jsonPath("$.msgErro", is("Cartão com status diferente de ATIVO não pode ser BLOQUEADO")));
    }
    
    @Test
    @WithMockUserPamcard
    public void alterarStatusComErro() throws Exception {
    	
    	CartaoDock cartao = gerarCartaoDock();
    	when(cartaoDockRepository.findById(any(Long.class))).thenReturn(Optional.ofNullable(cartao));

        mockMvc.perform(patch(STATUS_RESOURCE, 1)
        		.contentType("application/json")
                .content("Teste"))
                .andDo(print())
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.tituloErro", is("Erro status")))
                .andExpect(jsonPath("$.msgErro", is("Status diferente de ATIVO ou BLOQUEADO ou CANCELADO")));
    }
    
}

