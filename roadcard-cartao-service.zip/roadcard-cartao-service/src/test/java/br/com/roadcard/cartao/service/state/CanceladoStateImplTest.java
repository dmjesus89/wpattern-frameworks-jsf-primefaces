package br.com.roadcard.cartao.service.state;

import br.com.roadcard.cartao.exception.CartaoStatusException;
import br.com.roadcard.cartao.model.CartaoStatusEnum;
import br.com.roadcard.cartao.model.state.CartaoStatusState;
import br.com.roadcard.cartao.model.state.CartaoStatusStateFactory;
import br.com.roadcard.cartao.service.AbstractCartaoServiceTest;
import org.junit.Before;
import org.junit.Test;

public class CanceladoStateImplTest extends AbstractCartaoServiceTest {

    private CartaoStatusState stateImpl;

    @Before
    public void onStart() {
        stateImpl = CartaoStatusStateFactory.buscarStatePorStatus(CartaoStatusEnum.CANCELADO);
    }

    @Test(expected = CartaoStatusException.class)
    public void testDefinirCartaoProntoAtivacao() {
        stateImpl.definirCartaoProntoAtivacao();
    }

    @Test(expected = CartaoStatusException.class)
    public void testDefinirCartaoAtivo() {
        stateImpl.definirCartaoAtivo();
    }

    @Test(expected = CartaoStatusException.class)
    public void testDefinirCartaoBloqueado() {
        stateImpl.definirCartaoBloqueado();
    }

    @Test(expected = CartaoStatusException.class)
    public void testDefinirCartaoCancelado() {
        stateImpl.definirCartaoCancelado();
    }

}