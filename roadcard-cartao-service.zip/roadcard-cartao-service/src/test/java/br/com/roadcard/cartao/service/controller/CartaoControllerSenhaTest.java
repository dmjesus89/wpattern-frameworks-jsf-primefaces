package br.com.roadcard.cartao.service.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Optional;

import org.junit.Test;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MvcResult;

import com.fasterxml.jackson.databind.ObjectMapper;

import br.com.roadcard.cartao.exception.UnprocessableEntityException;
import br.com.roadcard.cartao.model.CartaoDock;
import br.com.roadcard.cartao.model.CartaoStatusEnum;
import br.com.roadcard.cartao.model.dto.CadastrarSenhaDTO;
import br.com.roadcard.cartao.repository.CartaoDockRepository;
import br.com.roadcard.cartao.repository.CartaoRepository;
import br.com.roadcard.cartao.service.AbstractCartaoServiceTest;
import br.com.roadcard.dock.exception.ResourceNotFoundException;
import br.com.roadcard.pamcard.auth.test.context.support.WithMockUserPamcard;

public class CartaoControllerSenhaTest extends AbstractCartaoServiceTest {

	
    @MockBean
    private CartaoRepository cartaoRepository;
    @MockBean
    private CartaoDockRepository cartaoDockRepository;

    private final ObjectMapper mapper = new ObjectMapper();


    @Test
    @WithMockUserPamcard
    public void cadastrarSenha() throws Exception {
    	prepararMock_AutenticacaoDockClientGerarToken();
    	
    	
    	CadastrarSenhaDTO cadastrarSenhaDTO = new CadastrarSenhaDTO();
    	cadastrarSenhaDTO.setSenha("1234");
    	cadastrarSenhaDTO.setConfirmacaoSenha("1234");
    	
    	CartaoDock cartao = gerarCartaoDock();
    	cartao.setStatus(CartaoStatusEnum.PENDENTE_SENHA);
    	cartao.getProprietario().setCnpj("11111111111111");
        when(cartaoDockRepository.findById(any(Long.class))).thenReturn(Optional.ofNullable(cartao));
        
        prepararMockHistoricoCartaoTopicNotifier();

        mockMvc.perform(patch(SENHA_RESOURCE, 1)
        		.contentType("application/json")
                .content(mapper.writeValueAsString(cadastrarSenhaDTO)))
                .andDo(print())
                .andExpect(status().isNoContent());
        
        verify(cardDockClient, times(1)).cadastrarSenha(any(), any(), any());
    }
    
    @Test
    @WithMockUserPamcard
    public void alterarSenha() throws Exception {
    	prepararMock_AutenticacaoDockClientGerarToken();
    	
    	CadastrarSenhaDTO cadastrarSenhaDTO = new CadastrarSenhaDTO();
    	cadastrarSenhaDTO.setSenha("1234");
    	cadastrarSenhaDTO.setConfirmacaoSenha("1234");
    	
    	CartaoDock cartao = gerarCartaoDock();
    	cartao.setStatus(CartaoStatusEnum.ATIVO);
    	cartao.getProprietario().setCnpj("11111111111111");
        when(cartaoDockRepository.findById(any(Long.class))).thenReturn(Optional.ofNullable(cartao));
        
        prepararMockHistoricoCartaoTopicNotifier();

        mockMvc.perform(patch(ALTERAR_SENHA_RESOURCE, 1)
        		.contentType("application/json")
                .content(mapper.writeValueAsString(cadastrarSenhaDTO)))
                .andDo(print())
                .andExpect(status().isNoContent());
        
        verify(cardDockClient, times(1)).alterarSenha(any(), any(), any());
    }
    
    @Test
    @WithMockUserPamcard
    public void cadastrarSenhaErroIntegracao() throws Exception {
    	prepararMock_AutenticacaoDockClientGerarToken();
    	
    	CadastrarSenhaDTO cadastrarSenhaDTO = new CadastrarSenhaDTO();
    	cadastrarSenhaDTO.setSenha("1234");
    	cadastrarSenhaDTO.setConfirmacaoSenha("1234");
    	
    	CartaoDock cartao = gerarCartaoDock();
    	cartao.setStatus(CartaoStatusEnum.PENDENTE_SENHA);
    	cartao.getProprietario().setCnpj("11111111111111");
        when(cartaoDockRepository.findById(any(Long.class))).thenReturn(Optional.ofNullable(cartao));
        
        doThrow(new UnprocessableEntityException("Erro Integracao Mock", "Erro Integracao Mock"))
		.when(cardDockClient).cadastrarSenha(any(), any(), any());
    	
    	mockMvc.perform(patch(SENHA_RESOURCE, 1)
        		.contentType("application/json")
                .content(mapper.writeValueAsString(cadastrarSenhaDTO)))
                .andDo(print())
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.tituloErro", is("Erro Integração")))
                .andExpect(jsonPath("$.msgErro", is("Não foi possível realizar a operação no emissor.")));
    }
    
    @Test
    @WithMockUserPamcard
    public void alterarSenhaErroIntegracao() throws Exception {
    	prepararMock_AutenticacaoDockClientGerarToken();
    	
    	CadastrarSenhaDTO cadastrarSenhaDTO = new CadastrarSenhaDTO();
    	cadastrarSenhaDTO.setSenha("1234");
    	cadastrarSenhaDTO.setConfirmacaoSenha("1234");
    	
    	CartaoDock cartao = gerarCartaoDock();
    	cartao.setStatus(CartaoStatusEnum.BLOQUEADO);
    	cartao.getProprietario().setCnpj("11111111111111");
        when(cartaoDockRepository.findById(any(Long.class))).thenReturn(Optional.ofNullable(cartao));
        
        doThrow(new UnprocessableEntityException("Erro Integracao Mock", "Erro Integracao Mock"))
		.when(cardDockClient).alterarSenha(any(), any(), any());
    	
    	mockMvc.perform(patch(ALTERAR_SENHA_RESOURCE, 1)
        		.contentType("application/json")
                .content(mapper.writeValueAsString(cadastrarSenhaDTO)))
                .andDo(print())
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.tituloErro", is("Erro Integração")))
                .andExpect(jsonPath("$.msgErro", is("Não foi possível realizar a operação no emissor.")));
    }
    
    @Test
    @WithMockUserPamcard
    public void alterarSenhaComErroStatus() throws Exception {
    	
    	CadastrarSenhaDTO cadastrarSenhaDTO = new CadastrarSenhaDTO();
    	cadastrarSenhaDTO.setSenha("1234");
    	cadastrarSenhaDTO.setConfirmacaoSenha("1234");
    	
    	CartaoDock cartao = gerarCartaoDock();
    	cartao.setStatus(CartaoStatusEnum.CANCELADO);
    	cartao.getProprietario().setCnpj("11111111111111");
    	when(cartaoDockRepository.findById(any(Long.class))).thenReturn(Optional.ofNullable(cartao));

        mockMvc.perform(patch(ALTERAR_SENHA_RESOURCE, 1)
        		.contentType("application/json")
                .content(mapper.writeValueAsString(cadastrarSenhaDTO)))
                .andDo(print())
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.tituloErro", is("Erro status")))
                .andExpect(jsonPath("$.msgErro", is("Status atual do cartão não permiti realizar o processo de alteração de senha do cartão")));
    }
    
    @Test
    @WithMockUserPamcard
    public void cadastrarSenhaDivergentes() throws Exception {
    	
    	CadastrarSenhaDTO cadastrarSenhaDTO = new CadastrarSenhaDTO();
    	cadastrarSenhaDTO.setSenha("1234");
    	cadastrarSenhaDTO.setConfirmacaoSenha("1235");
    	
    	CartaoDock cartao = gerarCartaoDock();
    	cartao.setStatus(CartaoStatusEnum.PENDENTE_SENHA);
    	cartao.getProprietario().setCnpj("11111111111111");
    	when(cartaoDockRepository.findById(any(Long.class))).thenReturn(Optional.ofNullable(cartao));

        mockMvc.perform(patch(SENHA_RESOURCE, 1)
        		.contentType("application/json")
                .content(mapper.writeValueAsString(cadastrarSenhaDTO)))
                .andDo(print())
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.tituloErro", is("Erro senha")))
                .andExpect(jsonPath("$.msgErro", is("Senha e Confirmação Senha estão diferentes")));
    }
    
    @Test
    @WithMockUserPamcard
    public void cadastrarSenhaNotFound() throws Exception {
    	
    	CadastrarSenhaDTO cadastrarSenhaDTO = new CadastrarSenhaDTO();
    	cadastrarSenhaDTO.setSenha("1234");
    	cadastrarSenhaDTO.setConfirmacaoSenha("1234");
    	
    	when(cartaoDockRepository.findById(any(Long.class))).thenReturn(Optional.<CartaoDock>empty());

        MvcResult result = mockMvc.perform(patch(SENHA_RESOURCE, 1)
        		.contentType("application/json")
                .content(mapper.writeValueAsString(cadastrarSenhaDTO)))
                .andExpect(status().isNotFound()).andReturn();
        
        assertEquals(ResourceNotFoundException.class, result.getResolvedException().getClass());
    }
    
    @Test
    @WithMockUserPamcard
    public void cadastrarSenhaComErroProprietario() throws Exception {
    	
    	CadastrarSenhaDTO cadastrarSenhaDTO = new CadastrarSenhaDTO();
    	cadastrarSenhaDTO.setSenha("1234");
    	cadastrarSenhaDTO.setConfirmacaoSenha("1234");
    	
    	CartaoDock cartao = gerarCartaoDock();
    	cartao.setStatus(CartaoStatusEnum.PENDENTE_SENHA);
    	when(cartaoDockRepository.findById(any(Long.class))).thenReturn(Optional.ofNullable(cartao));

        mockMvc.perform(patch(SENHA_RESOURCE, 1)
        		.contentType("application/json")
                .content(mapper.writeValueAsString(cadastrarSenhaDTO)))
                .andDo(print())
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.tituloErro", is("Erro proprietário")))
                .andExpect(jsonPath("$.msgErro", is("Cartão não pertence ao proprietário")));
    }
    
    @Test
    @WithMockUserPamcard
    public void cadastrarSenhaComStatusDiferentePendenteSenha() throws Exception {
    	
    	CadastrarSenhaDTO cadastrarSenhaDTO = new CadastrarSenhaDTO();
    	cadastrarSenhaDTO.setSenha("1234");
    	cadastrarSenhaDTO.setConfirmacaoSenha("1234");
    	
    	CartaoDock cartao = gerarCartaoDock();
    	cartao.getProprietario().setCnpj("11111111111111");
    	when(cartaoDockRepository.findById(any(Long.class))).thenReturn(Optional.ofNullable(cartao));

        mockMvc.perform(patch(SENHA_RESOURCE, 1)
        		.contentType("application/json")
                .content(mapper.writeValueAsString(cadastrarSenhaDTO)))
                .andDo(print())
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.tituloErro", is("Erro status")))
                .andExpect(jsonPath("$.msgErro", is("Cartão com status diferente de pendente senha")));
    }
    
    @Test
    @WithMockUserPamcard
    public void cadastrarSenhaSemPortador() throws Exception {
    	
    	CadastrarSenhaDTO cadastrarSenhaDTO = new CadastrarSenhaDTO();
    	cadastrarSenhaDTO.setSenha("1234");
    	cadastrarSenhaDTO.setConfirmacaoSenha("1234");
    	
    	CartaoDock cartao = gerarCartaoDock();
    	cartao.setStatus(CartaoStatusEnum.PENDENTE_SENHA);
    	cartao.getProprietario().setCnpj("11111111111111");
    	cartao.setPortador(null);
    	when(cartaoDockRepository.findById(any(Long.class))).thenReturn(Optional.ofNullable(cartao));

        mockMvc.perform(patch(SENHA_RESOURCE, 1)
        		.contentType("application/json")
                .content(mapper.writeValueAsString(cadastrarSenhaDTO)))
                .andDo(print())
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.tituloErro", is("Erro portador")))
                .andExpect(jsonPath("$.msgErro", is("Cartão sem portador")));
    }


}

