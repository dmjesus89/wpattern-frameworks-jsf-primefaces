package br.com.roadcard.cartao.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.model.PublishRequest;
import com.amazonaws.services.sns.model.PublishResult;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import br.com.roadcard.cartao.client.ContaDockClient;
import br.com.roadcard.cartao.cognito.CognitoClient;
import br.com.roadcard.cartao.cognito.CognitoOperation;
import br.com.roadcard.cartao.cognito.CognitoResponse;
import br.com.roadcard.cartao.model.CartaoDock;
import br.com.roadcard.cartao.model.Portador;
import br.com.roadcard.cartao.model.Proprietario;
import br.com.roadcard.cartao.model.dto.SaldoDisponivelDTO;
import br.com.roadcard.cartao.repository.CartaoRepository;
import br.com.roadcard.cartao.repository.PortadorRepository;
import br.com.roadcard.dock.autenticacao.AutenticacaoDockClient;
import br.com.roadcard.dock.autenticacao.AutenticacaoDockResponse;
import br.com.roadcard.dock.cards.CardDockClient;
import br.com.roadcard.dock.cards.CartaoDockDTO;
import br.com.roadcard.dock.cards.CartaoDockListDTO;
import br.com.roadcard.dock.cards.LimiteCartaoDTO;
import br.com.roadcard.dock.cards.LimiteCartaoResponse;
import br.com.roadcard.dock.companies.CompanyDockClient;
import br.com.roadcard.dock.contas.ContasDockClient;
import br.com.roadcard.dock.individuals.IndividualDockClient;
import br.com.roadcard.dock.individuals.IndividualDockResponse;
import br.com.roadcard.pamcard.auth.model.Empresa;
import br.com.roadcard.pamcard.auth.model.Perfil;
import br.com.roadcard.pamcard.auth.model.TipoEmpresa;
import br.com.roadcard.pamcard.auth.model.login.PermissaoClienteServiceConstants;
import br.com.roadcard.pamcard.auth.model.login.PermissaoDespesasConstants;
import br.com.roadcard.pamcard.auth.model.login.UsuarioPamcardWeb;

@SpringBootTest
@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
public abstract class AbstractCartaoServiceTest {

    protected final String CARTAO_RESOURCE = "/api/cartoes";
    
    protected final String SENHA_RESOURCE = "/api/cartoes/{id}/senha";
    
    protected final String ALTERAR_SENHA_RESOURCE = "/api/cartoes/{id}/alterarSenha";
    
    protected final String STATUS_RESOURCE = "/api/cartoes/{id}/status";

    @MockBean
    protected CognitoClient cognitoClient;
    @Autowired
    protected MockMvc mockMvc;
    @MockBean
    protected CardDockClient cardDockClient;
    @MockBean
    protected ContaDockClient contaDockClient;
    @MockBean
    protected AutenticacaoDockClient autenticacaoDockClient;
    @MockBean
    protected IndividualDockClient individualDockClientMock;
    @MockBean
    protected ContasDockClient contasDockClientMock;
    @MockBean
    protected CompanyDockClient companyDockClientMock;
    @Autowired
    protected PortadorRepository portadorRepository;
    @Autowired
    protected CartaoRepository cartaoRepository;
    @MockBean
    protected IndividualDockResponse individualDockResponseMock;
    @MockBean
    protected AmazonSNS snsMock;
    @MockBean
    protected CognitoOperation cognitoOperation;
    
    
    
    protected final ObjectMapper mapper = new ObjectMapper();


    public CartaoDockListDTO prepararListaCartoes(){
        CartaoDockDTO cartao = gerarCartaoDockDTO();

        List<CartaoDockDTO> list = new ArrayList<>();
        list.add(cartao);

        CartaoDockListDTO cartaoListDTO = new CartaoDockListDTO();
        cartaoListDTO.setCartaoList(list);

        return cartaoListDTO;
    }

    public CartaoDockDTO gerarCartaoDockDTO() {
        CartaoDockDTO cartao = new CartaoDockDTO();
        cartao.setId(1L);
        cartao.setNumeroCartao("1234********4321");
        cartao.setNomeImpresso("JoaoDoCaminhao");
        return cartao;
    }
    
    public void prepararMock_consultarSaldoConta(int saldo) {
    	SaldoDisponivelDTO item = new SaldoDisponivelDTO(BigDecimal.valueOf(saldo));
    	when(contaDockClient.consultarSaldo(any(String.class), any(String.class))).thenReturn(item);
    }
    
    protected void prepararMock_snsAws() {
    	PublishResult requestRetorno = new PublishResult();
    	requestRetorno.setMessageId("303");
    	when(snsMock.publish(any(PublishRequest.class))).thenReturn(requestRetorno);
    }
    
    protected void prepararMock_cadastrarLimiteCartaoDock() {
    	LimiteCartaoResponse limiteCartaoResponse = new LimiteCartaoResponse();
    	limiteCartaoResponse.setId(10L);
    	when(cardDockClient.cadastrarLimiteCartao(any(String.class), any(Long.class), any(LimiteCartaoDTO.class))).thenReturn(limiteCartaoResponse);
    }
    
    protected void prepararMockHistoricoCartaoTopicNotifier()
			throws JsonProcessingException {
		PublishResult publishResult = new PublishResult();
		publishResult.setMessageId("123");
		when(snsMock.publish(ArgumentMatchers.any(PublishRequest.class)))
				.thenReturn(publishResult);

	}

    public Proprietario gerarProprietario() {
        Proprietario proprietario = new Proprietario();
        proprietario.setCnpj("123321");
        return proprietario;
    }

    public CartaoDock gerarCartaoDock(){
        Proprietario proprietario = new Proprietario();
        proprietario.setCnpj("123");
        
        Portador portador = new Portador();
        portador.setCpf("123");

        CartaoDock cartao = new CartaoDock();
        cartao.setIdCartao(1L);
        cartao.setIdCartaoIntegracao(1L);
        cartao.setNumeroCartao("1234********4321");
        cartao.setNomeImpresso("JoaoDoCaminhao");
        cartao.setProprietario(proprietario);
        cartao.setPortador(portador);
        return cartao;
    }

    public UsuarioPamcardWeb prepararUsuarioPamcard(){

        Empresa empresa = new Empresa();
        empresa.setCnpj("123");
        empresa.setTipoEmpresa(TipoEmpresa.CONTRATANTE);

        Perfil perfil = new Perfil();
        perfil.setEmpresa(empresa);

        UsuarioPamcardWeb usuarioPamcard = new UsuarioPamcardWeb();
        usuarioPamcard.setUsername("usuarioTest");
        usuarioPamcard.setPerfil(perfil);
        GrantedAuthority authority1 = new SimpleGrantedAuthority(PermissaoClienteServiceConstants.CLIENTE_ACESSO_TOTAL);
        GrantedAuthority authority2 = new SimpleGrantedAuthority(PermissaoDespesasConstants.APLICACAO_DESPESAS_ACESSO_TOTAL);
        List<GrantedAuthority> authorityList = new ArrayList<>();
        authorityList.add(authority1);
        authorityList.add(authority2);
        usuarioPamcard.setAuthorities(authorityList);

        return usuarioPamcard;
    }

    public Page<CartaoDock> prepararPageCartoesDock(){
        List<CartaoDock> cartoes = new ArrayList<>();
        cartoes.add(gerarCartaoDock());
        //PageRequest paginacao = PageRequest.of(1, 1, Sort.by("idCartao"));
        //Page<CartaoDock> cartoesPage = new PageImpl<>(cartoes, paginacao, cartoes.size());

        Page<CartaoDock> cartoesPage = new PageImpl<>(cartoes);
        return cartoesPage;
    }
    public List<CartaoDock> prepararListCartoesDock(){
        List<CartaoDock> cartoes = new ArrayList<>();
        cartoes.add(gerarCartaoDock());

        return cartoes;
    }
    
    public void prepararMock_AutenticacaoDockClientGerarToken() {
    	AutenticacaoDockResponse autenticacao = new AutenticacaoDockResponse();
    	autenticacao.setAccessToken("tokenAcesso");
    	when(autenticacaoDockClient.gerarToken()).thenReturn(autenticacao);
    }
    
    protected void prepararMock_gerarTokenValidoCognitoClient() {
    	CognitoResponse cognitoResponse = new CognitoResponse();
    	cognitoResponse.setToken("tokenClientValido");
    	ResponseEntity<CognitoResponse> item = new  ResponseEntity<CognitoResponse>(cognitoResponse, HttpStatus.OK);
    	when(cognitoClient.getToken(any(String.class), any(String.class), any(String.class), any(String.class))).thenReturn(item);
    }


}
