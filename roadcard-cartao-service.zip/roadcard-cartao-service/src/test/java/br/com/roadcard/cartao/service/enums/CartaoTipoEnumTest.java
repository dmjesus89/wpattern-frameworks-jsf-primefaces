package br.com.roadcard.cartao.service.enums;

import br.com.roadcard.cartao.model.CartaoModalidadeEnum;
import br.com.roadcard.cartao.model.CartaoTipoEnum;
import br.com.roadcard.cartao.service.AbstractCartaoServiceTest;
import br.com.roadcard.dock.exception.ResourceNotFoundException;
import org.junit.Test;

import static org.junit.Assert.*;

public class CartaoTipoEnumTest extends AbstractCartaoServiceTest {

    @Test
    public void testBuscarEnumNull() {
        assertTrue(CartaoTipoEnum.buscarEnum(null, null).isEmpty());
    }

    @Test
    public void testBuscarEnumSemEmissor() {
        assertTrue(CartaoTipoEnum.buscarEnum(null, CartaoModalidadeEnum.FROTA).isEmpty());
    }

    @Test
    public void testBuscarEnumSemModalidade() {
        assertTrue(CartaoTipoEnum.buscarEnum("Dock", null).isEmpty());
    }

    @Test
    public void testBuscarEnum() {
        assertSame(CartaoTipoEnum.DOCK_CORPORATIVO.getDescricao(), CartaoTipoEnum.buscarEnum("Dock", CartaoModalidadeEnum.FROTA));
    }

    @Test
    public void testBuscarEnum_porTipo(){
        assertSame(CartaoTipoEnum.DOCK_CORPORATIVO, CartaoTipoEnum.buscarEnum("CARTAO_DOCK_FROTA"));
    }
    @Test
    public void testBuscarEnum_porTipo_erroTipoNaoEncontrado(){
        try {
            CartaoTipoEnum.buscarEnum("");
            fail();
        } catch (Exception e) {
            assertEquals(ResourceNotFoundException.class, e.getClass());
        }
    }

}