package br.com.roadcard.cartao.service.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.junit.Test;

import com.amazonaws.services.sns.model.PublishRequest;

import br.com.roadcard.cartao.exception.UnprocessableEntityException;
import br.com.roadcard.cartao.model.AbstractCartao;
import br.com.roadcard.cartao.model.CartaoStatusEnum;
import br.com.roadcard.cartao.model.Portador;
import br.com.roadcard.cartao.model.dto.PortadorDTO;
import br.com.roadcard.cartao.service.AbstractCartaoServiceTest;
import br.com.roadcard.dock.companies.BaseCompanyRegisterDockResponse;
import br.com.roadcard.dock.companies.CompanyDockResponse;
import br.com.roadcard.dock.companies.CompanyRegisterDockResponse;
import br.com.roadcard.dock.contas.VincularCartaoRequest;
import br.com.roadcard.dock.contas.VincularPortadorCartaoRequest;
import br.com.roadcard.dock.individuals.BaseIndividualDockResponse;
import br.com.roadcard.dock.individuals.IndividualDockResponse;
import br.com.roadcard.dock.individuals.PhoneDockResponse;
import br.com.roadcard.pamcard.auth.test.context.support.WithMockUserPamcard;

public class VincularPortadorCartaoControllerTest extends AbstractCartaoServiceTest {

    protected final String PORTADOR = "/portador";
    
    //TODO descomentar teste quando concluir a correção do jsonb do portador
    @Test
    @WithMockUserPamcard
    public void vincularPortadorAoCartao_Sucesso() throws Exception {
    	prepararMock_AutenticacaoDockClientGerarToken();
    	prepararMock_getPortadorPorCpf(true);
    	prepararMock_getCompanyDockClient(true);
    	prepararMock_snsAws();
    	
        mockMvc.perform(patch(CARTAO_RESOURCE+"/9999999"+PORTADOR)
                        .contentType("application/json")
                        .content(mapper.writeValueAsString(prepararPortadorDTO("31189447061")))
                )
                .andDo(print())
                .andExpect(status().isNoContent());

        
		List<Portador> listaPortador = portadorRepository.findByCpf("31189447061");
		assertFalse(CollectionUtils.isEmpty(listaPortador));
		assertEquals("Pedro", listaPortador.get(0).getNome());
		assertEquals(LocalDate.parse("2010-11-12"), listaPortador.get(0).getDataNascimento());
		assertEquals("071", listaPortador.get(0).getDados().getDddTelefone());
		assertEquals("992229292", listaPortador.get(0).getDados().getTelefoneCelular());
		assertEquals("pedro@email.com", listaPortador.get(0).getDados().getEmail());
		assertNull(listaPortador.get(0).getDados().getNumeroRg());
		assertEquals("SP", listaPortador.get(0).getDados().getUfEmissorRg());
		assertEquals("Joana", listaPortador.get(0).getDados().getNomeMae());
		
		
		Optional<AbstractCartao> cartao = cartaoRepository.findById(9999999L);
		assertFalse(ObjectUtils.isEmpty(cartao));
		assertEquals(CartaoStatusEnum.PENDENTE_SENHA, cartao.get().getStatus());
		assertEquals("user", cartao.get().getUsuarioSolicitante());
		assertEquals(listaPortador.get(0).getCpf(), cartao.get().getPortador().getCpf());
		assertEquals(listaPortador.get(0).getNome(), cartao.get().getPortador().getNome());
		assertEquals(listaPortador.get(0).getDataNascimento(), cartao.get().getPortador().getDataNascimento());
		
        
        verify(contasDockClientMock, times(1)).adicionarPortadorParaContaContratante(anyString(), any(Integer.class), any(VincularPortadorCartaoRequest.class));
        verify(contasDockClientMock, times(1)).vincularCartaoNaContaCooperada(any(), any(), any(VincularCartaoRequest.class));
        verify(snsMock, times(2)).publish(any(PublishRequest.class));
    }
    
    
    @Test
    @WithMockUserPamcard
    public void vincularPortadorAoCartao_vincularCartaoNaContaCooperada_ErroIntegracao() throws Exception {
    	prepararMock_AutenticacaoDockClientGerarToken();
    	prepararMock_getPortadorPorCpf(true);
    	prepararMock_getCompanyDockClient(true);
    	
    	doThrow(new UnprocessableEntityException("Erro Integracao Mock", "Erro Integracao Mock"))
    			.when(contasDockClientMock).vincularCartaoNaContaCooperada(any(), any(), any(VincularCartaoRequest.class));

    	
        mockMvc.perform(patch(CARTAO_RESOURCE+"/9999999"+PORTADOR)
                        .contentType("application/json")
                        .content(mapper.writeValueAsString(prepararPortadorDTO("31189447061")))
                )
                .andDo(print())
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.tituloErro", is("Erro Integração")))
                .andExpect(jsonPath("$.msgErro", is("Não foi possível realizar a operação no emissor.")));
        
        verify(contasDockClientMock, times(1)).adicionarPortadorParaContaContratante(anyString(), any(Integer.class), any(VincularPortadorCartaoRequest.class));
    }
    
    @Test
    @WithMockUserPamcard
    public void vincularPortadorAoCartao_adicionarPortadorParaContaContratante_ErroIntegracao() throws Exception {
    	prepararMock_AutenticacaoDockClientGerarToken();
    	prepararMock_getPortadorPorCpf(true);
    	prepararMock_getCompanyDockClient(true);
    	
    	doThrow(new UnprocessableEntityException("Erro Integracao Mock", "Erro Integracao Mock"))
    				.when(contasDockClientMock).adicionarPortadorParaContaContratante(any(), any(), any());
    	
        mockMvc.perform(patch(CARTAO_RESOURCE+"/9999999"+PORTADOR)
                        .contentType("application/json")
                        .content(mapper.writeValueAsString(prepararPortadorDTO("31189447061")))
                )
                .andDo(print())
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.tituloErro", is("Erro Integração")))
                .andExpect(jsonPath("$.msgErro", is("Não foi possível realizar a operação no emissor.")));
    }
    
    
    @Test
    @WithMockUserPamcard
    public void vincularPortadorAoCartao_buscarIdContaPorCnpjDock_SemStatusACTIVE_SemIdRegistration_erro() throws Exception {
    	prepararMock_AutenticacaoDockClientGerarToken();
    	prepararMock_getPortadorPorCpf(true);
    	prepararMock_getCompanyDockClient(false);
    	
    	
        mockMvc.perform(patch(CARTAO_RESOURCE+"/9999999"+PORTADOR)
                        .contentType("application/json")
                        .content(mapper.writeValueAsString(prepararPortadorDTO("31189447061")))
                )
                .andDo(print())
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.tituloErro", is("Recurso não encontrado.")))
                .andExpect(jsonPath("$.msgErro", is("Empresa não encontrada")));
    }
    
    @Test
    @WithMockUserPamcard
    public void vincularPortadorAoCartao_buscarIdContaPorCnpjDock_ErroIntegracao() throws Exception {
    	prepararMock_AutenticacaoDockClientGerarToken();
    	prepararMock_getPortadorPorCpf(true);
    	when(companyDockClientMock.getRegistroEmpresaPorCnpj(anyString(), anyString())).thenThrow(new UnprocessableEntityException("Erro Integracao Mock", "Erro Integracao Mock"));
    	
        mockMvc.perform(patch(CARTAO_RESOURCE+"/9999999"+PORTADOR)
                        .contentType("application/json")
                        .content(mapper.writeValueAsString(prepararPortadorDTO("31189447061")))
                )
                .andDo(print())
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.tituloErro", is("Erro Integração")))
                .andExpect(jsonPath("$.msgErro", is("Não foi possível realizar a operação no emissor.")));

    }
    
    @Test
    @WithMockUserPamcard
    public void vincularPortadorAoCartao_BuscarPortadorPorCpfDock_PortadorNaoEncotradoErro_baseIndividualDockResponseListaVazia() throws Exception {
    	prepararMock_AutenticacaoDockClientGerarToken();
    	prepararMock_getPortadorPorCpf(false);
    	
        mockMvc.perform(patch(CARTAO_RESOURCE+"/9797979"+PORTADOR)
                        .contentType("application/json")
                        .content(mapper.writeValueAsString(prepararPortadorDTO("85145711093")))
                )
                .andDo(print())
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.tituloErro", is("Recurso não encontrado.")))
                .andExpect(jsonPath("$.msgErro", is("Motorista não possui cadastro. Por favor informa-lo a criar uma conta pelo aplicativo Pambank")));
    }
    
    @Test
    @WithMockUserPamcard
    public void vincularPortadorAoCartao_BuscarPortadorPorCpfDock_PortadorNaoEncotradoErro_baseIndividualDockResponseNulo() throws Exception {
    	prepararMock_AutenticacaoDockClientGerarToken();
    	
        mockMvc.perform(patch(CARTAO_RESOURCE+"/9999999"+PORTADOR)
                        .contentType("application/json")
                        .content(mapper.writeValueAsString(prepararPortadorDTO("31189447061")))
                )
                .andDo(print())
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.tituloErro", is("Recurso não encontrado.")))
                .andExpect(jsonPath("$.msgErro", is("Motorista não possui cadastro. Por favor informa-lo a criar uma conta pelo aplicativo Pambank")));
    }
    
    
    @Test
    @WithMockUserPamcard
    public void vincularPortadorAoCartao_BuscarPortadorPorCpfDock_erroIntegracao () throws Exception {
    	prepararMock_AutenticacaoDockClientGerarToken();
    	when(individualDockClientMock.getPortadorPorCpf(anyString(), anyString())).thenThrow(new UnprocessableEntityException("Erro Integracao Mock", "Erro Integracao Mock"));
    	
        mockMvc.perform(patch(CARTAO_RESOURCE+"/9999999"+PORTADOR)
                        .contentType("application/json")
                        .content(mapper.writeValueAsString(prepararPortadorDTO("31189447061")))
                )
                .andDo(print())
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.tituloErro", is("Erro Integração")))
                .andExpect(jsonPath("$.msgErro", is("Não foi possível realizar a operação no emissor.")));
    }
    
    
    @Test
    @WithMockUserPamcard
    public void vincularPortadorAoCartao_obterCartaoPendenteVinculacaoSemPortador_ErroCartaoNaoEncontrado () throws Exception {
    	
        mockMvc.perform(patch(CARTAO_RESOURCE+"/000"+PORTADOR)
                        .contentType("application/json")
                        .content(mapper.writeValueAsString(prepararPortadorDTO("31189447061")))
                )
                .andDo(print())
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.tituloErro", is("Cartão não encontrado.")))
                .andExpect(jsonPath("$.msgErro", is("Cartão não encontrado. Por favor informe outro cartão.")));
    }
    
    @Test
    @WithMockUserPamcard
    public void vincularPortadorAoCartao_obterCartaoPendenteVinculacaoSemPortador_ErroCartaoStatusDiferentePendente () throws Exception {
    	
        mockMvc.perform(patch(CARTAO_RESOURCE+"/808080"+PORTADOR)
                        .contentType("application/json")
                        .content(mapper.writeValueAsString(prepararPortadorDTO("31189447061")))
                )
                .andDo(print())
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.tituloErro", is("Ocorreu um erro de validação")))
                .andExpect(jsonPath("$.msgErro", is("Cartão não disponível para vínculo. Por favor informe outro cartão.")));
    }
    
    @Test
    @WithMockUserPamcard
    public void vincularPortadorAoCartao_obterCartaoPendenteVinculacaoSemPortador_ErroCartaoJaPossuiPortador () throws Exception {
    	
        mockMvc.perform(patch(CARTAO_RESOURCE+"/8888888"+PORTADOR)
                        .contentType("application/json")
                        .content(mapper.writeValueAsString(prepararPortadorDTO("31189447061")))
                )
                .andDo(print())
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.tituloErro", is("Ocorreu um erro de validação")))
                .andExpect(jsonPath("$.msgErro", is("Cartão já possui portador. Por favor informe outro cartão.")));
    }
    
    
    @Test
    @WithMockUserPamcard
    public void vincularPortadorAoCartao_ErroObterTokenAcessoDock() throws Exception {
    	
        mockMvc.perform(patch(CARTAO_RESOURCE+"/9797979"+PORTADOR)
                        .contentType("application/json")
                        .content(mapper.writeValueAsString(prepararPortadorDTO("39262102062")))
                )
                .andDo(print())
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.tituloErro", is("Erro Integração")))
                .andExpect(jsonPath("$.msgErro", is("Não foi possível realizar a operação no emissor.")));
    }
    
    @Test
    @WithMockUserPamcard
    public void vincularPortadorAoCartao_validarPortadorTemCartaoAtivo_ErroJaExisteCartaoAtivoVinculado() throws Exception {
    	
        mockMvc.perform(patch(CARTAO_RESOURCE+"/9999999"+PORTADOR)
                        .contentType("application/json")
                        .content(mapper.writeValueAsString(prepararPortadorDTO("43924999015")))
                )
                .andDo(print())
                .andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.msgErro", is("Já existe um cartão vinculado a esse usuário. Por favor informe um usuário diferente.")));

    }
    
    @Test
    @WithMockUserPamcard
    public void vincularPortadorAoCartao_cpfInvalido() throws Exception {
    	
        mockMvc.perform(patch(CARTAO_RESOURCE+"/9999999"+PORTADOR)
                        .contentType("application/json")
                        .content(mapper.writeValueAsString(prepararPortadorDTO("12345"))))
                .andDo(print())
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.msgErro", is("CPF informado inválido; ")));

    }
    

    private void prepararMock_getPortadorPorCpf(boolean comItens) {
    	BaseIndividualDockResponse baseIndividualDockResponse = new BaseIndividualDockResponse();
    	if(comItens) {
    		List<IndividualDockResponse> listaItem = new ArrayList<IndividualDockResponse>();
    		IndividualDockResponse item = new IndividualDockResponse();
    		item.setId(99);
    		item.setDocument("31189447061");
    		item.setName("Pedro");
    		item.setBirthDate("2010-11-12");
    		item.setPhones(prepararListaPhoneDock());
    		item.setEmail("pedro@email.com");
    		item.setMotherName("Joana");
    		item.setIdentityIssuingEntity("SSP");
            item.setFederativeUnit("SP");
    		listaItem.add(item);
    		baseIndividualDockResponse.setItems(listaItem);
    	}
    	when(individualDockClientMock.getPortadorPorCpf(anyString(), anyString())).thenReturn(baseIndividualDockResponse);
    }
    
    private List<PhoneDockResponse> prepararListaPhoneDock() {
    	List<PhoneDockResponse> listaPhone = new ArrayList<PhoneDockResponse>();
		PhoneDockResponse phone = new PhoneDockResponse();
		phone.setDdd("071");
		phone.setId(1);
		phone.setTelefone("992229292");
		listaPhone.add(phone);
		return listaPhone;
    }
    
    
    private void prepararMock_getCompanyDockClient(boolean comItemValido) {
    	BaseCompanyRegisterDockResponse baseCompanyRegisterDockResponse = new BaseCompanyRegisterDockResponse();
    	List<CompanyRegisterDockResponse> listaItem = new ArrayList<CompanyRegisterDockResponse>();
		listaItem.add(prepararCompanyRegisterDockResponse("INATIVE", null));
    	listaItem.add(prepararCompanyRegisterDockResponse("ACTIVE", null));
    	if(comItemValido) {
    		listaItem.add(prepararCompanyRegisterDockResponse("ACTIVE", "9090"));
    	}
    
    	baseCompanyRegisterDockResponse.setResults(listaItem);
    	when(companyDockClientMock.getRegistroEmpresaPorCnpj(anyString(), anyString())).thenReturn(baseCompanyRegisterDockResponse);
    }
    
    private CompanyRegisterDockResponse prepararCompanyRegisterDockResponse (String status, String idRegistration) {
		CompanyRegisterDockResponse item = new CompanyRegisterDockResponse();
		item.setStatus(status);
		item.setIdRegistration(idRegistration);
		CompanyDockResponse company = new CompanyDockResponse();
		company.setIdAccount(12345);
		item.setCompany(company);
		return item;
    }
 
    private PortadorDTO prepararPortadorDTO(String cpf) {
    	PortadorDTO portadorDTO = new PortadorDTO(cpf);
    	return portadorDTO;
    }

}
