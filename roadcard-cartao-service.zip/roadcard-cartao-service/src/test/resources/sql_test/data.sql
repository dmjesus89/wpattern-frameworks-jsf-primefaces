INSERT INTO cartao.portador (cpf, nome, data_nascimento , dados )
VALUES ('00100200340', 'vinicius', '1997-02-05', null );

INSERT INTO cartao.proprietario (cnpj)
VALUES(25467197000102);

INSERT INTO cartao.cartao (
id_cartao ,
id_cartao_integracao ,
flag_titular ,
id_pessoa ,
sequencial_cartao ,
id_conta ,
id_status ,
data_status ,
id_estagio ,
data_estagio ,
numero_bin ,
numero_cartao ,
numero_cartao_hash ,
numero_cartao_criptografado ,
data_emissao ,
data_validade ,
cartao_virtual ,
impressao_avulsa ,
data_impressao ,
nome_arquivo_impressao ,
id_produto ,
nome_impresso ,
codigo_desbloqueio ,
data_hora_ativacao ,
data_hora_cadastro ,
data_hora_atualizacao ,
data_hora_cancelamento ,
data_hora_bloqueio ,
data_hora_desbloqueio ,
data_hora_cadastro_senha ,
data_hora_alteracao_senha,
emissor ,
modalidade ,
portador ,
proprietario ,
quatro_ultimos_digitos ,
status ,
usuario_solicitante
)
VALUES(
115,
11,
1,
12,
114321,
1,
1,
null,
1,
null,
111111,
'1111********1111',
192837465,
'numerocriptografado',
'2021-06-01 15:39:00.000',
'2021-06-01 15:39:00.000',
0,
99,
null,
'arquivoImpressao',
100,
'vinicius',
77,
null,
'2021-06-01 15:39:00.000',
'2021-06-01 15:39:00.000',
'2021-06-01 15:39:00.000',
null,
null,
null,
null,
'Dock',
'FROTA',
'00100200340',
'25467197000102',
'1111',
'PENDENTE_VINCULACAO',
'vinicius'
);

--buscarCartoes

INSERT INTO cartao.proprietario (cnpj)
VALUES('00000000000014');

INSERT INTO cartao.cartao (
id_cartao ,
id_cartao_integracao ,
flag_titular ,
id_pessoa ,
sequencial_cartao ,
id_conta ,
id_status ,
data_status ,
id_estagio ,
data_estagio ,
numero_bin ,
numero_cartao ,
numero_cartao_hash ,
numero_cartao_criptografado ,
data_emissao ,
data_validade ,
cartao_virtual ,
impressao_avulsa ,
data_impressao ,
nome_arquivo_impressao ,
id_produto ,
nome_impresso ,
codigo_desbloqueio ,
data_hora_ativacao ,
data_hora_cadastro ,
data_hora_atualizacao ,
data_hora_cancelamento ,
data_hora_bloqueio ,
data_hora_desbloqueio ,
data_hora_cadastro_senha ,
data_hora_alteracao_senha,
emissor ,
modalidade ,
portador ,
proprietario ,
quatro_ultimos_digitos ,
status ,
usuario_solicitante
)
VALUES(
281,
281,
1,
12,
114321,
1,
1,
null,
1,
null,
111111,
'1111********4321',
192837465,
'numerocriptografado',
'2021-06-01 15:39:00.000',
'2021-06-01 15:39:00.000',
0,
99,
null,
'arquivoImpressao',
100,
'testBuscarCartoes',
77,
null,
'2021-06-01 15:39:00.000',
'2022-07-10 15:39:00.000',
'2021-06-01 15:39:00.000',
null,
null,
null,
null,
'Dock',
'FROTA',
'00100200340',
'00000000000014',
'4321',
'ATIVO',
'vinicius'
);

INSERT INTO cartao.portador (cpf, nome, data_nascimento , dados )
VALUES ('00100200341', 'vinicius2', '1997-02-05', null );


INSERT INTO cartao.cartao (
id_cartao ,
id_cartao_integracao ,
flag_titular ,
id_pessoa ,
sequencial_cartao ,
id_conta ,
id_status ,
data_status ,
id_estagio ,
data_estagio ,
numero_bin ,
numero_cartao ,
numero_cartao_hash ,
numero_cartao_criptografado ,
data_emissao ,
data_validade ,
cartao_virtual ,
impressao_avulsa ,
data_impressao ,
nome_arquivo_impressao ,
id_produto ,
nome_impresso ,
codigo_desbloqueio ,
data_hora_ativacao ,
data_hora_cadastro ,
data_hora_atualizacao ,
data_hora_cancelamento ,
data_hora_bloqueio ,
data_hora_desbloqueio ,
data_hora_cadastro_senha ,
data_hora_alteracao_senha,
emissor ,
modalidade ,
portador ,
proprietario ,
quatro_ultimos_digitos ,
status ,
usuario_solicitante
)
VALUES(
282,
282,
1,
12,
114321,
1,
1,
null,
1,
null,
111111,
'1111********1111',
192837465,
'numerocriptografado',
'2021-06-01 15:39:00.000',
'2021-06-01 15:39:00.000',
0,
99,
null,
'arquivoImpressao',
100,
'unicoComEsseCPFeCNPJ',
77,
null,
'2021-06-01 15:39:00.000',
'2022-07-10 15:39:00.000',
'2025-05-05 00:00:00.000',
null,
null,
null,
null,
'Dock',
'FROTA',
'00100200341',
'00000000000014',
'1111',
'PENDENTE_VINCULACAO',
'vinicius'
);

/*Inicio Cartao e Limite teste cadastrarLimite */

	/*Cartão com status PENDENTE_LIMITE para sucesso*/
	INSERT INTO cartao.proprietario (cnpj)
		VALUES('62006491000135');
	INSERT INTO cartao.cartao (id_cartao, id_cartao_integracao, flag_titular, id_pessoa, sequencial_cartao, id_conta, id_status, data_status, id_estagio, data_estagio, numero_bin, numero_cartao, numero_cartao_hash, numero_cartao_criptografado, data_emissao, data_validade, cartao_virtual, impressao_avulsa, data_impressao, nome_arquivo_impressao, id_produto, nome_impresso, codigo_desbloqueio, data_hora_ativacao, data_hora_cadastro, data_hora_atualizacao, data_hora_cancelamento, data_hora_bloqueio, data_hora_desbloqueio, data_hora_cadastro_senha, data_hora_alteracao_senha, emissor, modalidade, portador, proprietario, quatro_ultimos_digitos, status, usuario_solicitante)
		VALUES(299, 18, 1, 4, 1, 25, 2, '2021-06-01 15:39:00.000', 12, '2021-06-15 14:44:00.000', 426065, '9992********9904', -8555886439283701003, '08DD2B02154338795F88E65275357689', '2021-06-01 15:39:00.000', '2026-06-30 00:00:00.000', 0, NULL, NULL, NULL, 1, 'ROADCARD', '9565', NULL, '2022-07-01 23:45:35.282', '2022-07-25 15:08:55.277', NULL, NULL, NULL, '2022-07-05 16:29:42.246', NULL, 'Dock', 'FROTA', NULL, '62006491000135', '9904', 'PENDENTE_LIMITE', 'pauloh_trp13');

	/*Cartão com status PENDENTE_LIMITE*/
	INSERT INTO cartao.proprietario (cnpj)
		VALUES('90687877000195');
	INSERT INTO cartao.cartao (id_cartao, id_cartao_integracao, flag_titular, id_pessoa, sequencial_cartao, id_conta, id_status, data_status, id_estagio, data_estagio, numero_bin, numero_cartao, numero_cartao_hash, numero_cartao_criptografado, data_emissao, data_validade, cartao_virtual, impressao_avulsa, data_impressao, nome_arquivo_impressao, id_produto, nome_impresso, codigo_desbloqueio, data_hora_ativacao, data_hora_cadastro, data_hora_atualizacao, data_hora_cancelamento, data_hora_bloqueio, data_hora_desbloqueio, data_hora_cadastro_senha, data_hora_alteracao_senha, emissor, modalidade, portador, proprietario, quatro_ultimos_digitos, status, usuario_solicitante)
		VALUES(250, 17, 1, 4, 1, 25, 2, '2021-06-01 15:39:00.000', 12, '2021-06-15 14:44:00.000', 426065, '9992********9904', -8555886439283701003, '08DD2B02154338795F88E65275357689', '2021-06-01 15:39:00.000', '2026-06-30 00:00:00.000', 0, NULL, NULL, NULL, 1, 'ROADCARD', '9565', NULL, '2022-07-01 23:45:35.282', '2022-07-25 15:08:55.277', NULL, NULL, NULL, '2022-07-05 16:29:42.246', NULL, 'Dock', 'FROTA', NULL, '90687877000195', '9904', 'PENDENTE_LIMITE', 'pauloh_trp13');


	/*Cartão com limite ja cadastrado e status PENDENTE_LIMITE*/
	INSERT INTO cartao.proprietario (cnpj)
		VALUES('74480593000177');
	INSERT INTO cartao.cartao (id_cartao, id_cartao_integracao, flag_titular, id_pessoa, sequencial_cartao, id_conta, id_status, data_status, id_estagio, data_estagio, numero_bin, numero_cartao, numero_cartao_hash, numero_cartao_criptografado, data_emissao, data_validade, cartao_virtual, impressao_avulsa, data_impressao, nome_arquivo_impressao, id_produto, nome_impresso, codigo_desbloqueio, data_hora_ativacao, data_hora_cadastro, data_hora_atualizacao, data_hora_cancelamento, data_hora_bloqueio, data_hora_desbloqueio, data_hora_cadastro_senha, data_hora_alteracao_senha, emissor, modalidade, portador, proprietario, quatro_ultimos_digitos, status, usuario_solicitante)
		VALUES(240, 16, 1, 4, 1, 25, 2, '2021-06-01 15:39:00.000', 12, '2021-06-15 14:44:00.000', 426065, '9992********9904', -8555886439283701003, '08DD2B02154338795F88E65275357689', '2021-06-01 15:39:00.000', '2026-06-30 00:00:00.000', 0, NULL, NULL, NULL, 1, 'ROADCARD', '9565', NULL, '2022-07-01 23:45:35.282', '2022-07-25 15:08:55.277', NULL, NULL, NULL, '2022-07-05 16:29:42.246', NULL, 'Dock', 'FROTA', NULL, '74480593000177', '9904', 'PENDENTE_LIMITE', 'pauloh_trp13');
	INSERT INTO cartao.limite_cartao (id, id_cartao, id_limite_integracao, limite_diario, limite_semanal, limite_mensal, proprietario, limite_ativo, data_hora_cadastro)
		VALUES(2, 240, 1, 50, 100, 200, '74480593000177', true, '2022-07-25 15:09:08.663');


	/*Cartão com limite ja cadastrado e status PRONTO_ATIVACAO*/
	INSERT INTO cartao.proprietario (cnpj)
		VALUES('00001001000312');
	INSERT INTO cartao.cartao (id_cartao, id_cartao_integracao, flag_titular, id_pessoa, sequencial_cartao, id_conta, id_status, data_status, id_estagio, data_estagio, numero_bin, numero_cartao, numero_cartao_hash, numero_cartao_criptografado, data_emissao, data_validade, cartao_virtual, impressao_avulsa, data_impressao, nome_arquivo_impressao, id_produto, nome_impresso, codigo_desbloqueio, data_hora_ativacao, data_hora_cadastro, data_hora_atualizacao, data_hora_cancelamento, data_hora_bloqueio, data_hora_desbloqueio, data_hora_cadastro_senha, data_hora_alteracao_senha, emissor, modalidade, portador, proprietario, quatro_ultimos_digitos, status, usuario_solicitante)
		VALUES(200, 15, 1, 4, 1, 25, 2, '2021-06-01 15:39:00.000', 12, '2021-06-15 14:44:00.000', 426065, '9992********9904', -8555886439283701003, '08DD2B02154338795F88E65275357689', '2021-06-01 15:39:00.000', '2026-06-30 00:00:00.000', 0, NULL, NULL, NULL, 1, 'ROADCARD', '9565', NULL, '2022-07-01 23:45:35.282', '2022-07-25 15:08:55.277', NULL, NULL, NULL, '2022-07-05 16:29:42.246', NULL, 'Dock', 'FROTA', NULL, '00001001000312', '9904', 'PRONTO_ATIVACAO', 'pauloh_trp13');
	INSERT INTO cartao.limite_cartao (id, id_cartao, id_limite_integracao,  limite_diario, limite_semanal, limite_mensal, proprietario, limite_ativo, data_hora_cadastro)
		VALUES(1, 200, 2, 1234, 1234, 1234, '00001001000312', true, '2022-07-25 15:09:08.663');




/*Fim Cartao e Limite teste cadastrarLimite */



/*Cartao e Proprietario teste vincularPortadorAoCartao */
	INSERT INTO cartao.proprietario (cnpj)
		VALUES('11111111111111');
	/*Cartao sem portador para Salvar*/
	INSERT INTO cartao.cartao (id_cartao ,id_cartao_integracao,flag_titular ,id_pessoa ,sequencial_cartao ,id_conta ,id_status ,data_status ,id_estagio ,data_estagio ,numero_bin ,numero_cartao ,numero_cartao_hash ,numero_cartao_criptografado ,data_emissao ,data_validade ,cartao_virtual ,impressao_avulsa ,data_impressao ,nome_arquivo_impressao ,id_produto ,nome_impresso ,codigo_desbloqueio ,data_hora_ativacao ,data_hora_cadastro ,data_hora_atualizacao ,data_hora_cancelamento ,data_hora_bloqueio ,data_hora_desbloqueio ,data_hora_cadastro_senha ,data_hora_alteracao_senha,emissor ,modalidade ,proprietario ,quatro_ultimos_digitos ,status ,usuario_solicitante)
		VALUES(9999999,9999999,1,12,114321,1,7,null,1,null,111111,'1212********1212',192837465,'numerocriptografado','2021-06-01 15:39:00.000','2021-01-01 15:39:00.000',0,99,null,'arquivoImpressao',100,'unicoComEsseCPFeCNPJ',77,null,'2021-06-01 15:39:00.000','2022-07-10 15:39:00.000','2024-04-04 00:00:00.000',null,null,null,null,'Dock','FROTA','11111111111111',1212,'PENDENTE_VINCULACAO','Joao');
	
	/*Cartao sem portador para teste de exception*/
	INSERT INTO cartao.cartao (id_cartao ,id_cartao_integracao,flag_titular ,id_pessoa ,sequencial_cartao ,id_conta ,id_status ,data_status ,id_estagio ,data_estagio ,numero_bin ,numero_cartao ,numero_cartao_hash ,numero_cartao_criptografado ,data_emissao ,data_validade ,cartao_virtual ,impressao_avulsa ,data_impressao ,nome_arquivo_impressao ,id_produto ,nome_impresso ,codigo_desbloqueio ,data_hora_ativacao ,data_hora_cadastro ,data_hora_atualizacao ,data_hora_cancelamento ,data_hora_bloqueio ,data_hora_desbloqueio ,data_hora_cadastro_senha ,data_hora_alteracao_senha,emissor ,modalidade ,proprietario ,quatro_ultimos_digitos ,status ,usuario_solicitante)
		VALUES(9797979,9797979,1,12,114321,1,7,null,1,null,111111,'1212********1212',192837465,'numerocriptografado','2021-06-01 15:39:00.000','2021-01-01 15:39:00.000',0,99,null,'arquivoImpressao',100,'unicoComEsseCPFeCNPJ',77,null,'2021-06-01 15:39:00.000','2022-07-10 15:39:00.000','2024-04-04 00:00:00.000',null,null,null,null,'Dock','FROTA','11111111111111',1212,'PENDENTE_VINCULACAO','Joao');
	

	/*Cartao com portador*/
	INSERT INTO cartao.portador (cpf, nome, data_nascimento , dados )
		VALUES ('43924999015', 'Maria', '1990-01-01', null );
	INSERT INTO cartao.cartao (id_cartao ,id_cartao_integracao, portador, flag_titular ,id_pessoa ,sequencial_cartao ,id_conta ,id_status ,data_status ,id_estagio ,data_estagio ,numero_bin ,numero_cartao ,numero_cartao_hash ,numero_cartao_criptografado ,data_emissao ,data_validade ,cartao_virtual ,impressao_avulsa ,data_impressao ,nome_arquivo_impressao ,id_produto ,nome_impresso ,codigo_desbloqueio ,data_hora_ativacao ,data_hora_cadastro ,data_hora_atualizacao ,data_hora_cancelamento ,data_hora_bloqueio ,data_hora_desbloqueio ,data_hora_cadastro_senha ,data_hora_alteracao_senha,emissor ,modalidade ,proprietario ,quatro_ultimos_digitos ,status ,usuario_solicitante)
		VALUES(8888888,8888888,'43924999015',1,12,114321,1,7,null,1,null,111111,'1313********1313',192837465,'numerocriptografado','2021-06-01 15:39:00.000','2021-01-01 15:39:00.000',0,99,null,'arquivoImpressao',100,'unicoComEsseCPFeCNPJ',77,null,'2021-06-01 15:39:00.000','2022-07-10 15:39:00.000','2024-04-04 00:00:00.000',null,null,null,null,'Dock','FROTA','11111111111111',1313,'PENDENTE_VINCULACAO','Joao');
	
	/*Cartao status diferente de pendente_vinculacao*/
	INSERT INTO cartao.cartao (id_cartao ,id_cartao_integracao, flag_titular ,id_pessoa ,sequencial_cartao ,id_conta ,id_status ,data_status ,id_estagio ,data_estagio ,numero_bin ,numero_cartao ,numero_cartao_hash ,numero_cartao_criptografado ,data_emissao ,data_validade ,cartao_virtual ,impressao_avulsa ,data_impressao ,nome_arquivo_impressao ,id_produto ,nome_impresso ,codigo_desbloqueio ,data_hora_ativacao ,data_hora_cadastro ,data_hora_atualizacao ,data_hora_cancelamento ,data_hora_bloqueio ,data_hora_desbloqueio ,data_hora_cadastro_senha ,data_hora_alteracao_senha,emissor ,modalidade ,proprietario ,quatro_ultimos_digitos ,status ,usuario_solicitante)
		VALUES(808080,808080,1,12,114321,1,2,null,1,null,111111,'1313********1313',192837465,'numerocriptografado','2021-06-01 15:39:00.000','2021-01-01 15:39:00.000',0,99,null,'arquivoImpressao',100,'unicoComEsseCPFeCNPJ',77,null,'2021-06-01 15:39:00.000','2022-07-10 15:39:00.000','2024-04-04 00:00:00.000',null,null,null,null,'Dock','FROTA','11111111111111',1313,'ATIVO','Joao');
	




