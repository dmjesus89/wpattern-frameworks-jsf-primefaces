package br.com.roadcard.cartao.model.state;

import br.com.roadcard.cartao.model.CartaoStatusEnum;

public class PendenteVinculacaoStateImpl implements CartaoStatusState {

    private static final long serialVersionUID = -7407944441645974651L;

    @Override
    public CartaoStatusEnum definirCartaoPendenteSenha() {
        return CartaoStatusEnum.PENDENTE_SENHA;
    }


    @Override
    public CartaoStatusEnum definirCartaoCancelado() {
        return CartaoStatusEnum.CANCELADO;
    }
}


