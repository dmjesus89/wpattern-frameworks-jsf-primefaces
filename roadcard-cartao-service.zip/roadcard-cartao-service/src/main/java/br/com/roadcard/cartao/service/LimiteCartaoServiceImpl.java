package br.com.roadcard.cartao.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.roadcard.cartao.client.ContaDockClient;
import br.com.roadcard.cartao.exception.UnprocessableEntityException;
import br.com.roadcard.cartao.model.AbstractCartao;
import br.com.roadcard.cartao.model.LimiteCartao;
import br.com.roadcard.cartao.model.dto.LimiteDTO;
import br.com.roadcard.cartao.model.dto.SaldoDisponivelDTO;
import br.com.roadcard.cartao.repository.LimiteCartaoRepository;
import br.com.roadcard.cartao.service.interfaces.CartaoService;
import br.com.roadcard.cartao.service.interfaces.CognitoService;
import br.com.roadcard.cartao.service.interfaces.IntegradorDockService;
import br.com.roadcard.cartao.service.interfaces.LimiteCartaoService;
import br.com.roadcard.cartao.service.interfaces.ProprietarioService;
import br.com.roadcard.dock.cards.LimiteCartaoResponse;
import br.com.roadcard.pamcard.auth.model.login.UsuarioPamcard;
import br.com.roadcard.pamcard.auth.utils.UsernamePasswordAuthenticationTokenUtils;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@Getter
@Service
public class LimiteCartaoServiceImpl implements LimiteCartaoService {

    private final IntegradorDockService integradorDockService;
    private final CartaoService cartaoService;
    private final LimiteCartaoRepository limiteCartaoRepository;
    private final ModelMapper modelMapper;
    private final ProprietarioService proprietarioService;
    private final ContaDockClient contaDockClient;
    private final CognitoService cognitoService;


    @Autowired
    public LimiteCartaoServiceImpl(IntegradorDockService integradorDockService, CartaoService cartaoService, 
    					LimiteCartaoRepository limiteCartaoRepository, ModelMapper modelMapper, ProprietarioService proprietarioService, ContaDockClient contaDockClient, CognitoService cognitoService) {
        this.integradorDockService = integradorDockService;
		this.cartaoService = cartaoService;
		this.limiteCartaoRepository = limiteCartaoRepository;
		this.modelMapper = modelMapper;
		this.proprietarioService = proprietarioService;
		this.contaDockClient = contaDockClient;
		this.cognitoService = cognitoService;
    }


	@Override
	public void cadastrarLimite(UsuarioPamcard usuarioPamcard, LimiteDTO limiteDTO, Long idCartao) {
		 String cnpj = UsernamePasswordAuthenticationTokenUtils.extrairCnpjProprietario(usuarioPamcard);
	     
	     AbstractCartao cartao = getCartaoService().obterCartaoPendenteLimite(idCartao, cnpj);
	     
	     validarLimitesCartoesComSaldoContratante(cnpj, limiteDTO);
	     LimiteCartaoResponse limiteCartaoResponse = getIntegradorDockService().cadastrarLimiteCartao(limiteDTO, idCartao);
	     salvarLimite(limiteDTO, cnpj, cartao, limiteCartaoResponse);
		 AbstractCartao cartaoSalvo = getCartaoService().atualizarCartaoComStatusProntoAtivacao(cartao, usuarioPamcard.getUsername());
	     getCartaoService().notificarHistoricoCartao(cartaoSalvo, null, cartaoSalvo.getStatus(), true, usuarioPamcard.getUsername(), cnpj);
	     getCartaoService().notificarLog(cartaoSalvo, null, cartaoSalvo.getStatus(), usuarioPamcard.getUsername());
	}
	

	private LimiteCartao salvarLimite(LimiteDTO limiteDTO, String cnpj, AbstractCartao cartaoSalvo, LimiteCartaoResponse limiteCartaoResponse) {
		LimiteCartao limiteCartao = getModelMapper().map(limiteDTO, LimiteCartao.class);
		limiteCartao.setProprietario(cnpj);
		limiteCartao.setIdCartao(cartaoSalvo.getIdCartao());
		limiteCartao.setDataHoraCadastro(LocalDateTime.now());
		limiteCartao.setLimiteAtivo(Boolean.TRUE);
		limiteCartao.setIdLimiteIntegracao(limiteCartaoResponse.getId());
		return getLimiteCartaoRepository().save(limiteCartao);
	}


	private void validarLimitesCartoesComSaldoContratante(String cnpj, LimiteDTO limiteDTO) {
		BigDecimal somatorio = getLimiteCartaoRepository().somatorioLimitesAtivosPorProprietario(cnpj);
		
		if(somatorio != null) {
			
			somatorio = somatorio.add(limiteDTO.getLimiteMensal());
			
			SaldoDisponivelDTO saldoContratanteDTO = obterSaldoDisponivelPeloCnpj(cnpj);
			
			if(somatorio.compareTo(saldoContratanteDTO.getSaldoDisponivelGlobal()) == 1) {
				log.info("LimiteCartaoServiceImpl.validarLimitesCartoesComSaldoContratante: O somatorio dos limites é maior que o saldo da contratante. Limite: "+limiteDTO);
				throw new UnprocessableEntityException("error.msg.limite.maior.saldo","error.msg.validation");
			}
		}
	}
	
	private SaldoDisponivelDTO obterSaldoDisponivelPeloCnpj(String cnpj) {
		SaldoDisponivelDTO saldoContratanteDTO = new SaldoDisponivelDTO();
		try {
			saldoContratanteDTO = getContaDockClient().consultarSaldo(getCognitoService().getToken(), cnpj);
		} catch (Exception e) {
            log.error("LimiteCartaoImpl: Erro ao buscar o saldo do contratante", e);
            throw new UnprocessableEntityException("error.msg.operacao.emissor", "error.msg.erro.integracao", e);
        }
		return saldoContratanteDTO;
	}
	
}
