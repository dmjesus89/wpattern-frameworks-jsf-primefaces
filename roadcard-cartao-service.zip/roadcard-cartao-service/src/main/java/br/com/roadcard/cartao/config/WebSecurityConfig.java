package br.com.roadcard.cartao.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

import br.com.roadcard.pamcard.auth.config.AbstractAuthWebSecurityConfig;
import br.com.roadcard.pamcard.auth.filter.JwtAuthFilter;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class WebSecurityConfig extends AbstractAuthWebSecurityConfig {
	
	public WebSecurityConfig(JwtAuthFilter authFilter) {
		super(authFilter);
	}

}
