package br.com.roadcard.cartao.model.dto;

import br.com.roadcard.cartao.validation.QuantidadeCaracteres;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;

@Getter
@Setter
@ApiModel
public class CadastrarCartaoDTO {
    private static final long serialVersionUID = -8436887652644135859L;

    @NotBlank
    @ApiModelProperty(required = true)
    @QuantidadeCaracteres(quantidade = 16)
    private String numeroCartao;

}
