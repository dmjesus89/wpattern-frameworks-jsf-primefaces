package br.com.roadcard.cartao.service.interfaces;

import br.com.roadcard.cartao.model.dto.LimiteDTO;
import br.com.roadcard.pamcard.auth.model.login.UsuarioPamcard;

public interface LimiteCartaoService {
  
	void cadastrarLimite(UsuarioPamcard usuarioPamcard, LimiteDTO limiteDTO, Long idCartao);
}
