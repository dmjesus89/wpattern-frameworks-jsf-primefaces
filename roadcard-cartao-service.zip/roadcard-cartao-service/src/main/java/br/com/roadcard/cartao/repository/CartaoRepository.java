package br.com.roadcard.cartao.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.roadcard.cartao.model.AbstractCartao;
import br.com.roadcard.cartao.model.CartaoDock;

@Repository
public interface CartaoRepository extends JpaRepository<AbstractCartao, Long> {

    Optional<CartaoDock> findByIdCartaoIntegracao(Long idCartaoIntegracao);
    
    Optional<List<AbstractCartao>> findByPortadorCpf(String cpf);

	Optional<AbstractCartao> findByIdCartaoAndProprietarioCnpj(Long idCartao, String cnpj);
}