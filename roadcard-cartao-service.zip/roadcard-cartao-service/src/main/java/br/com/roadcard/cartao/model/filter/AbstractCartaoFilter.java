package br.com.roadcard.cartao.model.filter;

import br.com.pamcary.pamcard.data.repository.utils.SearchableField;
import br.com.roadcard.cartao.model.CartaoModalidadeEnum;
import br.com.roadcard.cartao.model.CartaoStatusEnum;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

@Builder
@Data
public class AbstractCartaoFilter implements Serializable {
    private static final long serialVersionUID = -6377233420998831214L;

    @SearchableField(field = "portador.cpf")
    private String cpf;

    @SearchableField
    private CartaoStatusEnum status;

    @SearchableField
    private CartaoModalidadeEnum modalidade;

    @SearchableField
    private String emissor;

    @SearchableField
    private String quatroUltimosDigitos;

    @SearchableField(field = "portador.nome")
    private String nomePortador;

    @SearchableField(field = "proprietario.cnpj")
    private String proprietario;

    @SearchableField
    private Long idCartao;

}