package br.com.roadcard.cartao.model.state;

import br.com.roadcard.cartao.model.CartaoStatusEnum;

public class ProntoAtivacaoStateImpl implements CartaoStatusState {

    private static final long serialVersionUID = -5149724131575713167L;

    @Override
    public CartaoStatusEnum definirCartaoAtivo() {
        return CartaoStatusEnum.ATIVO;
    }

    @Override
    public CartaoStatusEnum definirCartaoCancelado() {
        return CartaoStatusEnum.CANCELADO;
    }

}