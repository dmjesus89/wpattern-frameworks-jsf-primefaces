package br.com.roadcard.cartao.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ApiModel
public class Proprietario implements Serializable {

    private static final long serialVersionUID = -5251155190183009795L;

    @Id
    private String cnpj;

}
