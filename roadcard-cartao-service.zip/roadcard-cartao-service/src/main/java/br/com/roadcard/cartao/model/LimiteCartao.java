package br.com.roadcard.cartao.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import io.swagger.annotations.ApiModel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@ApiModel
public class LimiteCartao implements Serializable {

	private static final long serialVersionUID = -4035449026263480436L;

	@Id
	@GeneratedValue(
	        strategy = GenerationType.SEQUENCE,
	        generator = "limite_cartao_id_seq"
	)
	@SequenceGenerator(
	        name = "limite_cartao_id_seq",
	        sequenceName = "limite_cartao_id_seq",
	        allocationSize = 1
	)
	private Long id;

    @Column(nullable = false)
    private Long idCartao;

    @Column(nullable = false)
    private Long idLimiteIntegracao;

    @Column(nullable = false)
    private BigDecimal limiteDiario;
    
    @Column(nullable = false)
    private BigDecimal limiteSemanal;
    
    @Column(nullable = false)
    private BigDecimal limiteMensal;
    
    @Column(nullable = false)
    private String proprietario;
    
    @Column(nullable = false)
    private Boolean limiteAtivo;
    
    @Column(nullable = false)
    private LocalDateTime dataHoraCadastro;

}