package br.com.roadcard.cartao.model.dto;

import java.io.Serializable;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class HistoricoVinculadoPortadorDTO implements Serializable{

	
	private static final long serialVersionUID = 6953246636785357043L;

	private String nome;
	private String cpf;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate dataNascimento;
	private String dddTelefoneCelular;
	private String telefoneCelular;
	private String email;
	private String nomeMae;
	private String numeroRG;
	private String ufEmissorRG;
	private Integer id;
	
	
	

}
