package br.com.roadcard.cartao.model.state;

import br.com.roadcard.cartao.exception.CartaoStatusException;
import br.com.roadcard.cartao.model.CartaoStatusEnum;
import br.com.roadcard.cartao.model.dto.AbstractCartaoDTO;
import br.com.roadcard.cartao.model.dto.NovoStatusCartaoDTO;

import java.io.Serializable;

public interface CartaoStatusState extends Serializable {

    default CartaoStatusEnum definirCartaoPendenteVinculacao() {
        throw new CartaoStatusException(
                this.formatarMensagemException(CartaoStatusEnum.PENDENTE_VINCULACAO)
        );
    }

    default CartaoStatusEnum definirCartaoPendenteSenha() {
        throw new CartaoStatusException(
                this.formatarMensagemException(CartaoStatusEnum.PENDENTE_SENHA)
        );
    }

    default CartaoStatusEnum definirCartaoPendenteLimite() {
        throw new CartaoStatusException(
                this.formatarMensagemException(CartaoStatusEnum.PENDENTE_LIMITE)
        );
    }

    default CartaoStatusEnum definirCartaoProntoAtivacao() {
        throw new CartaoStatusException(
                this.formatarMensagemException(CartaoStatusEnum.PRONTO_ATIVACAO)
        );
    }

    default CartaoStatusEnum definirCartaoAtivo() {
        throw new CartaoStatusException(
                this.formatarMensagemException(CartaoStatusEnum.ATIVO)
        );
    }

    default CartaoStatusEnum definirCartaoBloqueado() {
        throw new CartaoStatusException(
                this.formatarMensagemException(CartaoStatusEnum.BLOQUEADO)
        );
    }

    default CartaoStatusEnum definirCartaoCancelado() {
        throw new CartaoStatusException(
                this.formatarMensagemException(CartaoStatusEnum.CANCELADO)
        );
    }

    default String formatarMensagemException(CartaoStatusEnum proxima) {
        return "Não é possível alterar status para " + proxima.getDescricao();
    }

    default CartaoStatusEnum validarProximoStatus(NovoStatusCartaoDTO novoStatus, AbstractCartaoDTO cartao) {
        CartaoStatusEnum proximo = null;
        switch (novoStatus.getStatus()) {
            case PENDENTE_VINCULACAO:
                proximo = cartao.getState().definirCartaoPendenteVinculacao();
                break;
            case PENDENTE_LIMITE:
                proximo = cartao.getState().definirCartaoPendenteLimite();
                break;
            case PENDENTE_SENHA:
                proximo = cartao.getState().definirCartaoPendenteSenha();
                break;
            case PRONTO_ATIVACAO:
                proximo = cartao.getState().definirCartaoProntoAtivacao();
                break;
            case ATIVO:
                proximo = cartao.getState().definirCartaoAtivo();
                break;
            case BLOQUEADO:
                proximo = cartao.getState().definirCartaoBloqueado();
                break;
            case CANCELADO:
                proximo = cartao.getState().definirCartaoCancelado();
                break;
            default:
                throw new CartaoStatusException("Não foi possível alterar o cartão, Status inválido.");
        }
        return proximo;
    }

}