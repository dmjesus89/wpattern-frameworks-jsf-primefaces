package br.com.roadcard.cartao.cognito;

import java.io.UnsupportedEncodingException;
import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import br.com.roadcard.cartao.exception.CognitoException;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;


@Service
@Getter
@Slf4j
public class CognitoOperation {
	
	private final String chave;
	
	private final String segredo;
	
	private final String contentType;
	
	private final String grantType;
	
	private static final String CHARSET = "UTF-8";
	
	private final CognitoClient cognitoClient;
	
	@Autowired
	public CognitoOperation(
			@Value("${cognito.client.chave}") final String chave,
			@Value("${cognito.client.segredo}") final String segredo,
			@Value("${cognito.client.contentType}") final String contentType,
			@Value("${cognito.client.grantType}") final String grantType,
			final CognitoClient cognitoClient) {
		this.chave = chave;
		this.segredo = segredo;
		this.contentType = contentType;
		this.grantType = grantType;
		this.cognitoClient = cognitoClient;
	}

	public String getToken() {
		try {
			String cognitoKey = getChave().concat(":").concat(getSegredo());
			CognitoResponse cognito = 
					getCognitoClient().getToken("Basic ".concat(Base64.getEncoder().encodeToString(cognitoKey.getBytes(CHARSET))), 
							contentType, grantType, CognitoScope.MOVIMENTACAO_CARTAO.getId()).getBody();
			return cognito.getType().concat(" ").concat(cognito.getToken());
		} catch (UnsupportedEncodingException e) {
			log.error("Ocorreu um erro ao gerar o token para o cognito: ", e);
			throw new CognitoException(e);
		}
		
	}
	
}
