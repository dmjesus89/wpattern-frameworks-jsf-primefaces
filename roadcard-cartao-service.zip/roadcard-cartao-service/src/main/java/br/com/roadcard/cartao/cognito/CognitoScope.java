package br.com.roadcard.cartao.cognito;

public enum CognitoScope {

	MOVIMENTACAO_CARTAO("movimentacao_cartao%2Ffull");

	private String id;

	CognitoScope(String id) {
		this.id = id;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	 
}
