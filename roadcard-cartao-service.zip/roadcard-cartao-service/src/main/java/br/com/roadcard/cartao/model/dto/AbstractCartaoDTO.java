package br.com.roadcard.cartao.model.dto;

import br.com.roadcard.cartao.model.CartaoModalidadeEnum;
import br.com.roadcard.cartao.model.CartaoStatusEnum;
import br.com.roadcard.cartao.model.Portador;
import br.com.roadcard.cartao.model.Proprietario;
import br.com.roadcard.cartao.model.state.CartaoStatusState;
import br.com.roadcard.cartao.model.state.CartaoStatusStateFactory;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Set;

@Data
@NoArgsConstructor
public class AbstractCartaoDTO {

    private Long idCartao;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT-3")
    private LocalDateTime dataHoraAtivacao;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT-3")
    private LocalDateTime dataHoraCadastro;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT-3")
    private LocalDateTime dataHoraAtualizacao;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT-3")
    private LocalDateTime dataHoraCancelamento;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT-3")
    private LocalDateTime dataHoraBloqueio;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT-3")
    private LocalDateTime dataHoraDesbloqueio;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT-3")
    private LocalDateTime dataHoraCadastroSenha;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT-3")
    private LocalDateTime dataHoraAlteracaoSenha;

    private String emissor;

    private CartaoModalidadeEnum modalidade;

    private Portador portador;

    private Proprietario proprietario;

    private String quatroUltimosDigitos;

    private CartaoStatusEnum status;

    private String usuarioSolicitante;


    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Set<SimpleDTO> operacoesDisponiveis;

    @JsonIgnore
    public CartaoStatusState getState() {
        return CartaoStatusStateFactory.buscarStatePorStatus(status);
    }


}
