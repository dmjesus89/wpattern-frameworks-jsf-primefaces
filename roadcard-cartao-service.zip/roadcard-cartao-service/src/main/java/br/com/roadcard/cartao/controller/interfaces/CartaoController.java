package br.com.roadcard.cartao.controller.interfaces;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import br.com.roadcard.cartao.model.dto.AbstractCartaoDTO;
import br.com.roadcard.cartao.model.dto.CadastrarCartaoDTO;
import br.com.roadcard.cartao.model.dto.CadastrarSenhaDTO;
import br.com.roadcard.cartao.model.dto.LimiteDTO;
import br.com.roadcard.cartao.model.dto.PortadorDTO;
import br.com.roadcard.cartao.model.dto.SimpleDTO;
import br.com.roadcard.dock.exception.ResourceNotFoundException;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

public interface CartaoController {

    @ApiOperation(
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE,
            protocols = "http",
            value = "Serviço responsável por cadastrar os cartões.",
            notes = "Método POST."
    )
    @ApiResponses(
            value = {
                    @ApiResponse(code = 201, message = ""),
                    @ApiResponse(code = 400, message = "Número cartão deve ter 16 caracteres."),
                    @ApiResponse(code = 422, message = "O número do cartão inserido não foi encontrado."),
                    @ApiResponse(code = 422, message = "Não foi possível realizar a operação no emissor."),
                    @ApiResponse(code = 422, message = "O número desse cartão já foi inserido.")
            }
    )
    ResponseEntity<AbstractCartaoDTO> cadastrarCartao(UsernamePasswordAuthenticationToken token, CadastrarCartaoDTO cadastrarCartaoDTO);

	@ApiOperation(
			consumes = MediaType.APPLICATION_JSON_VALUE,
			produces = MediaType.APPLICATION_JSON_VALUE,
			protocols = "http",
			value = "Serviço responsável por cadastrar limite."
	)
	@ApiResponses(
			value = {
					@ApiResponse(code = 201, message = ""),
					@ApiResponse(code = 400, message = ""),
					@ApiResponse(code = 422, message = "")
			}
	)
	void cadastrarLimite(UsernamePasswordAuthenticationToken token, @Valid LimiteDTO limiteDTO, Long idCartao);


    @ApiOperation(
            produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
            protocols = "http",
            value = "Serviço responsável por obter os status do cartão.",
            notes = "Método GET."
    )
    @ApiResponses(
            value = {
                    @ApiResponse(code = 200, message = "")
            }
    )
    ResponseEntity<List<SimpleDTO>> carregarStatus(UsernamePasswordAuthenticationToken token);




    @ApiOperation(
            produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
            protocols = "http",
            value = "Serviço de consulta/acompanhamento de cartões por listagem.",
            notes = "Método GET."
            + "\t Retorno paginável ou não, definido por parametro 'paginado' com valor default = true."
    )
    @ApiResponses(
            value = {
                    @ApiResponse(code = 200, message = ""),
                    @ApiResponse(code = 400, message = "CPF inválido."),
                    @ApiResponse(code = 400, message = "Campo quatro digitos inválido."),
                    @ApiResponse(code = 400, message = "Campo quatro digitos deve ter 4 dígitos.")
            }
    )
    ResponseEntity<?> buscarCartoes(UsernamePasswordAuthenticationToken token,
                                    @RequestParam(value = "paginado", defaultValue = "true", required = true) boolean paginado,
									@RequestHeader(value ="filtros", required = false) Map<String, String> filtroHeader,
                                    @RequestParam(value = "pagina", defaultValue = "0", required = false) int pagina,
                                    @RequestParam(value = "tamanho", defaultValue = "10", required = false) int tamanho,
                                    @RequestParam(value = "colunaOrdenacao", defaultValue = "idCartao", required = false) String colunaOrdenacao,
                                    @ApiParam(hidden = true) String accept) throws Exception;




    @ApiOperation(
            produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
            protocols = "http",
            value = "Consulta informações de um cartão por id.",
            notes = "Método GET."
    )
    @ApiResponses(
            value = {
                    @ApiResponse(code = 200, message = ""),
                    @ApiResponse(code = 404, message = "Cartão com o id {} não encontrado.", response = ResourceNotFoundException.class)
            }
    )
    AbstractCartaoDTO buscarPorId(UsernamePasswordAuthenticationToken token, Long id);

    
    @ApiOperation(
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE,
            protocols = "http",
            value = "Serviço responsável vincular portador ao cartão."
    )
    @ApiResponses(
            value = {
                    @ApiResponse(code = 204, message = "Portador vinculado com sucesso."),
                    @ApiResponse(code = 422, message = "Erro na validação da regra de negócio.")
            }
    )
	void vincularPortadorAoCartao(UsernamePasswordAuthenticationToken token, @PathVariable("idCartao") Long idCartao, @RequestBody @Valid PortadorDTO portadorDTO);

	@ApiOperation(
			consumes = MediaType.APPLICATION_JSON_VALUE,
			produces = MediaType.APPLICATION_JSON_VALUE,
			protocols = "http",
			value = "Serviço responsável por cadastrar a senha."
	)
	@ApiResponses(
			value = {
					@ApiResponse(code = 201, message = ""),
					@ApiResponse(code = 400, message = "A senha deve ter 4 caracteres."),
					@ApiResponse(code = 422, message = "Não foi possível realizar a operação no emissor.")
			}
	)
	void cadastrarSenha(UsernamePasswordAuthenticationToken token, CadastrarSenhaDTO cadastrarSenhaDTO, Long idCartao);

	@ApiOperation(
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE,
            protocols = "http",
            value = "Serviço responsável por alterar o status do cartão."
    )
    @ApiResponses(
            value = {
                    @ApiResponse(code = 204, message = "Alteração de status com sucesso."),
                    @ApiResponse(code = 422, message = "Erro na validação da regra de negócio.")
            }
    )
	void alterarStatus(UsernamePasswordAuthenticationToken token, String status, Long idCartao);



	@ApiOperation(
			consumes = MediaType.APPLICATION_JSON_VALUE,
			produces = MediaType.APPLICATION_JSON_VALUE,
			protocols = "http",
			value = "Serviço responsável por alterar a senha."
	)
	@ApiResponses(
			value = {
					@ApiResponse(code = 201, message = ""),
					@ApiResponse(code = 400, message = "A senha deve ter 4 caracteres."),
					@ApiResponse(code = 422, message = "Não foi possível realizar a operação no emissor.")
			}
	)
	void alterarSenha(UsernamePasswordAuthenticationToken token, CadastrarSenhaDTO cadastrarSenhaDTO, Long idCartao);
}
