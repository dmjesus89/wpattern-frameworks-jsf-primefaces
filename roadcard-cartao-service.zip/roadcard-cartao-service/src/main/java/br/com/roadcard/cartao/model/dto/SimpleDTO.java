package br.com.roadcard.cartao.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class SimpleDTO implements Serializable {

    private static final long serialVersionUID = 7074808157493048860L;

    private String id;

    private String descricao;

    public SimpleDTO(String id, String descricao) {
        super();
        this.id = id;
        this.descricao = descricao;
    }

}
