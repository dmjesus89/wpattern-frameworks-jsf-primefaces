package br.com.roadcard.cartao.service;

import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import br.com.roadcard.cartao.cognito.CognitoClient;
import br.com.roadcard.cartao.cognito.CognitoResponse;
import br.com.roadcard.cartao.exception.CognitoException;
import br.com.roadcard.cartao.service.interfaces.CognitoService;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Service
@Getter
@Slf4j 
public class CognitoServiceImpl implements CognitoService {

    private final String chave;
    private final String segredo;
    private final String contentType;
    private final String grantType;
    private static final String CHARSET = "UTF-8";
    private static final String ROOT_SCOPE = "root%2Ffull";
    private final CognitoClient cognitoClient;

    @Autowired
    public CognitoServiceImpl(
            @Value("${cognito.client.chave}") final String chave,
            @Value("${cognito.client.segredo}") final String segredo,
            @Value("${cognito.client.contentType}") final String contentType,
            @Value("${cognito.client.grantType}") final String grantType,
            final CognitoClient cognitoClient) {
        this.chave = chave;
        this.segredo = segredo;
        this.contentType = contentType;
        this.grantType = grantType;
        this.cognitoClient = cognitoClient;
    }

    public String getToken() {
        try {
            String cognitoKey = getChave().concat(":").concat(getSegredo());
            CognitoResponse cognito = getCognitoClient().getToken("Basic ".concat(Base64.getEncoder().encodeToString(cognitoKey.getBytes(CHARSET))),
                            contentType, grantType, ROOT_SCOPE).getBody();
            return cognito.getToken();
        } catch (Exception e) {
            log.error("Ocorreu um erro ao gerar o token para o cognito: ", e);
            throw new CognitoException(e);
        }
    }



}