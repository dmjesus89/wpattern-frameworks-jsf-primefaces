package br.com.roadcard.cartao.config;

import java.util.Arrays;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;

import br.com.roadcard.pamcard.auth.utils.UsernamePasswordAuthenticationTokenUtils;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class SwaggerConfig extends WebMvcConfigurationSupport {

	@Bean
	public Docket api() {
		ParameterBuilder parameterBuilder = new ParameterBuilder();
		parameterBuilder.name("Authorization").modelRef(new ModelRef("string")).parameterType("header").required(true);
		ParameterBuilder parameterBuilder2 = new ParameterBuilder();
		parameterBuilder2.name("idToken").modelRef(new ModelRef("string")).parameterType("header").required(true);
		return new Docket(DocumentationType.SWAGGER_2)
				.ignoredParameterTypes(UsernamePasswordAuthenticationTokenUtils.class)
				.ignoredParameterTypes(UsernamePasswordAuthenticationToken.class)
				.globalOperationParameters(Arrays.asList(parameterBuilder.build(), parameterBuilder2.build())).select()
				.apis(RequestHandlerSelectors.basePackage("br.com.roadcard")).paths(PathSelectors.any()).build()
				.apiInfo(apinfo());
	}

	private ApiInfo apinfo() {
		return new ApiInfoBuilder().title("API para gerenciamento de cartão")
				.description("Rest API para gerenciamento de cartão ")
				.version("2.0.0").license("Apache License Version 2.0")
				.contact(new Contact("RoadCard",
						"https://www1.roadcard.com.br/contratante/", "sac.pamcard@roadcard.com.br"))
				.build();
	}

	@Override
	protected void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("swagger-ui.html").addResourceLocations("classpath:/META-INF/resources/");
		registry.addResourceHandler("/webjars/**").addResourceLocations("classpath:/META-INF/resources/webjars/");
	}

}
