package br.com.roadcard.cartao.service;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.StringJoiner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import br.com.roadcard.cartao.exception.CartaoFiltroException;
import br.com.roadcard.cartao.exception.UnprocessableEntityException;
import br.com.roadcard.cartao.model.AbstractCartao;
import br.com.roadcard.cartao.model.CartaoDock;
import br.com.roadcard.cartao.model.CartaoStatusEnum;
import br.com.roadcard.cartao.model.CartaoTipoEnum;
import br.com.roadcard.cartao.model.Portador;
import br.com.roadcard.cartao.model.Proprietario;
import br.com.roadcard.cartao.model.dto.AbstractCartaoDTO;
import br.com.roadcard.cartao.model.dto.CartaoDockIntegradorDTO;
import br.com.roadcard.cartao.model.dto.HistoricoCartaoDTO;
import br.com.roadcard.cartao.model.dto.PortadorDTO;
import br.com.roadcard.cartao.model.dto.SimpleDTO;
import br.com.roadcard.cartao.model.filter.AbstractCartaoFilter;
import br.com.roadcard.cartao.model.state.CartaoStatusState;
import br.com.roadcard.cartao.model.state.CartaoStatusStateFactory;
import br.com.roadcard.cartao.repository.CartaoDockRepository;
import br.com.roadcard.cartao.repository.CartaoRepository;
import br.com.roadcard.cartao.service.interfaces.CartaoService;
import br.com.roadcard.cartao.service.interfaces.IntegradorDockService;
import br.com.roadcard.cartao.service.interfaces.PortadorService;
import br.com.roadcard.cartao.service.interfaces.ProprietarioService;
import br.com.roadcard.cartao.service.notifier.GenericTopicNotifier;
import br.com.roadcard.dock.exception.ResourceNotFoundException;
import br.com.roadcard.geracao.log.model.AcaoEnum;
import br.com.roadcard.geracao.log.model.OperacaoLog;
import br.com.roadcard.geracao.log.service.NotificadorLog;
import br.com.roadcard.pamcard.auth.model.login.UsuarioPamcard;
import br.com.roadcard.pamcard.auth.utils.UsernamePasswordAuthenticationTokenUtils;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@Getter
@Service
public class CartaoServiceImpl implements CartaoService {

    private final CartaoRepository cartaoRepository;
    private final IntegradorDockService integradorDockService;
    private final ModelMapper modelMapper;
    private final CartaoDockRepository cartaoDockRepository;
    private final ProprietarioService proprietarioService;
    private final GenericTopicNotifier notifier;
    private final String historicoAlteracaoCartaoTopico;
    private final String historicoAlteracaoCartaoTitulo;
    private final PortadorService portadorService;
    private final NotificadorLog notificadorLog;
    private final ObjectMapper mapper;
    
    private final int CADASTRO = 1;
    private final int ALTERAR = 2;


    @Autowired
    public CartaoServiceImpl(CartaoRepository cartaoRepository,
                             IntegradorDockService integradorDockService,
                             ModelMapper modelMapper,
                             CartaoDockRepository cartaoDockRepository,
                             ProprietarioService proprietarioService,
                             GenericTopicNotifier notifier,
                             @Value("${aws.historicoAlteracaoCartaoTopico}") final String historicoAlteracaoCartaoTopico,
                             @Value("${aws.historicoAlteracaoCartaoTitulo}") final String historicoAlteracaoCartaoTitulo,
                             PortadorService portadorService,
                             NotificadorLog notificadorLog,
                             final ObjectMapper mapper) {
        this.cartaoRepository = cartaoRepository;
        this.integradorDockService = integradorDockService;
        this.modelMapper = modelMapper;
        this.cartaoDockRepository = cartaoDockRepository;
        this.proprietarioService = proprietarioService;
        this.notifier = notifier;
        this.historicoAlteracaoCartaoTopico = historicoAlteracaoCartaoTopico;
        this.historicoAlteracaoCartaoTitulo = historicoAlteracaoCartaoTitulo;
        this.portadorService = portadorService;
        this.notificadorLog = notificadorLog;
        this.mapper = mapper;
    }
	
	@Override
	public AbstractCartao atualizarCartaoComStatusProntoAtivacao(AbstractCartao cartao, String usuario) {
		cartao.setStatus(CartaoStatusEnum.PRONTO_ATIVACAO);
		cartao.setUsuarioSolicitante(usuario);
		cartao.setDataHoraAtualizacao(LocalDateTime.now());
		return getCartaoRepository().save(cartao);
	}
	
	@Override
	public AbstractCartao atualizarCartaoComPortador(AbstractCartao cartao, Portador portador) {
		cartao.setPortador(portador);
		cartao.setStatus(CartaoStatusEnum.PENDENTE_SENHA);
		return getCartaoRepository().save(cartao);
	}
	
	@Override
	public void validarPortadorTemCartaoAtivo(PortadorDTO portadorDTO) {
		List<AbstractCartao> listaCartao = getCartaoRepository().findByPortadorCpf(portadorDTO.getCpf()).orElse(new ArrayList<AbstractCartao>());
		 
		if(listaCartao.stream().filter(cartao -> !CartaoStatusEnum.CANCELADO.equals(cartao.getStatus())).findAny().isPresent()) {
			log.info("CartaoServiceImpl.validarPortadorTemCartaoAtivo: O portador ja possui um cartao ativo e vinculado. Portador: "+portadorDTO); 
			throw new UnprocessableEntityException("erro.msg.usuario.ja.tem.cartao.vinculado", "error.msg.validation");
		}
	}
	
	@Override
	public AbstractCartao obterCartaoPendenteVinculacaoSemPortador(Long idCartao, String cnpj){
		 Optional<AbstractCartao> optionalCartao = buscarCartaoPeloIdCartaoEProprietario(idCartao, cnpj);
		 
		 if(!CartaoStatusEnum.PENDENTE_VINCULACAO.equals(optionalCartao.get().getStatus())) {
			log.info("CartaoServiceImpl.obterCartaoPendenteVinculacao: O status do cartão não é PENDENTE_VINCULO. idCartao: "+idCartao);
			throw new UnprocessableEntityException("error.msg.cartao.nao.disponivel.vinculo", "error.msg.validation");
		 }
		 
		 if(ObjectUtils.isNotEmpty(optionalCartao.get().getPortador())) {
			log.info("CartaoServiceImpl.obterCartaoPendenteVinculacao: O cartao informado ja possui portador. idCartao: "+idCartao);
			throw new UnprocessableEntityException("error.msg.cartao.ja.possui.portador", "error.msg.validation");
		 }
		
		return optionalCartao.get();
	}
	
	@Override
	public AbstractCartao obterCartaoPendenteLimite(Long idCartao, String cnpj){
		 Optional<AbstractCartao> optionalCartao = buscarCartaoPeloIdCartaoEProprietario(idCartao, cnpj);
		 
		 if(!CartaoStatusEnum.PENDENTE_LIMITE.equals(optionalCartao.get().getStatus())) {
			log.info("CartaoServiceImpl.obterCartaoPendenteLimite: O status do cartão não é PENDENTE_LIMITE. Cartao: "+optionalCartao.get());
			throw new UnprocessableEntityException("error.msg.cartao.nao.disponivel.cadastro.limite", "error.msg.validation");
		 }
		 
		return optionalCartao.get();
	}


	private Optional<AbstractCartao> buscarCartaoPeloIdCartaoEProprietario(Long idCartao, String cnpj) {//cnpj = "00001001000312"
		Optional<AbstractCartao> optionalCartao = getCartaoRepository().findByIdCartaoAndProprietarioCnpj(idCartao, cnpj);
		 
		 if(!optionalCartao.isPresent()) {
			log.info("CartaoServiceImpl.obterCartaoPendenteVinculacao: O id do cartão não foi encontrado na base. idCartao: "+idCartao);
			throw new UnprocessableEntityException("error.msg.cartao.nao.encontrado.informe.outro","error.msg.cartao.notFound");
		 }
		return optionalCartao;
	}
	


    @Transactional
    @Override
    public AbstractCartaoDTO cadastrarCartao(String numeroCartao, UsuarioPamcard usuarioPamcard) {
        log.info("CartaoServiceImpl: Inicio de cadastrarCartao: {}", numeroCartao);

        CartaoDockIntegradorDTO cartaoDockIntegradorDTO = getIntegradorDockService().buscarInformacaoCartaoDock(numeroCartao);

        validarCartaoJaExiste(cartaoDockIntegradorDTO.getId());

        String cnpj = UsernamePasswordAuthenticationTokenUtils.extrairCnpjProprietario(usuarioPamcard);
        String usernamePamcard = usuarioPamcard.getUsername();

        cartaoDockIntegradorDTO.setQuatroUltimosDigitos(obterUltimosCaracteresString(cartaoDockIntegradorDTO.getNumeroCartao()));
        cartaoDockIntegradorDTO.setUsuarioSolicitante(usernamePamcard);
        cartaoDockIntegradorDTO.setProprietario(salvarProprietario(cnpj));
        LocalDateTime horaCadastro = LocalDateTime.now();
        cartaoDockIntegradorDTO.setDataHoraCadastro(horaCadastro);
        cartaoDockIntegradorDTO.setDataHoraAtualizacao(horaCadastro);

        mapperConfiguration();
        CartaoDock cartaoDock = getModelMapper().map(cartaoDockIntegradorDTO, CartaoDock.class);

        cartaoDock = getCartaoRepository().save(cartaoDock);

        notificarHistoricoCartao(cartaoDock, null, cartaoDock.getStatus(), true, usernamePamcard, cnpj);
        notificarLog(cartaoDock,null,CartaoStatusEnum.PENDENTE_VINCULACAO,usernamePamcard);

        log.info("CartaoServiceImpl: Fim de cadastrarCartao.");
        return getModelMapper().map(cartaoDock, CartaoDockIntegradorDTO.class);
    }


    protected void validarCartaoJaExiste(Long idCartaoIntegracao) {
        Optional<CartaoDock> cartao = cartaoRepository.findByIdCartaoIntegracao(idCartaoIntegracao);
        if (cartao.isPresent()) {
            log.error("CartaoServiceImpl: O número desse cartão já foi inserido.");
            throw new UnprocessableEntityException("error.msg.cartao.duplicado", "error.msg.parametro.invalido");
        }
    }

    private Proprietario salvarProprietario(String cnpj){
        Optional<Proprietario> proprietario = getProprietarioService().buscarPorCnpj(cnpj);
        if (proprietario.isPresent()){
            return proprietario.get();
        } else {
            Proprietario novoProprietario = new Proprietario();
            novoProprietario.setCnpj(cnpj);
            return novoProprietario;
        }
    }

    private String obterUltimosCaracteresString(String valor) {
        return StringUtils.right(valor, 4);
    }

    private void mapperConfiguration() {
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT).setSkipNullEnabled(true);
        modelMapper.typeMap(CartaoDockIntegradorDTO.class, CartaoDock.class).addMapping(CartaoDockIntegradorDTO::getId, CartaoDock::setIdCartaoIntegracao);
        modelMapper.typeMap(CartaoDock.class, CartaoDockIntegradorDTO.class).addMapping(CartaoDock::getIdCartaoIntegracao, CartaoDockIntegradorDTO::setId);
    }

    @Override
    public List<SimpleDTO> carregarStatus() {
        List<SimpleDTO> statusLista = new ArrayList<>();
        Stream.of(CartaoStatusEnum.values()).forEach(item -> {
            statusLista
                    .add(new SimpleDTO(item.getId(), item.getDescricao()));
        });
        return statusLista;
    }

    @Override
    public AbstractCartaoDTO buscarPorId(Long id, UsuarioPamcard usuario) {
        log.info("CartaoServiceImpl: Inicio de buscarPorId. id: {}", id);
        Optional<AbstractCartao> cartaoEncontrado = getCartaoRepository().findById(id);
        if (!cartaoEncontrado.isPresent()) {
            log.error("Cartão com o id {} não encontrado.", id);
            throw new ResourceNotFoundException(CartaoDock.class, "id", String.valueOf(Optional.ofNullable(id).orElse(null)));
        }
        AbstractCartao cartao = cartaoEncontrado.get();
        validarProprietario(id, usuario, cartao.getProprietario());

        mapperConfiguration();
        CartaoDockIntegradorDTO cartaoDTO = getModelMapper().map(cartao, CartaoDockIntegradorDTO.class);

        Map<CartaoStatusEnum, Set<SimpleDTO>> statusOperacoes = consultarOperacoesStatus(usuario);
        Set<SimpleDTO> operacoes = statusOperacoes.get(cartaoDTO.getStatus());
        cartaoDTO.setOperacoesDisponiveis(operacoes);

        log.info("CartaoServiceImpl: Fim de buscarPorId.");
        return cartaoDTO;
    }

    private void validarProprietario(Long idCartao, UsuarioPamcard usuario, Proprietario proprietario) {
        if (UsuarioPamcard.TipoUsuario.CLIENTE == usuario.getTipoUsuario()) {
            String cnpj = UsernamePasswordAuthenticationTokenUtils.extrairCnpjProprietario(usuario);
            if (!proprietario.getCnpj().equals(cnpj)) {
                log.error("O solicitante não é o proprietario do cartão com id {}.", idCartao);
                throw new ResourceNotFoundException(AbstractCartao.class, "id", idCartao.toString());
            }
        }
    }

    @Override
    public ResponseEntity<?> buscarCartoes(UsuarioPamcard usuario, boolean paginado, Map<String, String> filtroHeader,
                                        int pagina, int tamanho, String colunaOrdenacao) throws ParseException, IOException {
        log.info("CartaoServiceImpl: Inicio de buscarCartoes.");

        Map<String, String> filtro = new HashMap<>();

        if(filtroHeader.get("filtros") != null){
            TypeReference<HashMap<String, String>> typeRef = new TypeReference<HashMap<String, String>>() {};
            filtro = mapper.readValue(filtroHeader.get("filtros"), typeRef);
        }

        if (UsuarioPamcard.TipoUsuario.CLIENTE == usuario.getTipoUsuario()) {
            String proprietario = UsernamePasswordAuthenticationTokenUtils.extrairCnpjProprietario(usuario);
            filtro.put("proprietario", proprietario);
        } else {
            filtro.remove("proprietario");
        }
        AbstractCartaoFilter filtroCartao = montarFiltro(usuario, filtro);

        if (!paginado){
            List<CartaoDock> cartoesList = getCartaoDockRepository().findAll(filtroCartao);
            List<CartaoDockIntegradorDTO> cartoesListDTO = mapEntityListIntoDTOList(cartoesList);
            Map<CartaoStatusEnum, Set<SimpleDTO>> statusOperacoesL = consultarOperacoesStatus(usuario);
            for (CartaoDockIntegradorDTO cartao : cartoesListDTO) {
                Set<SimpleDTO> operacoes = statusOperacoesL.get(cartao.getStatus());
                cartao.setOperacoesDisponiveis(operacoes);
            }
            log.info("CartaoServiceImpl: Fim de buscarCartoes.");
            return ResponseEntity.ok(cartoesListDTO);
        }

        Page<CartaoDock> cartoesPage = getCartaoDockRepository()
                .findAll(filtroCartao,
                        PageRequest.of(pagina, tamanho, Sort.by(colunaOrdenacao).descending())
                );
        Page<CartaoDockIntegradorDTO> cartoesPageDTO = mapEntityPageIntoDTOPage(cartoesPage);
        Map<CartaoStatusEnum, Set<SimpleDTO>> statusOperacoes = consultarOperacoesStatus(usuario);
        for (CartaoDockIntegradorDTO cartao : cartoesPageDTO) {
            Set<SimpleDTO> operacoes = statusOperacoes.get(cartao.getStatus());
            cartao.setOperacoesDisponiveis(operacoes);
        }
        log.info("CartaoServiceImpl: Fim de buscarCartoes.");
        return ResponseEntity.ok(cartoesPageDTO);
    }

    private Page<CartaoDockIntegradorDTO> mapEntityPageIntoDTOPage(Page<CartaoDock> entityPage){
        mapperConfiguration();
        return entityPage.map(entity -> modelMapper.map(entity, CartaoDockIntegradorDTO.class));
    }
    private List<CartaoDockIntegradorDTO> mapEntityListIntoDTOList(List<CartaoDock> entityList){
        mapperConfiguration();
        return entityList.stream().map(entity -> modelMapper.map(entity, CartaoDockIntegradorDTO.class)).collect(Collectors.toList());
    }

    private Map<CartaoStatusEnum, Set<SimpleDTO>> consultarOperacoesStatus(UsuarioPamcard usuario) {
        Map<CartaoStatusEnum, Set<SimpleDTO>> statusOperacoes = new HashMap<>();

        CartaoStatusEnum[] statusDisponiveis = CartaoStatusEnum.values();
        for (CartaoStatusEnum status : statusDisponiveis) {

            Set<SimpleDTO> operacoes = statusOperacoes.get(status);
            if (operacoes == null) {
                operacoes = new HashSet<>();
                statusOperacoes.put(status, operacoes);
            }

            CartaoStatusState state = CartaoStatusStateFactory
                    .buscarStatePorStatus(status);

            if (!CollectionUtils.isEmpty(usuario.getAuthorities())) {
                List<String> permissoesUsuario = usuario.getAuthorities()
                        .parallelStream().map(GrantedAuthority::getAuthority).collect(Collectors.toList());

                Method[] methods = state.getClass().getMethods();
                for (Method method : methods) {
                    if (method.getName().toUpperCase().startsWith("DEFINIR")) {
                        try {
                            CartaoStatusEnum operacao = (CartaoStatusEnum) method.invoke(state, null);
                            if (operacao.validarPermissao(operacao, permissoesUsuario)) {
                                operacoes.add(new SimpleDTO(operacao.getId(), operacao.getDescricao()));
                            }
                        } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
                        }
                    }
                }

            }
        }
        return statusOperacoes;
    }

    private AbstractCartaoFilter montarFiltro(UsuarioPamcard usuario, Map<String, String> filtro) throws ParseException {
        AbstractCartaoFilter filter = AbstractCartaoFilter.builder().build();

        String id = filtro.get("idCartao");
        if (!Optional.ofNullable(id).orElse("").trim().isEmpty()) {
            validarNumerico("idCartao", id);
            filter.setIdCartao(Long.parseLong(id.replaceAll("[^0-9]", "")));
        }

        String cpf = filtro.get("cpf");
        if (!Optional.ofNullable(cpf).orElse("").trim().isEmpty()) {
            validarNumerico("cpf", cpf);
            filter.setCpf(cpf.replaceAll("[^0-9]", ""));
        }
        String status = filtro.get("status");
        if (!Optional.ofNullable(status).orElse("").trim().isEmpty()) {
            filter.setStatus(CartaoStatusEnum.buscarEnum(status));
        }
        String tipoCartao = filtro.get("tipoCartao");
        if (!Optional.ofNullable(tipoCartao).orElse("").trim().isEmpty()) {
            CartaoTipoEnum tipoCartaoEnum = CartaoTipoEnum
                    .buscarEnum(tipoCartao);
            filter.setEmissor(tipoCartaoEnum.getEmissor());
            filter.setModalidade(tipoCartaoEnum.getModalidade());
        }
        String quatroDigitos = filtro.get("quatroDigitos");
        if (!Optional.ofNullable(quatroDigitos).orElse("").trim().isEmpty()) {
            validarNumerico("quatroDigitos", quatroDigitos);
            validarQuantidadeCaracteres(4, "quatroDigitos", quatroDigitos);
            filter.setQuatroUltimosDigitos(quatroDigitos);
        }
        String nomePortador = filtro.get("nomePortador");
        if (!Optional.ofNullable(nomePortador).orElse("").trim().isEmpty()) {
            filter.setNomePortador(nomePortador.toUpperCase());
        }
        if (UsuarioPamcard.TipoUsuario.CLIENTE == usuario.getTipoUsuario()) {
            String proprietario = filtro.get("proprietario");
            if (!Optional.ofNullable(proprietario).orElse("").trim().isEmpty()) {
                filter.setProprietario(proprietario);
            }
        }

        return filter;
    }

    private void validarNumerico(String campo, String valor) {
        if (valor.replaceAll("[^0-9]", "").trim().isEmpty()) {
            log.error("validarNumerico: Campo {} inválido.", campo);
            throw new CartaoFiltroException(campo + " inválido.");
        }
    }

    private void validarQuantidadeCaracteres(int quantidade, String campo, String valor) {
        if (quantidade != Optional.ofNullable(valor).orElse("").trim().length()) {
            log.error("validarQuantidadeCaracteres: Campo {} deve ter {} dígitos.", campo, quantidade);
            throw new CartaoFiltroException(campo + " deve ter " + quantidade + " dígitos.");
        }
    }

    
	@Override
	public void cadastrarSenha(String senha, String confirmacaoSenha, UsuarioPamcard usuarioPamcard, Long idCartao, int tipoOperacao) {

		if (!senha.equals(confirmacaoSenha)) {
			log.error("Senha e Confirmação Senha estão diferentes.");
			throw new UnprocessableEntityException("erro.msg.senha", "erro.senha");
		}

		String cnpj = UsernamePasswordAuthenticationTokenUtils.extrairCnpjProprietario(usuarioPamcard);
		
		Optional<CartaoDock> cartao =  validarCartao(idCartao, cnpj);
		
		String usernamePamcard = usuarioPamcard.getUsername();	
		
		if (ObjectUtils.isEmpty(cartao.get().getPortador())) {
			log.error("Cartão sem portador");
			throw new UnprocessableEntityException("erro.msg.portador", "erro.portador");
		}
		
		CartaoStatusEnum statusAnterior = cartao.get().getStatus();
		
		if(tipoOperacao == CADASTRO) {
		if (!cartao.get().getStatus().equals(CartaoStatusEnum.PENDENTE_SENHA)) {
			log.error("Cartão com status diferente de pendente senha");
			throw new UnprocessableEntityException("erro.status.pendente.senha", "erro.status");
		}
			getIntegradorDockService().cadastrarSenha(senha, cartao.get().getIdCartaoIntegracao());
			cartao.get().setDataHoraCadastroSenha(LocalDateTime.now());
			cartao.get().setStatus(CartaoStatusEnum.PENDENTE_LIMITE);
		}
		
		if(tipoOperacao == ALTERAR) {
			if (!(cartao.get().getStatus().equals(CartaoStatusEnum.ATIVO) || cartao.get().getStatus().equals(CartaoStatusEnum.BLOQUEADO))) {
				log.error("Status atual do cartão não permiti realizar o processo de alteração de senha do cartão");
				throw new UnprocessableEntityException("erro.msg.alteracao.senha", "erro.status");
			}
			getIntegradorDockService().alterarSenha(senha, cartao.get().getIdCartaoIntegracao());
			cartao.get().setDataHoraAlteracaoSenha(LocalDateTime.now());
		}
				
		cartao.get().setUsuarioSolicitante(usernamePamcard);
		
		getCartaoRepository().save(cartao.get());
		
		notificarHistoricoCartao(cartao.get(), statusAnterior, cartao.get().getStatus(), true, usernamePamcard, cnpj);
        notificarLog(cartao.get(), statusAnterior, cartao.get().getStatus(), usernamePamcard);
	}
		

	 private Optional<CartaoDock> validarCartao(Long idCartao, String cnpj) {
	    	Optional<CartaoDock> cartao =  getCartaoDockRepository().findById(idCartao);
	    	
	    	if (!cartao.isPresent()) {
				log.error("Cartão com o id integração {} não encontrado.", idCartao);
				throw new ResourceNotFoundException(CartaoDock.class, "id",
						String.valueOf(Optional.ofNullable(idCartao).orElse(null)));
			}		
			
			if (!cnpj.equals(cartao.get().getProprietario().getCnpj())) {
				log.error("Cartão não pertence ao proprieterio com cnpj {}", cnpj);
				throw new UnprocessableEntityException("erro.msg.proprietario", "erro.proprietario");
			}
	    	
	    	return cartao;
		}



	public void notificarHistoricoCartao(AbstractCartao cartao, CartaoStatusEnum anterior, CartaoStatusEnum proximo, boolean propagaLog,  String usuario, String proprietario) {
        HistoricoCartaoDTO historico = new HistoricoCartaoDTO(
                cartao.getIdCartao(),
                anterior,
                proximo,
                LocalDateTime.now(),
                propagaLog,
                usuario,
                proprietario);
        getNotifier().enviarNotificacao(this.getHistoricoAlteracaoCartaoTopico(),
                this.getHistoricoAlteracaoCartaoTitulo(), historico);
    }

	@Override
    public void notificarLog(AbstractCartao cartao, CartaoStatusEnum anterior, CartaoStatusEnum proximo, String usuario) {
        StringJoiner complemento = new StringJoiner(", ");
        complemento.add(cartao.getIdCartao().toString());
        if(anterior!=null){
            complemento.add(anterior.getId());
        }
        complemento.add(proximo.getId());
        OperacaoLog operacaoLog = OperacaoLog.builder().complemento(complemento.toString()).dataOperacao(LocalDateTime.now())
                .acao(AcaoEnum.ALTERAR_STATUS_CARTAO).usuario(usuario).build();
        getNotificadorLog().salvarLog(operacaoLog);
    }



	@Override
	public void alterarStatus(String status, UsuarioPamcard usuarioPamcard, Long idCartao) {
		
		if(!(status.equalsIgnoreCase(CartaoStatusEnum.ATIVO.getDescricao()) || status.equalsIgnoreCase(CartaoStatusEnum.BLOQUEADO.getDescricao()) || 
				status.equalsIgnoreCase(CartaoStatusEnum.CANCELADO.getDescricao()))) {
			log.error("Status diferente de ATIVO ou BLOQUEADO ou CANCELADO");
			throw new UnprocessableEntityException("erro.msg.status.invalido", "erro.status");
		}

		String cnpj = UsernamePasswordAuthenticationTokenUtils.extrairCnpjProprietario(usuarioPamcard);
		
		Optional<CartaoDock> cartao =  validarCartao(idCartao, cnpj);
			
		String usernamePamcard = usuarioPamcard.getUsername();
		
		CartaoStatusEnum statusAnterior = cartao.get().getStatus();

		if(status.equalsIgnoreCase(CartaoStatusEnum.ATIVO.getDescricao())){
			
			if (!(cartao.get().getStatus().equals(CartaoStatusEnum.PRONTO_ATIVACAO) || cartao.get().getStatus().equals(CartaoStatusEnum.BLOQUEADO))) {
				log.error("Cartão com status diferente de PRONTO_ATIVACAO ou BLOQUEADO");
				throw new UnprocessableEntityException("erro.status.ativo.invalido", "erro.status");
			}
		
			getIntegradorDockService().ativarCartao(cartao.get().getIdCartaoIntegracao());
			
			cartao.get().setStatus(CartaoStatusEnum.ATIVO);
			cartao.get().setDataHoraAtivacao(LocalDateTime.now());	
			cartao.get().setDataHoraDesbloqueio(LocalDateTime.now());
		}
		
		if(status.equalsIgnoreCase(CartaoStatusEnum.BLOQUEADO.getDescricao())){
			
			if (!cartao.get().getStatus().equals(CartaoStatusEnum.ATIVO)){
				log.error("Cartão com status diferente de ATIVO não pode ser BLOQUEADO");
				throw new UnprocessableEntityException("erro.status.bloqueado.invalido", "erro.status");
			}
			
			getIntegradorDockService().bloquearCartao(cartao.get().getIdCartaoIntegracao());
			
			cartao.get().setStatus(CartaoStatusEnum.BLOQUEADO);
			cartao.get().setDataHoraBloqueio(LocalDateTime.now());
		}
		
		if(status.equalsIgnoreCase(CartaoStatusEnum.CANCELADO.getDescricao())){
			
			getIntegradorDockService().cancelarCartao(cartao.get().getIdCartaoIntegracao());
			
			cartao.get().setStatus(CartaoStatusEnum.CANCELADO);
			cartao.get().setDataHoraCancelamento(LocalDateTime.now());
		}
			
		cartao.get().setUsuarioSolicitante(usernamePamcard);

		getCartaoRepository().save(cartao.get());
		

		notificarHistoricoCartao(cartao.get(), statusAnterior, cartao.get().getStatus(), true,
				usernamePamcard, cnpj);
		notificarLog(cartao.get(), statusAnterior, cartao.get().getStatus(), usernamePamcard);

	}


}
