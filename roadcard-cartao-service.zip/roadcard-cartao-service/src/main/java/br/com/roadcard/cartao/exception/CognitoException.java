package br.com.roadcard.cartao.exception;

public class CognitoException extends RuntimeException {

	private static final long serialVersionUID = 218734474226160359L;

	public CognitoException(Exception e) {
		super(e);
	}
	
}
