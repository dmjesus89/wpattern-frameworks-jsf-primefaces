package br.com.roadcard.cartao.model.state;

import br.com.roadcard.cartao.model.CartaoStatusEnum;
import lombok.NoArgsConstructor;

@NoArgsConstructor
public class CartaoStatusStateFactory {

    public static CartaoStatusState buscarStatePorStatus(CartaoStatusEnum status) {
        if (CartaoStatusEnum.PENDENTE_VINCULACAO.equals(status)) {
            return new PendenteVinculacaoStateImpl();
        } else if (CartaoStatusEnum.PENDENTE_SENHA.equals(status)) {
            return new PendenteSenhaStateImpl();
        } else if (CartaoStatusEnum.PENDENTE_LIMITE.equals(status)) {
            return new PendenteLimiteStateImpl();
        } else if (CartaoStatusEnum.PRONTO_ATIVACAO.equals(status)) {
            return new ProntoAtivacaoStateImpl();
        } else if (CartaoStatusEnum.ATIVO.equals(status)) {
            return new AtivoStateImpl();
        } else if (CartaoStatusEnum.BLOQUEADO.equals(status)) {
            return new BloqueadoStateImpl();
        } else if (CartaoStatusEnum.CANCELADO.equals(status)) {
            return new CanceladoStateImpl();
        }
        return null;
    }

}