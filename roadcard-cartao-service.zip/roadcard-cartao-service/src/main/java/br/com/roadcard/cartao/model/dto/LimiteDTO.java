package br.com.roadcard.cartao.model.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.validation.constraints.NotNull;

import br.com.roadcard.cartao.validation.LimiteValidation;
import lombok.Data;
import org.springframework.data.annotation.ReadOnlyProperty;

@LimiteValidation.List({
	@LimiteValidation()
})
@Data
public class LimiteDTO implements Serializable {

    private static final long serialVersionUID = 7074808157493048860L;

    @NotNull
    private BigDecimal limiteMensal;

    @NotNull
    private BigDecimal limiteSemanal;

    @NotNull
    private BigDecimal limiteDiario;

    @ReadOnlyProperty
    private BigDecimal saldoDisponivelMensal;

    @ReadOnlyProperty
    private BigDecimal saldoDisponivelSemanal;

    @ReadOnlyProperty
    private BigDecimal saldoDisponivelDiario;

}
