package br.com.roadcard.cartao.service.interfaces;

public interface CognitoService {

    String getToken();

}