package br.com.roadcard.cartao.model.state;

public class CanceladoStateImpl implements CartaoStatusState {

	private static final long serialVersionUID = -1072317674247169683L;

}
