package br.com.roadcard.cartao.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
@Table(
        name = "cartao",
        uniqueConstraints = {
                @UniqueConstraint(
                        columnNames = {
                                "emissor",
                                "modalidade",
                                "idCartaoIntegracao"
                        }
                )
        }
)
@DiscriminatorColumn(
        name = "emissor",
        discriminatorType = DiscriminatorType.STRING
)
@NoArgsConstructor
@Getter
@Setter
public abstract class AbstractCartao implements Serializable {

    private static final long serialVersionUID = 3627927180335136661L;
    private static final String EMISSOR_DOCK = "Dock";

    @Id
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "seq_cartao"
    )
    @SequenceGenerator(
            name = "seq_cartao",
            sequenceName = "seq_cartao",
            allocationSize = 1
    )
    @Column(
            name = "id_cartao",
            nullable = false,
            updatable = false
    )
    private Long idCartao;

    @Column(insertable = false, updatable = true)
    private LocalDateTime dataHoraAtivacao;

    @Column(insertable = true, updatable = false)
    private LocalDateTime dataHoraCadastro;

    @Column(insertable = true, updatable = true)
    private LocalDateTime dataHoraAtualizacao;

    @Column(insertable = false, updatable = true)
    private LocalDateTime dataHoraCancelamento;

    @Column(insertable = false, updatable = true)
    private LocalDateTime dataHoraBloqueio;

    @Column(insertable = false, updatable = true)
    private LocalDateTime dataHoraDesbloqueio;

    @Column(insertable = false, updatable = true)
    private LocalDateTime dataHoraCadastroSenha;

    @Column(insertable = false, updatable = true)
    private LocalDateTime dataHoraAlteracaoSenha;

    @Column(nullable = false, insertable = false, updatable = false)
    private String emissor = EMISSOR_DOCK;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private CartaoModalidadeEnum modalidade = CartaoModalidadeEnum.FROTA;

    @JoinColumn(name = "portador")
    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private Portador portador;

    @JoinColumn(name = "proprietario", nullable = false)
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private Proprietario proprietario;

    @Column(nullable = false)
    private String quatroUltimosDigitos;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private CartaoStatusEnum status = CartaoStatusEnum.PENDENTE_VINCULACAO;

    @Column(nullable = false)
    private String usuarioSolicitante;

}
