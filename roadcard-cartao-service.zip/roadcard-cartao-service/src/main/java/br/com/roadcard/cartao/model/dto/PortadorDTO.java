package br.com.roadcard.cartao.model.dto;

import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.br.CPF;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ApiModel
public class PortadorDTO {

    @NotBlank
    @ApiModelProperty(required = true)
    @CPF(message = "CPF informado inválido")
    private String cpf;
    

}
