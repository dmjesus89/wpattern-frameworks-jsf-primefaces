package br.com.roadcard.cartao.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.StringJoiner;

import br.com.roadcard.cartao.model.*;
import br.com.roadcard.cartao.model.dto.HistoricoCartaoDTO;
import br.com.roadcard.dock.exception.ResourceNotFoundException;
import br.com.roadcard.dock.individuals.PhoneDockResponse;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import br.com.roadcard.cartao.model.dto.HistoricoVinculadoDTO;
import br.com.roadcard.cartao.model.dto.HistoricoVinculadoPortadorDTO;
import br.com.roadcard.cartao.model.dto.PortadorDTO;
import br.com.roadcard.cartao.repository.PortadorRepository;
import br.com.roadcard.cartao.service.interfaces.CartaoService;
import br.com.roadcard.cartao.service.interfaces.IntegradorDockService;
import br.com.roadcard.cartao.service.interfaces.PortadorService;
import br.com.roadcard.cartao.service.notifier.GenericTopicNotifier;
import br.com.roadcard.dock.contas.VincularCartaoRequest;
import br.com.roadcard.dock.individuals.IndividualDockResponse;
import br.com.roadcard.geracao.log.model.AcaoEnum;
import br.com.roadcard.geracao.log.model.OperacaoLog;
import br.com.roadcard.geracao.log.service.NotificadorLog;
import br.com.roadcard.pamcard.auth.model.login.UsuarioPamcard;
import br.com.roadcard.pamcard.auth.utils.UsernamePasswordAuthenticationTokenUtils;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
@Service
public class PortadorServiceImpl implements PortadorService {
	
	private final IntegradorDockService integradorDockService;
	private final CartaoService cartaoService;
	private final PortadorRepository portadorRepository;
	private final ModelMapper mapper;
	private final NotificadorLog notificadorLog;
	private final String vinculacaoPortadorCartaoTopico;
	private final String vinculacaoPortadorCartaoTitulo;

    private final GenericTopicNotifier notifier;
	
	
	@Autowired
	public PortadorServiceImpl(IntegradorDockService integradorDockService, @Lazy CartaoService cartaoService, ModelMapper mapper, PortadorRepository portadorRepository,
							   NotificadorLog notificadorLog, GenericTopicNotifier notifier,
							   @Value("${aws.vinculacaoPortadorCartaoTopic}") final String vinculacaoPortadorCartaoTopico, @Value("${aws.vinculacaoPortadorCartaoTopicTitulo}") final String vinculacaoPortadorCartaoTitulo
							   ) {
		this.integradorDockService = integradorDockService;
		this.cartaoService = cartaoService;
		this.portadorRepository = portadorRepository;
		this.mapper = mapper;
		this.notificadorLog = notificadorLog;
		this.vinculacaoPortadorCartaoTopico = vinculacaoPortadorCartaoTopico;
		this.vinculacaoPortadorCartaoTitulo = vinculacaoPortadorCartaoTitulo;
		this.notifier = notifier;
	}

	@Override
	public void vincularPortadorAoCartao(UsuarioPamcard usuarioPamcard, Long idCartao, PortadorDTO portadorDTO) {
		getCartaoService().validarPortadorTemCartaoAtivo(portadorDTO);
		
		String cnpj = UsernamePasswordAuthenticationTokenUtils.extrairCnpjProprietario(usuarioPamcard);

		AbstractCartao cartao = getCartaoService().obterCartaoPendenteVinculacaoSemPortador(idCartao, cnpj);
		
		IndividualDockResponse portadorDockResponse = getIntegradorDockService().buscarPortadorPorCpfDock(portadorDTO);
		
		Integer idConta = getIntegradorDockService().buscarIdContaPorCnpjDock(UsernamePasswordAuthenticationTokenUtils.extrairCnpjProprietario(usuarioPamcard));

		getIntegradorDockService().adicionarPortadorParaContaContratante(portadorDockResponse.getId(), idConta);
		
		VincularCartaoRequest vincularCartaoRequest = new VincularCartaoRequest();
		vincularCartaoRequest.setIdCartao(idConta);
		vincularCartaoRequest.setIdPessoaFisica(portadorDockResponse.getId());

		getIntegradorDockService().vincularCartaoNaContaCooperada(idConta, vincularCartaoRequest);
		
		Portador portadorSalvo = salvarPortador(portadorDockResponse);
		
		cartao.setUsuarioSolicitante(usuarioPamcard.getUsername());
		
		AbstractCartao cartaoSalvo = getCartaoService().atualizarCartaoComPortador(cartao, portadorSalvo);

		notificarVinculoCartao(cartaoSalvo, portadorDockResponse, true, usuarioPamcard.getUsername(), cnpj);

		notificarLogPamcard(usuarioPamcard.getUsername(), cartaoSalvo);
    }
	
	  private void notificarLogPamcard(String username, AbstractCartao cartao) {
		StringJoiner complementos = new StringJoiner(", ");
			complementos.add(cartao.getIdCartao().toString());
			complementos.add(cartao.getStatus().toString());
		OperacaoLog operacaoLog = OperacaoLog.builder().complemento(complementos.toString()).dataOperacao(LocalDateTime.now()).acao(AcaoEnum.VINCULAR_PORTADOR).usuario(username).build();
		getNotificadorLog().salvarLog(operacaoLog);
	  }


	private void notificarVinculoCartao(AbstractCartao cartao, IndividualDockResponse portadorDockResponse, boolean propagaLog,  String usuario, String proprietario) {
		List<PhoneDockResponse> phones = portadorDockResponse.getPhones();
		boolean portadorComTelefone = Optional.ofNullable(phones).isPresent();

		HistoricoVinculadoDTO historico = new HistoricoVinculadoDTO(
				cartao.getIdCartao(), 
				cartao.getStatus(),
				new HistoricoVinculadoPortadorDTO(portadorDockResponse.getName(), 
													portadorDockResponse.getDocument(), 
													LocalDate.parse(portadorDockResponse.getBirthDate()),
						portadorComTelefone ?  phones.stream().findFirst().get().getDdd() : null,
						portadorComTelefone ?  phones.stream().findFirst().get().getTelefone() : null,
													portadorDockResponse.getEmail(),
													portadorDockResponse.getMotherName(),
													null, 
													portadorDockResponse.getIdentityIssuingEntity(), 
													portadorDockResponse.getId()), 
				propagaLog, 
				usuario, 
				proprietario, 
				LocalDateTime.now());
	              
		getNotifier().enviarNotificacao(this.getVinculacaoPortadorCartaoTopico(),
	                this.getVinculacaoPortadorCartaoTitulo(), historico);
	    }
	
	
	public Portador salvarPortador(IndividualDockResponse portadorDockResponse) {
		Portador portador = new Portador();
		portador.setCpf(portadorDockResponse.getDocument());
		portador.setNome(portadorDockResponse.getName());
		portador.setDataNascimento(LocalDate.parse(portadorDockResponse.getBirthDate()));
		PortadorConteudo dados = new PortadorConteudo();
		if(Optional.ofNullable(portadorDockResponse.getPhones()).isPresent()){
			portadorDockResponse.getPhones().stream().findFirst().ifPresent( portadorItem ->{
				dados.setDddTelefone(portadorItem.getDdd());
				dados.setTelefoneCelular(portadorItem.getTelefone());
			});
		}
		dados.setEmail(portadorDockResponse.getEmail());
		dados.setUfEmissorRg(portadorDockResponse.getFederativeUnit());
		dados.setNomeMae(portadorDockResponse.getMotherName());
		portador.setDados(dados);
	
		return getPortadorRepository().save(portador);
	}

}
