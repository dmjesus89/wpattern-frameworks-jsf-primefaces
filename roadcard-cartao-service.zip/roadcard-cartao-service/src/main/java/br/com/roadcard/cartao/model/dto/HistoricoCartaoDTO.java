package br.com.roadcard.cartao.model.dto;

import br.com.roadcard.cartao.model.CartaoStatusEnum;
import lombok.*;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.time.LocalDateTime;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class HistoricoCartaoDTO implements Serializable {

    private static final long serialVersionUID = 809555366460289650L;

    private Long idCartao;

    private CartaoStatusEnum anterior;

    private CartaoStatusEnum proximo;

    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss",
            timezone = "GMT-3"
    )
    private LocalDateTime dataHoraAlteracao;

    private boolean propagaLog;

    private String usuario;

    private String proprietario;

}
