package br.com.roadcard.cartao.model.dto;

import br.com.roadcard.dock.cards.LimiteCartaoDTO;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class CartaoDockIntegradorDTO extends AbstractCartaoDTO{

    @JsonProperty("idCartaoIntegracao")
    private Long id;

    private Integer flagTitular;

    private Long idPessoa;

    private Integer sequencialCartao;

    private Long idConta;

    private Integer idStatus;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT-3")
    private LocalDateTime dataStatus;

    private Integer idEstagio;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT-3")
    private LocalDateTime dataEstagio;

    private Integer numeroBin;

    private String numeroCartao;
    
    private Long numeroCartaoHash;

    private String numeroCartaoCriptografado;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT-3")
    private LocalDateTime dataEmissao;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT-3")
    private LocalDateTime dataValidade;

    private Integer cartaoVirtual;

    private Integer impressaoAvulsa;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT-3")
    private LocalDateTime dataImpressao;

    private String nomeArquivoImpressao;

    private Integer idProduto;

    private String nomeImpresso;

    private String codigoDesbloqueio;

    private LimiteCartaoDTO limiteCartao;
}
