package br.com.roadcard.cartao.model.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SaldoDisponivelDTO implements Serializable {
    private static final long serialVersionUID = -8258977400614940996L;

    private BigDecimal saldoDisponivelGlobal;

}
