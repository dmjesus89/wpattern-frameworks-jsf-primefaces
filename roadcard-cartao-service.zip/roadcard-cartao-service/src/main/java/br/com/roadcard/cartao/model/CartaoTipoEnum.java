package br.com.roadcard.cartao.model;


import java.util.Arrays;
import java.util.Optional;

import br.com.roadcard.dock.exception.ResourceNotFoundException;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@JsonFormat(shape = JsonFormat.Shape.OBJECT)
@AllArgsConstructor
public enum CartaoTipoEnum {

    DOCK_CORPORATIVO("CARTAO_DOCK_FROTA", "Dock", CartaoModalidadeEnum.FROTA, "Cartão Frota");

    private final String id;

    private final String emissor;

    private final CartaoModalidadeEnum modalidade;

    private final String descricao;

    @JsonCreator
    public static CartaoTipoEnum buscarEnum(String tipo) {
        Optional<CartaoTipoEnum> tipoCartao = Arrays.asList(values())
                .parallelStream().filter(c -> c.getId().equalsIgnoreCase(tipo))
                .findFirst();
        if (!tipoCartao.isPresent()) {
            throw new ResourceNotFoundException(CartaoTipoEnum.class, "id",
                    tipo);
        }
        return tipoCartao.get();
    }

    public static String buscarEnum(String emissor, CartaoModalidadeEnum modalidade) {
        Optional<CartaoTipoEnum> tipoCartao = Arrays.asList(values())
                .parallelStream().filter(c ->
                        c.getEmissor().equalsIgnoreCase(emissor) && (c.getModalidade() == modalidade)
                ).findFirst();
        if (!tipoCartao.isPresent()) {
            return "";
        }
        return tipoCartao.get().getDescricao();
    }

}