package br.com.roadcard.cartao.aws.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.AmazonSNSClient;

@Configuration
public class AwsConfig {

	@Bean
	public AmazonSNS gerarSnsClient() {
		return AmazonSNSClient.builder().build();
	}

}
