package br.com.roadcard.cartao.service.notifier;

import br.com.roadcard.cartao.exception.CartaoNotificationException;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.model.PublishRequest;
import com.amazonaws.services.sns.model.PublishResult;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;



@Component
@Slf4j
public class GenericTopicNotifier {

	private final AmazonSNS sns;
	private final ObjectMapper mapper;

	@Autowired
	public GenericTopicNotifier(final AmazonSNS sns, final ObjectMapper mapper) {
		this.sns = sns;
		this.mapper = mapper;
	}

	@Valid
	public boolean enviarNotificacao(String topico, String titulo, 
			@NotNull Object conteudo) {
		try {
			enviarSnsAws(topico, titulo, conteudo);
			return true;
		} catch (Exception e) {
			log.error("Ocorreu um erro ao enviar a notificação: ", e);
			throw new CartaoNotificationException();
		}
	}

	public boolean enviarSnsAws(String topico, String titulo, Object valores) throws JsonProcessingException {
		PublishRequest request = new PublishRequest()
				.withTopicArn(topico)
				.withSubject(titulo)
				.withMessage(this.mapper.writeValueAsString(valores));
		PublishResult retorno = this.getSns().publish(request);

		log.info(mapper.writeValueAsString(valores));
		return !retorno.getMessageId().trim().isEmpty();
	}

	public AmazonSNS getSns() {
		return this.sns;
	}


}
