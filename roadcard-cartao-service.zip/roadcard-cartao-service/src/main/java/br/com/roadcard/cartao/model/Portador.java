package br.com.roadcard.cartao.model;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.vladmihalcea.hibernate.type.json.JsonStringType;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;

import io.swagger.annotations.ApiModel;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.TypeDefs;

@Entity
@Getter
@Setter
@ApiModel
@TypeDefs({
        @TypeDef(name = "json", typeClass = JsonStringType.class),
        @TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
})
public class Portador implements Serializable {

    private static final long serialVersionUID = -509906341528826161L;

    @Id
    private String cpf;

    @Column(nullable = false)
    private String nome;

    @Column(nullable = false)
    private LocalDate dataNascimento;
    
	
	 @JsonIgnore
     @Type(type = "jsonb")
     @Column(columnDefinition = "jsonb")
     private PortadorConteudo dados;


	public Portador() {
		this.dados =  new PortadorConteudo();
	}
	 
	 

}