package br.com.roadcard.cartao.service.interfaces;

import br.com.roadcard.cartao.model.Proprietario;

import java.util.Optional;

public interface ProprietarioService {
    Optional<Proprietario> buscarPorCnpj(String cnpj);
}
