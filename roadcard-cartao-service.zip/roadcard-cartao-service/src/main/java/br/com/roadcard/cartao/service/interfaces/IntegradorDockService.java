package br.com.roadcard.cartao.service.interfaces;

import br.com.roadcard.cartao.model.dto.CartaoDockIntegradorDTO;
import br.com.roadcard.cartao.model.dto.LimiteDTO;
import br.com.roadcard.cartao.model.dto.PortadorDTO;
import br.com.roadcard.dock.cards.LimiteCartaoResponse;
import br.com.roadcard.dock.contas.VincularCartaoRequest;
import br.com.roadcard.dock.individuals.IndividualDockResponse;

public interface IntegradorDockService {
	
	IndividualDockResponse buscarPortadorPorCpfDock(PortadorDTO portadorDTO);

	CartaoDockIntegradorDTO buscarInformacaoCartaoDock(String numeroCartao);

	Integer buscarIdContaPorCnpjDock(String cnpj);

	void adicionarPortadorParaContaContratante(Integer idPessoa, Integer idConta);

	void vincularCartaoNaContaCooperada(Integer idConta, VincularCartaoRequest vincularCartaoRequest);
     
	void cadastrarSenha(String senha, Long idCartao);

	LimiteCartaoResponse cadastrarLimiteCartao(LimiteDTO limiteDTO, Long idCartao);
	
	void ativarCartao(Long idCartaoIntegracao);

	void bloquearCartao(Long idCartaoIntegracao);

	void cancelarCartao(Long idCartaoIntegracao);

	void alterarSenha(String senha, Long idCartaoIntegracao);
}
