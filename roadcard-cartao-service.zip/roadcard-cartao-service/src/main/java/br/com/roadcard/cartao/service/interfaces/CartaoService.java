package br.com.roadcard.cartao.service.interfaces;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;

import br.com.roadcard.cartao.model.AbstractCartao;
import br.com.roadcard.cartao.model.CartaoStatusEnum;
import br.com.roadcard.cartao.model.Portador;
import br.com.roadcard.cartao.model.dto.AbstractCartaoDTO;
import br.com.roadcard.cartao.model.dto.PortadorDTO;
import br.com.roadcard.cartao.model.dto.SimpleDTO;
import br.com.roadcard.pamcard.auth.model.login.UsuarioPamcard;

public interface CartaoService {
    AbstractCartaoDTO cadastrarCartao(String numeroCartao, UsuarioPamcard usuarioPamcard);

    List<SimpleDTO> carregarStatus();

    ResponseEntity<?> buscarCartoes(UsuarioPamcard usuario,
                                    boolean paginado,
                                    Map<String, String> filtroHeader,
                                    int pagina,
                                    int tamanho,
                                    String colunaOrdenacao) throws ParseException, IOException;

	AbstractCartaoDTO buscarPorId(Long id, UsuarioPamcard usuario);
    
	void validarPortadorTemCartaoAtivo(PortadorDTO portadorDTO);

	AbstractCartao atualizarCartaoComPortador(AbstractCartao cartao, Portador portador);

	AbstractCartao obterCartaoPendenteVinculacaoSemPortador(Long idCartao, String cnpj);

	AbstractCartao obterCartaoPendenteLimite(Long idCartao, String cnpj);

	AbstractCartao atualizarCartaoComStatusProntoAtivacao(AbstractCartao cartao, String usuario);

	void notificarHistoricoCartao(AbstractCartao cartao, CartaoStatusEnum anterior, CartaoStatusEnum proximo,
			boolean propagaLog, String usuario, String proprietario);

	void notificarLog(AbstractCartao cartao, CartaoStatusEnum anterior, CartaoStatusEnum proximo, String usuario);

	void cadastrarSenha(String senha, String confirmacaoSenha, UsuarioPamcard usuarioPamcard, Long idCartao, int tipoOperacao);

	void alterarStatus(String status, UsuarioPamcard usuarioPamcard, Long idCartao);
}
