package br.com.roadcard.cartao.model.state;

import br.com.roadcard.cartao.model.CartaoStatusEnum;

public class PendenteLimiteStateImpl implements CartaoStatusState {

    private static final long serialVersionUID = -7742492602002497644L;

    @Override
    public CartaoStatusEnum definirCartaoProntoAtivacao() {
        return CartaoStatusEnum.PRONTO_ATIVACAO;
    }

    @Override
    public CartaoStatusEnum definirCartaoCancelado() {
        return CartaoStatusEnum.CANCELADO;
    }

}
