package br.com.roadcard.cartao.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST)
public class FiltroPeriodoException extends RuntimeException {

    private static final long serialVersionUID = -8875951707645989472L;

    public FiltroPeriodoException() {
        super();
    }

}