package br.com.roadcard.cartao.repository;

import br.com.pamcary.pamcard.data.repository.utils.FilterRepository;
import br.com.roadcard.cartao.model.CartaoDock;
import br.com.roadcard.cartao.model.filter.AbstractCartaoFilter;
import org.springframework.stereotype.Repository;

@Repository
public interface CartaoDockRepository extends FilterRepository<CartaoDock, Long, AbstractCartaoFilter> {

}