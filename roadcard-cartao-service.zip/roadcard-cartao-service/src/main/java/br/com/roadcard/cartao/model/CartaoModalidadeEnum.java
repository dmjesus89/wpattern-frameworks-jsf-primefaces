package br.com.roadcard.cartao.model;

public enum CartaoModalidadeEnum {
    FROTA
}
