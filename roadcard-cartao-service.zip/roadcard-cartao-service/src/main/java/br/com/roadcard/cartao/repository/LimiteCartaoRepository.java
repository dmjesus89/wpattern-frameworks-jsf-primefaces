package br.com.roadcard.cartao.repository;

import java.math.BigDecimal;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import br.com.roadcard.cartao.model.LimiteCartao;

@Repository
public interface LimiteCartaoRepository extends JpaRepository<LimiteCartao, Long>  {
	
	@Query("SELECT sum(l.limiteMensal) FROM LimiteCartao l WHERE l.limiteAtivo = true AND l.proprietario = :proprietario")
	BigDecimal somatorioLimitesAtivosPorProprietario(@Param("proprietario") String cnpjProprietario);

	Optional<LimiteCartao> findByIdCartaoAndProprietario(String string, String string2);
	
}
