package br.com.roadcard.cartao.cognito;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class CognitoResponse implements Serializable{

	private static final long serialVersionUID = -6026893605168045591L;

	@JsonProperty("access_token")
	private String token;
	
	@JsonProperty("token_type")
	private String type;
	
}
