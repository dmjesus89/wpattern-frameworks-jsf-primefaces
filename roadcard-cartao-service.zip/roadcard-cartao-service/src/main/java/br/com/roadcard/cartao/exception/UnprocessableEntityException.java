package br.com.roadcard.cartao.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

import lombok.Getter;
import lombok.Setter;

@ResponseStatus(value = HttpStatus.UNPROCESSABLE_ENTITY)
@Getter
@Setter
public class UnprocessableEntityException extends RuntimeException {
	
	private static final long serialVersionUID = -8888811983990494642L;
	
	private HttpStatus status;
	private String tituloErro;
	private Exception exception;
	
	
	public UnprocessableEntityException(String message, String tituloErro, Exception exception) {
		super(message);
		this.status = HttpStatus.UNPROCESSABLE_ENTITY;
		this.tituloErro = tituloErro;
		this.exception = exception;
	}
	
	public UnprocessableEntityException(String message, String tituloErro) {
		super(message);
		this.status = HttpStatus.UNPROCESSABLE_ENTITY;
		this.tituloErro = tituloErro;
	}
}
