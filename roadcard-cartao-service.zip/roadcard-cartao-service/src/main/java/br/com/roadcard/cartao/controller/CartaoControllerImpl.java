package br.com.roadcard.cartao.controller;

import java.math.BigDecimal;
import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import br.com.roadcard.cartao.controller.interfaces.CartaoController;
import br.com.roadcard.cartao.model.dto.AbstractCartaoDTO;
import br.com.roadcard.cartao.model.dto.CadastrarCartaoDTO;
import br.com.roadcard.cartao.model.dto.CadastrarSenhaDTO;
import br.com.roadcard.cartao.model.dto.LimiteDTO;
import br.com.roadcard.cartao.model.dto.PortadorDTO;
import br.com.roadcard.cartao.model.dto.SimpleDTO;
import br.com.roadcard.cartao.service.interfaces.CartaoService;
import br.com.roadcard.cartao.service.interfaces.LimiteCartaoService;
import br.com.roadcard.cartao.service.interfaces.PortadorService;
import br.com.roadcard.pamcard.auth.model.login.UsuarioPamcard;
import br.com.roadcard.pamcard.auth.utils.UsernamePasswordAuthenticationTokenUtils;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping(
        value = "/api/cartoes",
        produces = MediaType.APPLICATION_JSON_UTF8_VALUE
)
@Getter
@Slf4j
public class CartaoControllerImpl implements CartaoController {

    private final CartaoService cartaoService;
    private final PortadorService portadorService;
    private final LimiteCartaoService limiteCartaoService;
    private final int CADASTRO = 1;
    private final int ALTERAR = 2;

    @Autowired
    public CartaoControllerImpl(CartaoService cartaoService, PortadorService portadorService, LimiteCartaoService limiteCartaoService) {
        this.cartaoService = cartaoService;
		this.portadorService = portadorService;
		this.limiteCartaoService = limiteCartaoService;
    }
    
  

    @PostMapping
    @Override
    public ResponseEntity<AbstractCartaoDTO> cadastrarCartao(UsernamePasswordAuthenticationToken token, @RequestBody @Valid CadastrarCartaoDTO cadastrarCartaoDTO){

        UsuarioPamcard usuarioPamcard = UsernamePasswordAuthenticationTokenUtils.getUsuarioPamcard(token);
        log.info("Inicio do fluxo casdastrar cartao. Usuario: " + usuarioPamcard);

        AbstractCartaoDTO cartaoDTO = getCartaoService().cadastrarCartao(cadastrarCartaoDTO.getNumeroCartao(), usuarioPamcard);
        log.info("Fim do fluxo casdastrar cartao. Usuario: " + usuarioPamcard);

        URI location = URI.create(ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").toUriString());
        return ResponseEntity.created(location).body(cartaoDTO);
    }
    
    @PostMapping(value = "/{id}/controlesLimites")
   	@Override
    @ResponseStatus(HttpStatus.CREATED)
   	public void cadastrarLimite(UsernamePasswordAuthenticationToken token,
   			@RequestBody @Valid LimiteDTO limiteDTO, @PathVariable(value = "id", required = true) Long idCartao) {

   		UsuarioPamcard usuarioPamcard = UsernamePasswordAuthenticationTokenUtils.getUsuarioPamcard(token);
        log.info("Inicio do fluxo casdastrar senha. Usuario: " + usuarioPamcard);
   		
        getLimiteCartaoService().cadastrarLimite(usuarioPamcard, limiteDTO, idCartao);
               
   		log.info("Fim do fluxo casdastrar senha. Usuario: " + usuarioPamcard);
   	}
    
    
    @PatchMapping(value = "/{id}/controlesLimites/{idLimite}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
   	public void alterarLimite(UsernamePasswordAuthenticationToken token,
   			@RequestBody @Valid LimiteDTO limiteDTO, @PathVariable(value = "id", required = true) Long idCartao, 
   			@PathVariable(value = "idLimite", required = true) Long idLimite) {

   		UsuarioPamcard usuarioPamcard = UsernamePasswordAuthenticationTokenUtils.getUsuarioPamcard(token);
        
   	}

    @GetMapping(value = "/{id}/controlesLimites/{idLimite}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public LimiteDTO consultarLimite(UsernamePasswordAuthenticationToken token,
                                @PathVariable(value = "id", required = true) Long idCartao,
                              @PathVariable(value = "idLimite", required = true) Long idLimite) {

        UsuarioPamcard usuarioPamcard = UsernamePasswordAuthenticationTokenUtils.getUsuarioPamcard(token);

        LimiteDTO limiteDTO = new LimiteDTO();
        limiteDTO.setSaldoDisponivelDiario(new BigDecimal(1));
        limiteDTO.setSaldoDisponivelSemanal(new BigDecimal(2));
        limiteDTO.setSaldoDisponivelMensal(new BigDecimal(3));
        return  limiteDTO;
    }
    
    @PatchMapping(value = "/{idCartao}/portador", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @Override
    public void vincularPortadorAoCartao(UsernamePasswordAuthenticationToken token, @PathVariable("idCartao") Long idCartao, @RequestBody @Valid PortadorDTO portadorDTO){

        UsuarioPamcard usuarioPamcard = UsernamePasswordAuthenticationTokenUtils.getUsuarioPamcard(token);
        log.info("Inicio do fluxo vincular portador ao cartao. Usuario: " + usuarioPamcard);

        getPortadorService().vincularPortadorAoCartao(usuarioPamcard, idCartao, portadorDTO);
        log.info("Fim do fluxo vincular portador ao cartao. Usuario: " + usuarioPamcard);
    }

    @Override
    @GetMapping(
            value = "/status",
            produces = MediaType.APPLICATION_JSON_UTF8_VALUE
    )
    public ResponseEntity<List<SimpleDTO>> carregarStatus(UsernamePasswordAuthenticationToken token) {
        return ResponseEntity.ok(getCartaoService().carregarStatus());
    }

    @Override
    @GetMapping(
            produces = {
                    MediaType.APPLICATION_JSON_UTF8_VALUE
            }
    )
    public ResponseEntity<?> buscarCartoes(UsernamePasswordAuthenticationToken token,
                                           @RequestParam(value = "paginado", defaultValue = "true", required = true) boolean paginado,
                                           @RequestHeader(value ="filtros", required = false) Map<String, String> filtroHeader,
                                           @RequestParam(value = "pagina", defaultValue = "0", required = false) int pagina,
                                           @RequestParam(value = "tamanho", defaultValue = "10", required = false) int tamanho,
                                           @RequestParam(value = "colunaOrdenacao", defaultValue = "idCartao", required = false) String colunaOrdenacao,
                                           @RequestHeader(value = HttpHeaders.ACCEPT, required = false, defaultValue = "application/json") String accept) throws Exception {
        UsuarioPamcard usuario = UsernamePasswordAuthenticationTokenUtils.getUsuarioPamcard(token);
        log.info("Início do fluxo buscar cartões.");
        ResponseEntity<?> cartoes = getCartaoService().buscarCartoes(usuario, paginado, filtroHeader, pagina, tamanho, colunaOrdenacao);
        log.info("Fim do fluxo buscar cartões.");
        return cartoes;
    }

    @GetMapping(
            value = "/{id}",
            produces = MediaType.APPLICATION_JSON_UTF8_VALUE
    )
    @ResponseStatus(HttpStatus.OK)
    public AbstractCartaoDTO buscarPorId(UsernamePasswordAuthenticationToken token, @PathVariable(value = "id")  Long id) {
        log.info("Início do fluxo buscar cartões por id.");
        UsuarioPamcard usuario = UsernamePasswordAuthenticationTokenUtils.getUsuarioPamcard(token);
        return getCartaoService().buscarPorId(id, usuario);
    }

    @PatchMapping(value = "/{id}/senha")
	@Override
    @ResponseStatus(HttpStatus.NO_CONTENT)
	public void cadastrarSenha(UsernamePasswordAuthenticationToken token,
			@RequestBody @Valid CadastrarSenhaDTO cadastrarSenhaDTO, @PathVariable(value = "id", required = true) Long idCartao) {

		UsuarioPamcard usuarioPamcard = UsernamePasswordAuthenticationTokenUtils.getUsuarioPamcard(token);
            log.info("Inicio do fluxo casdastrar senha. Usuario: " + usuarioPamcard);
		getCartaoService().cadastrarSenha(cadastrarSenhaDTO.getSenha(), cadastrarSenhaDTO.getConfirmacaoSenha(),
				usuarioPamcard, idCartao, CADASTRO);
		log.info("Fim do fluxo casdastrar senha. Usuario: " + usuarioPamcard);

	}

    @PatchMapping(value = "/{id}/alterarSenha")
	@Override
    @ResponseStatus(HttpStatus.NO_CONTENT)
	public void alterarSenha(UsernamePasswordAuthenticationToken token,
			@RequestBody @Valid CadastrarSenhaDTO cadastrarSenhaDTO, @PathVariable(value = "id", required = true) Long idCartao) {

		UsuarioPamcard usuarioPamcard = UsernamePasswordAuthenticationTokenUtils.getUsuarioPamcard(token);
            log.info("Inicio do fluxo alterar senha. Usuario: " + usuarioPamcard);
		getCartaoService().cadastrarSenha(cadastrarSenhaDTO.getSenha(), cadastrarSenhaDTO.getConfirmacaoSenha(),
				usuarioPamcard, idCartao, ALTERAR);
		log.info("Fim do fluxo alterar senha. Usuario: " + usuarioPamcard);

	}
    
    @PatchMapping(value = "/{idCartao}/status")
	@Override
    @ResponseStatus(HttpStatus.NO_CONTENT)
	public void alterarStatus(UsernamePasswordAuthenticationToken token,
			@RequestBody String status, @PathVariable(value = "idCartao", required = true) Long idCartao) {

		UsuarioPamcard usuarioPamcard = UsernamePasswordAuthenticationTokenUtils.getUsuarioPamcard(token);
            log.info("Inicio do fluxo alterar status. Usuario: " + usuarioPamcard);
		getCartaoService().alterarStatus(status, usuarioPamcard, idCartao);
		log.info("Fim do fluxo alterar status. Usuario: " + usuarioPamcard);

	}

}