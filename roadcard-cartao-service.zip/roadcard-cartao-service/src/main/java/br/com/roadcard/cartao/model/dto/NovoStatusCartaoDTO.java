package br.com.roadcard.cartao.model.dto;

import br.com.roadcard.cartao.model.CartaoStatusEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotNull;

@Setter
@NoArgsConstructor
@ApiModel(description = "Status disponíveis para o Cartão")
public class NovoStatusCartaoDTO {
	
	@NotNull
	private CartaoStatusEnum status;
	
	public NovoStatusCartaoDTO(@NotNull CartaoStatusEnum status) {
		super();
		this.status = status;
	}
	
	@ApiModelProperty(
		dataType = "java.lang.String", 
		required = true, 
		allowableValues = "ATIVO, BLOQUEADO, CANCELADO"
	)
	public CartaoStatusEnum getStatus() {
		return this.status;
	}

}
