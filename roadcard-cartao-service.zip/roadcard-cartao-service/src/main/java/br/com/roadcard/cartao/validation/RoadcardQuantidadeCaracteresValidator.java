package br.com.roadcard.cartao.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.Optional;

public class RoadcardQuantidadeCaracteresValidator implements ConstraintValidator<QuantidadeCaracteres, String> {

    private int quantidade;

    @Override
    public void initialize(QuantidadeCaracteres constraintAnnotation) {
        this.quantidade = constraintAnnotation.quantidade();
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        return (Optional.ofNullable(value).orElse("").trim().length() == quantidade);
    }

}