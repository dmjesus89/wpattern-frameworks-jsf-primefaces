package br.com.roadcard.cartao.service.interfaces;

import br.com.roadcard.cartao.model.dto.PortadorDTO;
import br.com.roadcard.pamcard.auth.model.login.UsuarioPamcard;

public interface PortadorService {
	
	void vincularPortadorAoCartao(UsuarioPamcard usuarioPamcard, Long idCartao, PortadorDTO portadorDTO);
}
