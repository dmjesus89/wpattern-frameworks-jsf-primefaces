package br.com.roadcard.cartao.exception;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;


@Data
public class CustomExceptionResponse {

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime dataErro;
	
	private HttpStatus status;
	
	private String path;
	
	private String tituloErro;
	
	private String msgErro;
	
	private String debugMsgErro;

	public CustomExceptionResponse(LocalDateTime dataErro, HttpStatus status, String path) {
		this.dataErro = dataErro;
		this.status = status;
		this.path = path;
	}
	
}
