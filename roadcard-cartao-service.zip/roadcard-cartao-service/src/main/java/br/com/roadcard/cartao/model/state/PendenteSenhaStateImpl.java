package br.com.roadcard.cartao.model.state;

import br.com.roadcard.cartao.model.CartaoStatusEnum;

public class PendenteSenhaStateImpl implements CartaoStatusState {

    private static final long serialVersionUID = -7742492602002499144L;

    @Override
    public CartaoStatusEnum definirCartaoPendenteLimite() {
        return CartaoStatusEnum.PENDENTE_LIMITE;
    }

    @Override
    public CartaoStatusEnum definirCartaoCancelado() {
        return CartaoStatusEnum.CANCELADO;
    }

}
