package br.com.roadcard.cartao.cognito;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(path = "/oauth2/token", url = "${api.cognito.endpoint}", name = "autenticacaoClient")
public interface CognitoClient {

	@PostMapping
	public ResponseEntity<CognitoResponse> getToken(@RequestHeader("Authorization") String clientSecret,
			@RequestHeader("Content-Type") String contentType, @RequestParam("grant_type") String clientCredentials,
			@RequestParam("scopes") String scope);
}
