package br.com.roadcard.cartao.model.dto;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import br.com.roadcard.cartao.model.CartaoStatusEnum;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class HistoricoVinculadoDTO implements Serializable{

	private static final long serialVersionUID = -6960693555793349580L;
	
	private Long idCartao;
	private CartaoStatusEnum statusAtual;
	private HistoricoVinculadoPortadorDTO vinculado;
	private boolean propagaLog;
	private String usuario;
	private String proprietario;
	
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime dataHoraVinculo;
	
	
	

}
