package br.com.roadcard.cartao.model;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonValue;

import br.com.roadcard.dock.exception.ResourceNotFoundException;
import br.com.roadcard.pamcard.auth.model.login.PermissaoDespesasConstants;
import lombok.Getter;

@Getter
@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum CartaoStatusEnum {
    PENDENTE_VINCULACAO(
            "PENDENTE_VINCULACAO",
            "Pendente de Vinculação",
            false,
            false,
            Arrays.asList(
                    PermissaoDespesasConstants.APLICACAO_DESPESAS_ACESSO_TOTAL
            )
    ),
    PENDENTE_SENHA(
            "PENDENTE_SENHA",
                    "Pendente de Cadastro de Senha",
                    false,
                    false,
            Arrays.asList(
                    PermissaoDespesasConstants.APLICACAO_DESPESAS_ACESSO_TOTAL
    )
    ),
    PENDENTE_LIMITE(
            "PENDENTE_LIMITE",
            "Pendente de Cadastro de Limite",
            false,
            false,
            Arrays.asList(
                    PermissaoDespesasConstants.APLICACAO_DESPESAS_ACESSO_TOTAL
            )
    ),
    PRONTO_ATIVACAO(
            "PRONTO_ATIVACAO",
            "Pronto Ativação",
            false,
            false,
            Arrays.asList(
                    PermissaoDespesasConstants.APLICACAO_DESPESAS_ACESSO_TOTAL
            )
    ),
    ATIVO(
            "ATIVO",
            "Ativo",
            true,
            true,
            Arrays.asList(
                    PermissaoDespesasConstants.APLICACAO_DESPESAS_ACESSO_TOTAL,
                    PermissaoDespesasConstants.ATIVAR_CARTAO
            )
    ),
    BLOQUEADO(
            "BLOQUEADO",
            "Bloqueado",
            true,
            true,
            Arrays.asList(
                    PermissaoDespesasConstants.APLICACAO_DESPESAS_ACESSO_TOTAL,
                    PermissaoDespesasConstants.BLOQUEAR_CARTAO
            )
    ),
    CANCELADO(
            "CANCELADO",
            "Cancelado",
            true,
            true,
            Arrays.asList(
                    PermissaoDespesasConstants.APLICACAO_DESPESAS_ACESSO_TOTAL,
                    PermissaoDespesasConstants.CANCELAR_CARTAO
            )
    );

    private final String id;

    private final String descricao;

    private final boolean alteraStatusEmissor;

    private final boolean consultaSaldo;

    private final List<String> permissoes;

    CartaoStatusEnum(final String id, final String descricao, final boolean alteraStatusEmissor, final boolean consultaSaldo,
                     final List<String> permissoes) {
        this.id = id;
        this.descricao = descricao;
        this.alteraStatusEmissor = alteraStatusEmissor;
        this.consultaSaldo = consultaSaldo;
        this.permissoes = permissoes;
    }

    @JsonCreator
    public static CartaoStatusEnum buscarEnum(String status) {
        Optional<CartaoStatusEnum> cartaoStatus = Arrays.asList(values())
                .parallelStream().filter(c ->
                        (c.getId().equalsIgnoreCase(status) || status.equalsIgnoreCase(c.getDescricao()))
                ).findFirst();
        if (!cartaoStatus.isPresent()) {
            throw new ResourceNotFoundException(CartaoStatusEnum.class,
                    "id", status);
        }
        return cartaoStatus.get();
    }

    @JsonValue
    public String getValue() {
        return this.id;
    }

    public boolean validarPermissao(CartaoStatusEnum operacao, List<String> permissoesUsuario) {
        return operacao.getPermissoes().parallelStream()
                .filter(auth -> permissoesUsuario.contains(auth)).count() > 0;
    }

}
