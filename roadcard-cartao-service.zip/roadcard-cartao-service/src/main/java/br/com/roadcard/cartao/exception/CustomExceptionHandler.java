package br.com.roadcard.cartao.exception;

import java.time.LocalDateTime;
import java.util.Locale;
import java.util.Optional;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.stereotype.Component;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.fasterxml.jackson.databind.exc.InvalidDefinitionException;

import br.com.roadcard.pamcard.auth.exception.AcessoNegadoException;

@RestControllerAdvice
@Order(Ordered.HIGHEST_PRECEDENCE)
@Component
public class CustomExceptionHandler extends ResponseEntityExceptionHandler {

	private final MessageSource messageSource;
	
	@Autowired
	public CustomExceptionHandler(MessageSource messageSource) {
		super();
		this.messageSource = messageSource;
	}

	
	@ExceptionHandler(UnprocessableEntityException.class)
	public final ResponseEntity<Object> handleUnprocessableEntityException(
			@NotNull UnprocessableEntityException ex, @NotNull WebRequest request) {
		
		Exception exception = ObjectUtils.isEmpty(ex.getException())? ex: ex.getException();
		
		return gerarRetornoExcessao(
				exception, 
				request, 
				HttpStatus.UNPROCESSABLE_ENTITY, 
				messageSource.getMessage(
						ex.getTituloErro(), 
						new Object[] {}, 
						Locale.getDefault()), 
				messageSource.getMessage(
						ex.getMessage(), 
						new Object[] {}, 
						Locale.getDefault()));
	}
	
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {

		CustomExceptionResponse exceptionResponse = new CustomExceptionResponse(LocalDateTime.now(),
				HttpStatus.BAD_REQUEST, request.getDescription(false));
		String titleError = messageSource.getMessage("error.msg.payload.invalido", new Object[] {},
				Locale.getDefault());
		exceptionResponse.setTituloErro(titleError);
		exceptionResponse.setDebugMsgErro(ex.getMessage());
		StringBuilder strError = new StringBuilder();
		for (FieldError fieldErro : ex.getBindingResult().getFieldErrors()) {
			String msgUser = messageSource.getMessage(fieldErro, Locale.getDefault()) + "; ";
			strError.append(msgUser);
		}
		exceptionResponse.setMsgErro(strError.toString());
		return buildError(exceptionResponse);
	}
		
	@Override
	protected ResponseEntity<Object> handleHttpMessageNotReadable(
			@NotNull HttpMessageNotReadableException ex,
			HttpHeaders headers, HttpStatus status, @NotNull WebRequest request) {

		CustomExceptionResponse exceptionResponse = new CustomExceptionResponse(
				LocalDateTime.now(),
				status, 
				request.getDescription(false));
		
		String titleError = messageSource.getMessage(
				"error.msg.solicitacao.json.malFormada", 
				new Object[] {}, 
				Locale.getDefault());
		
		exceptionResponse.setTituloErro(titleError);
		exceptionResponse.setMsgErro(ex.getMessage());
		exceptionResponse.setDebugMsgErro(ex.toString());
		
		return buildError(exceptionResponse);
	}

	//TODO ESSA EXCEPTION EH LANCADO QUANDO TEMOS UM ENUM NA REQUISICAO, NAO EH O CASO DESSA FEATURE.
	@ExceptionHandler(InvalidDefinitionException.class)
	public final ResponseEntity<Object> handleInvalidDefinitionException(
			@NotNull InvalidDefinitionException ex, @NotNull WebRequest request) {

		return gerarRetornoExcessao(
				ex,
				request,
				HttpStatus.BAD_REQUEST,
				"error.msg.payload.invalido",
				ex.getMessage());
	}

	
	
	//TODO ESSA EXCEPTION VAMOS TEM QUE LANCAR QUANDO O CLIENTE REALIZAR ALGUMA OPERAÇAO PARA UM CARTAO QUE NAO EH DELE.
	@ExceptionHandler(AcessoNegadoException.class)
	public final ResponseEntity<Object> handleAcessoNegadoException(
			@NotNull AcessoNegadoException ex, @NotNull WebRequest request) {
		
		return gerarRetornoExcessao(
				ex, 
				request, 
				HttpStatus.FORBIDDEN, 
				"error.msg.cartao.acesso.negado", 
				"error.msg.cartao.acesso.negado");
	}
	

	private ResponseEntity<Object> gerarRetornoExcessao(
			@NotNull Exception ex, 
			@NotNull WebRequest request,
			@NotNull HttpStatus status,
			@NotNull String mensagemTitulo,
			@NotNull String mensagemErro) {
		
		CustomExceptionResponse exceptionResponse = new CustomExceptionResponse(
				LocalDateTime.now(),
				status, 
				request.getDescription(false));
		
		String titleError = "";
		if (!Optional.ofNullable(mensagemTitulo).orElse("").trim().isEmpty()) {
			titleError = messageSource.getMessage(
					mensagemTitulo, 
					new Object[] {}, 
					Locale.getDefault());
		}
		
		exceptionResponse.setTituloErro(titleError);
		if (!Optional.ofNullable(mensagemErro).orElse("").trim().isEmpty()) {
			exceptionResponse.setMsgErro(messageSource.getMessage(
					mensagemErro, 
					new Object[] {}, 
					Locale.getDefault()));
		}
		exceptionResponse.setDebugMsgErro(ex.toString());
		
		return buildError(exceptionResponse);
	}
  
	
	private static ResponseEntity<Object> buildError(CustomExceptionResponse exceptionResponse) {
		return new ResponseEntity<>(exceptionResponse, exceptionResponse.getStatus());
	}
}
