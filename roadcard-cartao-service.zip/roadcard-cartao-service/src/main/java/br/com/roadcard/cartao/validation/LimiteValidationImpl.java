package br.com.roadcard.cartao.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import br.com.roadcard.cartao.exception.UnprocessableEntityException;
import br.com.roadcard.cartao.model.dto.LimiteDTO;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LimiteValidationImpl implements ConstraintValidator<LimiteValidation, LimiteDTO> {

    public boolean isValid(LimiteDTO limiteDTO, ConstraintValidatorContext context) {
        
    	if(limiteDTO.getLimiteDiario().compareTo(limiteDTO.getLimiteSemanal()) == 1) {
    		log.info("LimiteValidationImpl: O limite diario informado é maior que o limite semanal. limiteDTO: "+limiteDTO); 
			throw new UnprocessableEntityException("erro.msg.limite.diario.maior.limite.semanal", "error.msg.validation");
    	}
    	
    	if(limiteDTO.getLimiteSemanal().compareTo(limiteDTO.getLimiteMensal()) == 1) {
    		log.info("LimiteValidationImpl: O limite semanal informado é maior que o limite mensal. limiteDTO: "+limiteDTO); 
			throw new UnprocessableEntityException("erro.msg.limite.semanal.maior.limite.mensal", "error.msg.validation");
    	}
       
        return true;
    }
}
