package br.com.roadcard.cartao.model;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class PortadorConteudo implements Serializable {

	private static final long serialVersionUID = 2368667463279583871L;

	private String dddTelefone;

    private String telefoneCelular;
   
    private String email;
   
    private String nomeMae;
   
    private String numeroRg;
       
    private String ufEmissorRg;

}
