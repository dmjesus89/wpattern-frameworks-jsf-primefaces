package br.com.roadcard.cartao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.roadcard.cartao.model.Portador;

public interface PortadorRepository extends JpaRepository<Portador, String> {
	
	List<Portador> findByCpf(String cpf);
}
