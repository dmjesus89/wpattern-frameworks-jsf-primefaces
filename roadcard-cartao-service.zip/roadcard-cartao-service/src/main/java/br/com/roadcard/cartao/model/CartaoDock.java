package br.com.roadcard.cartao.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@DiscriminatorValue(value = "Dock")
@EqualsAndHashCode(of = {"idCartaoIntegracao"}, callSuper = true)
@Getter
@Setter
@ApiModel
public class CartaoDock extends AbstractCartao{
    private static final long serialVersionUID = -8436887652644135856L;

    @Column(nullable = false)
    private Long idCartaoIntegracao;

    private Integer flagTitular;

    private Long idPessoa;

    private Integer sequencialCartao;

    private Long idConta;

    private Long idStatus;

    private LocalDateTime dataStatus;

    private Integer idEstagio;

    private LocalDateTime dataEstagio;

    private Integer numeroBin;

    @ApiModelProperty(required = true)
    private String numeroCartao;

    private Long numeroCartaoHash;

    private String numeroCartaoCriptografado;

    private LocalDateTime dataEmissao;

    @Column(nullable = false)
    private LocalDateTime dataValidade;

    private Integer cartaoVirtual;

    private Integer impressaoAvulsa;

    private LocalDateTime dataImpressao;

    private String nomeArquivoImpressao;

    private Integer idProduto;

    private String nomeImpresso;

    private String codigoDesbloqueio;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_limite_cartao")
    private LimiteCartao limiteCartao;
    
}
