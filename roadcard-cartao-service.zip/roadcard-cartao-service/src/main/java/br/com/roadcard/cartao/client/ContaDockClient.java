package br.com.roadcard.cartao.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;

import br.com.roadcard.cartao.model.dto.SaldoDisponivelDTO;


@FeignClient(
        url = "${api.conta-dock.endpoint}",
        path = "/api/contas",
        name = "ContaDockClient"
)
public interface ContaDockClient {

    @PostMapping(value = "/{cnpj}/saldo" ,produces = MediaType.APPLICATION_JSON_VALUE)
    SaldoDisponivelDTO consultarSaldo(@RequestHeader("Authorization") String accessToken, @PathVariable(value = "cnpj") String cnpjRequisicao);

}
