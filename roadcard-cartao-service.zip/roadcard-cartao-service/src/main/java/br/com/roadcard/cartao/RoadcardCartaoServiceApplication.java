package br.com.roadcard.cartao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EnableFeignClients(basePackages = "br.com.roadcard")
@ComponentScan(basePackages = "br.com.roadcard")
public class RoadcardCartaoServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoadcardCartaoServiceApplication.class, args);
	}

}
