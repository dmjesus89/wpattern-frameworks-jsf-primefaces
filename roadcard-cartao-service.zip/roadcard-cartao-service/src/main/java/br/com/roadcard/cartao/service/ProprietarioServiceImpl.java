package br.com.roadcard.cartao.service;

import br.com.roadcard.cartao.model.Proprietario;
import br.com.roadcard.cartao.repository.ProprietarioRepository;
import br.com.roadcard.cartao.service.interfaces.ProprietarioService;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@Getter
public class ProprietarioServiceImpl implements ProprietarioService {
    private final ProprietarioRepository proprietarioRepository;
    @Autowired
    public ProprietarioServiceImpl(final ProprietarioRepository proprietarioRepository) {
        this.proprietarioRepository = proprietarioRepository;
    }
    @Override
    public Optional<Proprietario> buscarPorCnpj(String cnpj){
        return getProprietarioRepository().findById(cnpj);
    }

}
