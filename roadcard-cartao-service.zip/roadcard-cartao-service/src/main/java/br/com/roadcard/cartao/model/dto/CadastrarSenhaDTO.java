package br.com.roadcard.cartao.model.dto;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;

import br.com.roadcard.cartao.validation.QuantidadeCaracteres;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@ApiModel
public class CadastrarSenhaDTO implements Serializable {
	
	private static final long serialVersionUID = 6731619503954358778L;

	@NotBlank
    @ApiModelProperty(required = true)
    @QuantidadeCaracteres(quantidade = 4)
    private String senha;
    
    @NotBlank
    @ApiModelProperty(required = true)
    @QuantidadeCaracteres(quantidade = 4)
    private String confirmacaoSenha;

}
