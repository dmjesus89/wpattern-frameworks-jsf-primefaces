package br.com.roadcard.cartao.service;

import java.util.Optional;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import br.com.roadcard.cartao.exception.UnprocessableEntityException;
import br.com.roadcard.cartao.model.dto.CartaoDockIntegradorDTO;
import br.com.roadcard.cartao.model.dto.LimiteDTO;
import br.com.roadcard.cartao.model.dto.PortadorDTO;
import br.com.roadcard.cartao.service.interfaces.IntegradorDockService;
import br.com.roadcard.dock.autenticacao.AutenticacaoDockClient;
import br.com.roadcard.dock.autenticacao.AutenticacaoDockResponse;
import br.com.roadcard.dock.cards.CardDockClient;
import br.com.roadcard.dock.cards.CartaoDockDTO;
import br.com.roadcard.dock.cards.CartaoDockListDTO;
import br.com.roadcard.dock.cards.LimiteCartaoDTO;
import br.com.roadcard.dock.cards.LimiteCartaoResponse;
import br.com.roadcard.dock.companies.BaseCompanyRegisterDockResponse;
import br.com.roadcard.dock.companies.CompanyDockClient;
import br.com.roadcard.dock.companies.CompanyRegisterDockResponse;
import br.com.roadcard.dock.contas.ContasDockClient;
import br.com.roadcard.dock.contas.VincularCartaoRequest;
import br.com.roadcard.dock.contas.VincularPortadorCartaoRequest;
import br.com.roadcard.dock.individuals.BaseIndividualDockResponse;
import br.com.roadcard.dock.individuals.IndividualDockClient;
import br.com.roadcard.dock.individuals.IndividualDockResponse;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@Getter
@Service
public class IntegradorDockServiceImpl implements IntegradorDockService {

    private final CardDockClient cardDockClient;
    private final ContasDockClient contasDockClient;
    private final CompanyDockClient companyDockClient;
    private final IndividualDockClient individualDockClient;
    private final AutenticacaoDockClient autenticacaoDockClient;
    private final ModelMapper modelMapper;

    @Autowired
    public IntegradorDockServiceImpl(CardDockClient cardDockClient, AutenticacaoDockClient autenticacaoDockClient, ModelMapper modelMapper, IndividualDockClient individualDockClient, ContasDockClient contasDockClient, CompanyDockClient companyDockClient) {
        this.cardDockClient = cardDockClient;
		this.contasDockClient = contasDockClient;
		this.companyDockClient = companyDockClient;
		this.individualDockClient = individualDockClient;
        this.autenticacaoDockClient = autenticacaoDockClient;
        this.modelMapper = modelMapper;
    }
    
    @Override
    public void adicionarPortadorParaContaContratante(Integer idPessoa, Integer idConta) {
    	AutenticacaoDockResponse autenticacaoDockResponse = obterAutenticacaoDock();
    	VincularPortadorCartaoRequest vincularPortadorCartaoRequest = new VincularPortadorCartaoRequest();
    	vincularPortadorCartaoRequest.setIdPessoa(idPessoa);
    	try {
    		getContasDockClient().adicionarPortadorParaContaContratante(autenticacaoDockResponse.getAccessToken(), idConta, vincularPortadorCartaoRequest);
    	} catch (Exception e) {
    		log.error("adicionarPortadorParaContaContratante: Houve um erro na integração com a dock. idConta :"+idConta+" idPessoa: "+idPessoa, e);
    		throw new UnprocessableEntityException("error.msg.operacao.emissor", "error.msg.erro.integracao", e);
    	}
    }
    
    @Override
    public LimiteCartaoResponse cadastrarLimiteCartao(LimiteDTO limiteDTO, Long idCartao) {
    	AutenticacaoDockResponse autenticacaoDockResponse = obterAutenticacaoDock();
    	LimiteCartaoDTO limiteCartaoDTO = getModelMapper().map(limiteDTO, LimiteCartaoDTO.class);
    	LimiteCartaoResponse limiteCartaoResponse = new LimiteCartaoResponse();
    	
    	try {
    		limiteCartaoResponse = getCardDockClient().cadastrarLimiteCartao(autenticacaoDockResponse.getAccessToken(), idCartao, limiteCartaoDTO);
    	} catch (Exception e) {
    		log.error("cadastrarLimiteCartao:  Houve um erro na integração com a dock. idConta:"+idCartao+" limiteCartao: "+limiteDTO, e);
    		throw new UnprocessableEntityException("error.msg.operacao.emissor", "error.msg.erro.integracao", e);
        }
    	
    	return limiteCartaoResponse;
    }
    
    @Override
    public void vincularCartaoNaContaCooperada(Integer idConta, VincularCartaoRequest vincularCartaoRequest) {
    	AutenticacaoDockResponse autenticacaoDockResponse = obterAutenticacaoDock();
    	try {
    		getContasDockClient().vincularCartaoNaContaCooperada(autenticacaoDockResponse.getAccessToken(), idConta, vincularCartaoRequest);
    	} catch (Exception e) {
    		log.error("vincularCartaoNaContaCooperada:  Houve um erro na integração com a dock. idConta:"+idConta+" vincularCartaoRequest: "+vincularCartaoRequest, e);
    		throw new UnprocessableEntityException("error.msg.operacao.emissor", "error.msg.erro.integracao", e);
        }
    }
    
    @Override
    public IndividualDockResponse buscarPortadorPorCpfDock(PortadorDTO portadorDTO) {
    	AutenticacaoDockResponse autenticacaoDockResponse = obterAutenticacaoDock();
    	BaseIndividualDockResponse baseIndividualDockResponse;
    	try {
    		baseIndividualDockResponse = getIndividualDockClient().getPortadorPorCpf(autenticacaoDockResponse.getAccessToken(), portadorDTO.getCpf());
    	} catch (Exception e) {
    		log.error("buscarPortadorPorCpfDock: Houve um erro na integração com a dock. Portador: "+portadorDTO, e);
    		throw new UnprocessableEntityException("error.msg.operacao.emissor", "error.msg.erro.integracao", e);
    	}
    	
    	
    	if(ObjectUtils.isEmpty(baseIndividualDockResponse) || CollectionUtils.isEmpty(baseIndividualDockResponse.getItems())) {
    		log.error("buscarPortadorPorCpfDock: Portador nao foi encontrado na dock. Portador: "+portadorDTO);
    		throw new UnprocessableEntityException("erro.msg.motorista.nao.cadastrado.dock", "error.msg.resource.notFound");
    	}
    	
    	IndividualDockResponse individualDockResponse = baseIndividualDockResponse.getItems().stream().findFirst().get();
    	
    	return individualDockResponse;
    }
    
    @Override
    public Integer buscarIdContaPorCnpjDock(String cnpj) {
        AutenticacaoDockResponse autenticacaoDockResponse = obterAutenticacaoDock();
        BaseCompanyRegisterDockResponse baseCompanyRegisterDockResponse;
        try {
        	baseCompanyRegisterDockResponse = getCompanyDockClient().getRegistroEmpresaPorCnpj(autenticacaoDockResponse.getAccessToken(), cnpj);
        } catch (Exception e) {
            log.error("buscarIdContaPorCnpjDock: Erro na Integração com a dock chamando getRegistroEmpresaPorCnpj. CNPJ: "+cnpj, e);
    		throw new UnprocessableEntityException("error.msg.operacao.emissor", "error.msg.erro.integracao", e);
        }
        
        Optional<CompanyRegisterDockResponse> companyRegisterDockResponseOptional = baseCompanyRegisterDockResponse.getResults().stream()
											    			.filter(item -> item.getStatus().equalsIgnoreCase("ACTIVE") 
																&&  StringUtils.isNotEmpty(item.getIdRegistration())).findFirst();

        if(!companyRegisterDockResponseOptional.isPresent()) {
        	log.error("buscarIdContaPorCnpjDock: Não foi encontrado nenhum registro com status ACTIVE. CNPJ: "+cnpj);
        	throw new UnprocessableEntityException("erro.msg.empresa.nao.encontrada", "error.msg.resource.notFound");
        }
        
        return companyRegisterDockResponseOptional.get().getCompany().getIdAccount();
    }



    @Override
    public CartaoDockIntegradorDTO buscarInformacaoCartaoDock(String numeroCartao) {
        AutenticacaoDockResponse autenticacaoDockResponse = obterAutenticacaoDock();
        CartaoDockListDTO cartaoListDTO;
        try {
            cartaoListDTO = getCardDockClient().getInfoCartao(autenticacaoDockResponse.getAccessToken(), numeroCartao);
        } catch (Exception e) {
            log.error("CartaoServiceImpl: Erro ao obter informacoes do cartao na Dock - buscarInformacaoCartaoDock", e);
            throw new UnprocessableEntityException("error.msg.operacao.emissor", "error.msg.erro.integracao", e);
        }
        if(cartaoListDTO == null || ObjectUtils.isEmpty(cartaoListDTO) || CollectionUtils.isEmpty(cartaoListDTO.getCartaoList())) {
            log.error("CartaoServiceImpl: Erro não foi encontrado nenhum cartão na dock com o numeroCartao informado - buscarInformacaoCartaoDock");
            throw new UnprocessableEntityException("error.msg.cartaoDock.nao.encontrado", "error.msg.cartao.notFound");
        }
        CartaoDockDTO cartaoDockDTO = cartaoListDTO.getCartaoList().stream().findFirst().get();

        return getModelMapper().map(cartaoDockDTO, CartaoDockIntegradorDTO.class);
    }


    public AutenticacaoDockResponse obterAutenticacaoDock() {
        AutenticacaoDockResponse autenticacaoDockResponse = getAutenticacaoDockClient().gerarToken();
        if (autenticacaoDockResponse == null || StringUtils.isEmpty(autenticacaoDockResponse.getAccessToken())) {
            log.error("CartaoServiceImpl.obterAutenticacaoDock: Erro ao obter token Dock");
            throw new UnprocessableEntityException("error.msg.operacao.emissor","error.msg.erro.integracao");
        }
        return autenticacaoDockResponse;
    }


	@Override
	public void cadastrarSenha(String senha, Long idCartao) {
		 AutenticacaoDockResponse autenticacaoDockResponse = obterAutenticacaoDock();
		try {
         getCardDockClient().cadastrarSenha(autenticacaoDockResponse.getAccessToken(), senha, idCartao);
        } catch (Exception e) {
            log.error("CartaoServiceImpl: Erro ao cadastrar senha na Dock", e);
            throw new UnprocessableEntityException("error.msg.operacao.emissor", "error.msg.erro.integracao", e);
        }
		
	}
	
	@Override
	public void ativarCartao(Long idCartaoIntegracao) {
		 AutenticacaoDockResponse autenticacaoDockResponse = obterAutenticacaoDock();
		try {
         getCardDockClient().ativarCartao(autenticacaoDockResponse.getAccessToken(), idCartaoIntegracao);
        } catch (Exception e) {
            log.error("CartaoServiceImpl: Erro ao ativar cartão", e);
            throw new UnprocessableEntityException("error.msg.operacao.emissor", "error.msg.erro.integracao", e);
        }
		
	}

	@Override
	public void bloquearCartao(Long idCartaoIntegracao) {
		AutenticacaoDockResponse autenticacaoDockResponse = obterAutenticacaoDock();
		try {
         getCardDockClient().bloquearCartao(autenticacaoDockResponse.getAccessToken(), idCartaoIntegracao);
        } catch (Exception e) {
            log.error("CartaoServiceImpl: Erro ao bloquear cartão", e);
            throw new UnprocessableEntityException("error.msg.operacao.emissor", "error.msg.erro.integracao", e);
        }		
	}
	
	@Override
	public void cancelarCartao(Long idCartaoIntegracao) {
		AutenticacaoDockResponse autenticacaoDockResponse = obterAutenticacaoDock();
		try {
         getCardDockClient().cancelarCartao(autenticacaoDockResponse.getAccessToken(), idCartaoIntegracao);
        } catch (Exception e) {
            log.error("CartaoServiceImpl: Erro ao cancelar cartão", e);
            throw new UnprocessableEntityException("error.msg.operacao.emissor", "error.msg.erro.integracao", e);
        }		
	}
	
	@Override
	public void alterarSenha(String senha, Long idCartao) {
		 AutenticacaoDockResponse autenticacaoDockResponse = obterAutenticacaoDock();
		try {
         getCardDockClient().alterarSenha(autenticacaoDockResponse.getAccessToken(), senha, idCartao);
        } catch (Exception e) {
            log.error("CartaoServiceImpl: Erro ao alterar senha na Dock", e);
            throw new UnprocessableEntityException("error.msg.operacao.emissor", "error.msg.erro.integracao", e);
        }
		
	}

}
