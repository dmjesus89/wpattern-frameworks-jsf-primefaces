
ALTER TABLE cartao.portador ADD COLUMN dados jsonb;
