
ALTER TABLE cartao.cartao ADD COLUMN numero_pedido_plastico BIGINT;
