
ALTER TABLE cartao.cartao ADD COLUMN label_em_processamento VARCHAR(64);
