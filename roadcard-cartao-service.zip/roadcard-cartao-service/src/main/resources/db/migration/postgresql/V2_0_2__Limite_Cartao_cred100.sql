CREATE TABLE if not exists "limite_cartao" (
  "id" SERIAL PRIMARY KEY,
  "id_cartao" SERIAL NOT NULL,
  "id_limite_integracao" numeric NOT NULL,
  "limite_diario" numeric NOT NULL,
  "limite_semanal" numeric NOT NULL,
  "limite_mensal" numeric NOT NULL,
  "proprietario" varchar NOT NULL,
  "limite_ativo" boolean NOT NULL DEFAULT (true),
  "data_hora_cadastro" timestamp NOT NULL,
  "data_hora_atualizacao" timestamp NOT NULL
  );

ALTER TABLE "limite_cartao" ADD FOREIGN KEY ("proprietario") REFERENCES "proprietario" ("cnpj");
ALTER TABLE "limite_cartao" ADD FOREIGN KEY ("id_cartao") REFERENCES "cartao" ("id_cartao");
ALTER TABLE "cartao" ADD FOREIGN KEY ("id_limite_cartao") REFERENCES "limite_cartao" ("id");
