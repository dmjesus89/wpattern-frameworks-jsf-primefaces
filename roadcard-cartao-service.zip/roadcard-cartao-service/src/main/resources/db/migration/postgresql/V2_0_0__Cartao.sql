
ALTER TABLE CARTAO RENAME TO CARTAO_BPP_BACKUP;

-- fazendo backup no lugar de droptable

CREATE TABLE "cartao" (
  "id_cartao" SERIAL PRIMARY KEY,
  "id_cartao_integracao" SERIAL,
  "flag_titular" int,
  "id_pessoa" int,
  "sequencial_cartao" int,
  "id_conta" int NOT NULL,
  "id_status" int,
  "data_status" timestamp,
  "id_estagio" int,
  "data_estagio" timestamp,
  "numero_bin" int,
  "numero_cartao" varchar NOT NULL,
  "numero_cartao_hash" bigint,
  "numero_cartao_criptografado" varchar,
  "data_emissao" timestamp NOT NULL,
  "data_validade" timestamp NOT NULL,
  "cartao_virtual" int,
  "impressao_avulsa" int,
  "data_impressao" timestamp,
  "nome_arquivo_impressao" varchar,
  "id_produto" int,
  "nome_impresso" varchar,
  "codigo_desbloqueio" varchar,
  "data_hora_ativacao" timestamp,
  "data_hora_cadastro" timestamp NOT NULL DEFAULT (now()),
  "data_hora_atualizacao" timestamp NOT NULL DEFAULT (now()),
  "data_hora_cancelamento" timestamp,
  "data_hora_bloqueio" timestamp,
  "data_hora_desbloqueio" timestamp,
  "data_hora_cadastro_senha" timestamp,
  "data_hora_alteracao_senha" timestamp,
  "emissor" varchar NOT NULL,
  "modalidade" varchar NOT NULL,
  "portador" varchar,
  "proprietario" varchar NOT NULL,
  "quatro_ultimos_digitos" varchar(4) NOT NULL,
  "status" varchar NOT NULL,
  "id_limite_cartao" BIGINT,
  "usuario_solicitante" varchar NOT NULL
);

COMMENT ON COLUMN "cartao"."data_hora_cadastro" IS 'When cartao created';

COMMENT ON COLUMN "cartao"."data_hora_atualizacao" IS 'When cartao updated';

COMMENT ON COLUMN "portador"."dados" IS 'JSON COLUMN';

ALTER TABLE "cartao" ADD FOREIGN KEY ("portador") REFERENCES "portador" ("cpf");

ALTER TABLE "cartao" ADD FOREIGN KEY ("proprietario") REFERENCES "proprietario" ("cnpj");
